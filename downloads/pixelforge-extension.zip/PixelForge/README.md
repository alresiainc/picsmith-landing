# ✨ PixelForge — AI Photo Editor

A **powerful, offline-first photo editor** that lives in your browser as an
extension. Built for Chrome / Edge / Brave / Opera (Manifest V3), plain vanilla
JS with **no build step** — exactly like the other extensions in this repo.

- **Free tier:** the entire editor works fully offline — layers, filters,
  drawing, text, shapes, crop, resize, templates and export.
- **PixelForge Pro:** unlocks AI — tell the AI what to change, remove
  backgrounds, restyle your image, generate new images and analyze your work
  (OpenAI GPT-4o + gpt-image-1).

---

## ✨ Features

| Area | What you get |
| --- | --- |
| 🗂️ **Layers** | Add, reorder, duplicate, delete, hide; per-layer opacity; raster / text / shape layers |
| 🎛️ **Adjust** | 10 one-tap presets (Vivid, Noir, Cinematic…) + brightness, contrast, saturation, hue, blur and a real pixel-level **sharpen** |
| 🖌️ **Drawing** | Brush (size / softness / opacity / colour), eraser, **fill bucket (tolerance)**, **gradient (linear/radial)**, **blur brush**, **clone stamp**, eyedropper with live brush cursor |
| 🔤 **Text** | Click to add, double-click to edit inline, 12 system fonts, size, colour, bold/italic, **line height, letter spacing, all-caps, outline** |
| 🔷 **Shapes** | Rectangle, ellipse, **triangle, diamond, star, heart, pentagon, hexagon**, line, arrow — fill, outline, weight, corner radius, star points |
| 🖱️ **Item inspector** | Click any item and a **contextual panel** appears: exact X/Y/W/H, rotation, opacity, flip, rotate 90°, six align buttons, arrange (front/back) — plus per-item **effects** |
| 📥 **Elements panel** | A dedicated **Elements** tab — drag **text, images or any shape** onto the canvas with a live ghost preview, drop badge and glowing drop zone (click a chip to add it centred) |
| 🔲 **Resize / rotate** | Grab any **corner** to scale (Shift = uniform), **edge handles** for width/height, the **round handle** to rotate (Shift snaps to 15°), plus hover feedback — the cursor changes, the handle glows and a hint names the action. Scaling is anchor-pinned, so it stays correct on already-resized layers |
| 🎯 **Corner radius** | Drag the **amber diamond** on an item's top edge to round its corners live — shapes, images and text borders |
| ✨ **Item effects** | Non-destructive **drop shadow** (colour/blur/offset/opacity), **border** (colour/width/corner radius), **reflection** (opacity/gap/height), **background** fill — for images, text *and* shapes |
| 🖼️ **Images** | Add via file, drag-and-drop or paste — then **replace in place**, or use **AI background removal** from the inspector |
| 💬 **Tooltips** | Hover any tool or button for a rich popover: name, what it does, and its shortcut |
| ✂️ **Tools** | Move + transform (scale/rotate handles), crop, pan, zoom (click / scroll / fit / 100%), 13 tools total |
| 🖼️ **Templates** | Instagram post & story, YouTube thumbnail, X/Twitter, Facebook & LinkedIn banners, Pinterest, A4 print + custom sizes |
| 📤 **Export** | PNG / JPG / WebP with quality; free tier caps at 2048px long edge, Pro exports full resolution |
| 📦 **Projects** | Autosaved to IndexedDB, recent designs in the popup, `.pfproj` backup downloads |
| ✨ **AI (Pro)** | Prompt-based edits, background removal & style transfers, text-to-image, image analysis, smart suggestions, captions |
| 🔒 **Privacy** | Everything offline by default. Images only leave your browser when you explicitly run an AI tool |

## 🖥️ Loading the extension (unpacked)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Toggle **Developer mode** on.
3. Click **Load unpacked** → select:
   ```
   browser extensions/PixelForge
   ```
4. Pin PixelForge to the toolbar. 🎉

## 📁 Project structure

```
PixelForge/
├── manifest.json      # MV3 manifest
├── background.js      # Service worker: OpenAI calls + Pro license validation
├── popup.html/css/js  # Quick-create + recent projects
├── install.html/css/js# Welcome page (opens on install)
├── editor.html        # Full-screen editor page
├── editor.css         # Editor theme
├── editor.js          # Editor controller (workspace, tools, panels, AI, shortcuts)
├── lib/
│   ├── idb.js         # Promise-based IndexedDB helper (project storage)
│   ├── project.js     # Document model, templates, serialization, export
│   ├── filters.js     # Filter pipeline + pixel sharpen
│   ├── canvas-engine.js # Layer compositing, transforms, hit-testing, effects
│   ├── tools.js       # 13 tools incl. fill/gradient/blur/clone-stamp/zoom
│   └── license.js     # HMAC-SHA256 Pro key core (shared with Node tooling)
├── icons/             # Generated icons
└── tools/
    ├── gen-icons.js   # node tools/gen-icons.js — regenerate icons
    └── mint-key.js    # node tools/mint-key.js [days] [count] — mint Pro keys
```

## 🔑 Monetization (PixelForge Pro)

- **Free tier:** everything offline, full quality editing, export capped at
  2048px long edge.
- **Pro:** AI tools + full-resolution export. Unlocks with an HMAC-signed key:
  ```
  node tools/mint-key.js            # one lifetime Pro key
  node tools/mint-key.js 365 5      # five keys, valid 365 days
  ```
  Paste the key in **Settings → License** (or the AI panel) to activate.

> ⚠️ **v1 note:** the HMAC secret ships inside the extension, so someone with
> the source can mint their own keys. For a hardened production build, validate
> keys against your backend instead (the key scheme — tier + expiry — carries
> over unchanged). Keys also work offline; nothing phones home.

## 🤖 AI setup

AI runs through **OpenAI** (GPT-4o vision + gpt-image-1):

1. Get an API key at [platform.openai.com](https://platform.openai.com).
2. Paste it in **Settings → AI provider**. It is stored in your browser only.
3. Activate a **Pro key** (see above) to unlock the AI tab.

The editor prepares images for `gpt-image-1` (square-padded to a supported
size) and crops the result back to your image's aspect ratio automatically.

## ⌨️ Shortcuts

| Key | Action |
| --- | --- |
| `V B E I T U` | Move / Brush / Eraser / Eyedropper / Text / Shape |
| `F G L S C Z H` | Fill / Gradient / Blur brush / Clone stamp / Crop / Zoom / Pan |
| `Ctrl+Z` / `Ctrl+Shift+Z` | Undo / Redo |
| `Ctrl+S` | Save project · `Ctrl+E` Export |
| `0` / `1` / `+` / `−` | Fit / 100% / Zoom in / Zoom out |
| `Delete` | Remove selected layer · `←↑→↓` nudge (Shift = ×10) |
| `Space` (hold) | Temporary pan |
| `Enter` / `Esc` | Apply / cancel crop |

## 🔧 Development notes

- **No build step.** Edit any file, then hit reload in `chrome://extensions`.
- Regenerate icons: `node tools/gen-icons.js`
- Mint keys: `node tools/mint-key.js`
- Projects are stored in IndexedDB (`pixelforge` db) so full-resolution designs
  don't hit the `chrome.storage` quota (`unlimitedStorage` is requested).

## 🗺️ Roadmap

- [ ] Non-destructive adjustment layers (current filters bake into the layer)
- [ ] Selection tools (marquee / magic wand) + transform-as-selection
- [ ] More AI models / providers + server-side key validation
- [ ] Chrome Web Store + Edge Add-ons listings
- [ ] Watermark/watermark-free toggle on free exports (ad-based monetization)

---

**PixelForge — your photos, your browser, unlimited imagination.**
