/* PixelForge popup */
"use strict";

const $ = (id) => document.getElementById(id);
const els = {
  proBadge: $("proBadge"),
  recentList: $("recentList"),
  openBtn: $("openBtn"),
  licLine: $("licLine"),
};

function openEditor(url) {
  chrome.tabs.create({ url: chrome.runtime.getURL(url) });
}

function renderProjects(projects) {
  const list = els.recentList;
  list.innerHTML = "";
  if (!projects.length) {
    list.innerHTML = '<div class="empty">No projects yet — create your first design!</div>';
    return;
  }
  projects.slice(0, 9).forEach((p) => {
    const card = document.createElement("div");
    card.className = "recent-card";
    card.title = p.name;
    card.innerHTML = `
      ${p.thumbnail ? `<img src="${p.thumbnail}" alt="" draggable="false">` : ""}
      <span class="rc-dim">${p.width}×${p.height}</span>
      <span class="rc-name"></span>`;
    card.querySelector(".rc-name").textContent = p.name;
    card.addEventListener("click", () => openEditor(`editor.html?id=${encodeURIComponent(p.id)}`));
    list.appendChild(card);
  });
}

async function boot() {
  // Quick-create buttons
  document.querySelectorAll(".quick-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tpl = btn.dataset.tpl;
      openEditor(tpl === "custom" ? "editor.html" : `editor.html?new=${encodeURIComponent(tpl)}`);
      window.close();
    });
  });

  els.openBtn.addEventListener("click", () => {
    openEditor("editor.html");
    window.close();
  });

  // Recent projects (most recently updated first)
  try {
    const all = await PFDB.getAll("projects");
    all.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    renderProjects(all);
  } catch {
    renderProjects([]);
  }

  // License status
  try {
    const res = await chrome.runtime.sendMessage({ type: "license:status" });
    if (res && res.active) {
      els.proBadge.classList.add("active");
      els.licLine.textContent = res.exp
        ? `PixelForge Pro · expires ${new Date(res.exp * 1000).toLocaleDateString()}`
        : "PixelForge Pro active";
    }
  } catch { /* background unavailable */ }
}

boot();
