/* PixelForge editor — main controller. Vanilla JS, no build step. */
"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const els = {
    menuBar: $("menuBar"),
    docName: $("docName"), undoBtn: $("undoBtn"), redoBtn: $("redoBtn"),
    zoomOut: $("zoomOut"), zoomLabel: $("zoomLabel"), zoomIn: $("zoomIn"), zoomFit: $("zoomFit"),
    newBtn: $("newBtn"), saveBtn: $("saveBtn"), exportBtn: $("exportBtn"), proBadge: $("proBadge"),
    contextBar: $("contextBar"),
    leftBar: $("leftBar"),
    workspace: $("workspace"), workspaceWrap: $("workspaceWrap"),
    stage: $("stage"), docCanvas: $("docCanvas"), previewCanvas: $("previewCanvas"),
    selectionOverlay: $("selectionOverlay"), cropOverlay: $("cropOverlay"), brushCursor: $("brushCursor"),
    hudZoom: $("hudZoom"), hudSize: $("hudSize"), hudTool: $("hudTool"), hudHint: $("hudHint"), hudCursor: $("hudCursor"),
    dragHint: $("dragHint"),
    rightPanel: $("rightPanel"), ctxMenu: $("ctxMenu"),
    presetGrid: $("presetGrid"),
    fxBrightness: $("fxBrightness"), fxContrast: $("fxContrast"), fxSaturate: $("fxSaturate"),
    fxHue: $("fxHue"), fxBlur: $("fxBlur"), fxSharpen: $("fxSharpen"),
    vBrightness: $("vBrightness"), vContrast: $("vContrast"), vSaturate: $("vSaturate"),
    vHue: $("vHue"), vBlur: $("vBlur"), vSharpen: $("vSharpen"),
    applyFxBtn: $("applyFxBtn"), resetFxBtn: $("resetFxBtn"), resizeBtn: $("resizeBtn"),
    layersList: $("layersList"), btnAddImage: $("btnAddImage"), btnAddText: $("btnAddText"),
    btnAddShape: $("btnAddShape"), btnAddBrush: $("btnAddBrush"),
    layerOpacity: $("layerOpacity"), layerOpacityVal: $("layerOpacityVal"),
    layerUp: $("layerUp"), layerDown: $("layerDown"), layerDup: $("layerDup"), layerDel: $("layerDel"),
    aiLocked: $("aiLocked"), aiBody: $("aiBody"), aiKeyInput: $("aiKeyInput"),
    aiActivateBtn: $("aiActivateBtn"), aiStatusLine: $("aiStatusLine"), aiModeSeg: $("aiModeSeg"),
    aiChips: $("aiChips"), aiPrompt: $("aiPrompt"), aiGo: $("aiGo"), aiOutput: $("aiOutput"),
    setKey: $("setKey"), setModel: $("setModel"),
    licKeyInput: $("licKeyInput"), licActivateBtn: $("licActivateBtn"), licClearBtn: $("licClearBtn"), licStatus: $("licStatus"),
    btnDownloadProject: $("btnDownloadProject"), btnClearProjects: $("btnClearProjects"), btnResetAll: $("btnResetAll"),
    verText: $("verText"),
    textPop: $("textPop"), textPopInput: $("textPopInput"),
    templateGrid: $("templateGrid"), newW: $("newW"), newH: $("newH"), newCreateBtn: $("newCreateBtn"),
    fmtSeg: $("fmtSeg"), expQuality: $("expQuality"), expQualityVal: $("expQualityVal"),
    expSizeNote: $("expSizeNote"), expDims: $("expDims"), expBtn: $("expBtn"),
    resW: $("resW"), resH: $("resH"), resizeApply: $("resizeApply"),
    confirmText: $("confirmText"), confirmTitle: $("confirmTitle"),
    confirmOk: $("confirmOk"), confirmCancel: $("confirmCancel"),
    toast: $("toast"), tooltip: $("tooltip"),
    inspector: $("inspector"), inspIcon: $("inspIcon"), inspName: $("inspName"), inspType: $("inspType"),
    inspEye: $("inspEye"), inspDup: $("inspDup"), inspDel: $("inspDel"), inspReturn: $("inspReturn"),
    inspX: $("inspX"), inspY: $("inspY"), inspW: $("inspW"), inspH: $("inspH"),
    inspRot: $("inspRot"), inspOp: $("inspOp"),
    inspFlipX: $("inspFlipX"), inspFlipY: $("inspFlipY"),
    inspRotL: $("inspRotL"), inspRotR: $("inspRotR"),
    inspToFront: $("inspToFront"), inspFwd: $("inspFwd"), inspBack: $("inspBack"), inspToBack: $("inspToBack"),
    inspTypeSection: $("inspTypeSection"),
    fxShadowOn: $("fxShadowOn"), fxShadowColor: $("fxShadowColor"), fxShadowBlur: $("fxShadowBlur"),
    fxShadowX: $("fxShadowX"), fxShadowY: $("fxShadowY"), fxShadowOp: $("fxShadowOp"),
    fxBorderOn: $("fxBorderOn"), fxBorderColor: $("fxBorderColor"), fxBorderWidth: $("fxBorderWidth"), fxBorderRadius: $("fxBorderRadius"),
    fxReflOn: $("fxReflOn"), fxReflOp: $("fxReflOp"), fxReflGap: $("fxReflGap"), fxReflH: $("fxReflH"),
    fxBgOn: $("fxBgOn"), fxBgColor: $("fxBgColor"), fxBgRadius: $("fxBgRadius"),
  };

  // ================================================================== state
  const FONTS = [
    "Arial", "Helvetica", "Georgia", "Times New Roman", "Courier New", "Verdana",
    "Trebuchet MS", "Impact", "Comic Sans MS", "Palatino", "Tahoma", "Segoe UI",
  ];

  const state = {
    doc: null,
    tool: "move",
    toolInstance: null,
    selectedId: null,
    zoom: 1,
    history: [],
    hIndex: -1,
    saveTimer: null,
    settings: {},
    license: null,
    previousPaintTool: "brush",
    toolOptions: {
      size: 14, hardness: 0.85, opacity: 1, color: "#6366f1",
      tolerance: 24,
      gradType: "linear", color2: "#0ea5e9",
      points: 5,
      shapeKind: "rect", fill: "#6366f1", stroke: "#111827", strokeWidth: 3, radius: 12,
      textDefaults: { fontFamily: "Arial", fontSize: 64, fontWeight: 400, fontStyle: "normal", color: "#111827", align: "center", letterSpacing: 0, upper: false },
    },
    fx: { brightness: 0, contrast: 0, saturate: 0, hue: 0, blur: 0, sharpen: 0 },
    cropRect: null,
    aiMode: "edit",
    aiBusy: false,
    layersTabActive: false,
    itemDragActive: false,
    dragging: false,
    middlePan: false,
    exportFormat: "png",
    textPopOrig: "",
  };

  const AI_CHIPS = {
    edit: [
      "Remove the background", "Enhance lighting and color", "Make it a cartoon",
      "Turn it into an oil painting", "Add a dramatic sunset sky", "Make it a watercolor painting",
      "Sharpen details and upscale", "Make the mood cinematic",
    ],
    create: [
      "A cozy cabin in a snowy forest", "A futuristic city skyline at sunset",
      "A minimalist poster of mountain peaks", "A cute robot watering flowers",
      "An astronaut floating among colorful nebulas", "A macro photo of a colorful butterfly",
    ],
    analyze: ["Describe this image", "Suggest improvements", "Write captions", "What could be better here?"],
  };
  const ANALYZE_MODES = {
    "Describe this image": "describe",
    "Suggest improvements": "suggest",
    "Write captions": "caption",
  };

  // ================================================================== helpers
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const selectedLayer = () => layerById(state.selectedId);
  const layerById = (id) => (state.doc ? state.doc.layers.find((l) => l.id === id) : null);

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Failed to load image"));
      img.src = src;
    });
  }

  function cloneCanvas(c) {
    const n = document.createElement("canvas");
    n.width = c.width;
    n.height = c.height;
    n.getContext("2d").drawImage(c, 0, 0);
    return n;
  }

  function sendMessage(msg) {
    return chrome.runtime.sendMessage(msg).catch((err) => ({ ok: false, error: String(err) }));
  }

  let toastTimer = null;
  function toast(message, isError = false) {
    els.toast.textContent = message;
    els.toast.classList.toggle("error", !!isError);
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove("show"), 2600);
  }

  // ================================================================== boot
  async function boot() {
    buildStageWrap();
    moveBrushCursorToWorkspace();
    renderToolRail();
    renderTemplates();
    renderPresets();
    renderAIChips();
    bindMenuBar();
    bindTopbar();
    bindPanels();
    bindModals();
    bindShortcuts();
    bindDnD();
    bindSettingsUI();
    initTooltips();
    bindInspector();
    renderElementsPanel();
    initItemDrag();
    bindDockResizer();
    bindContextMenu();
    setTool("move");

    await loadSettings();
    renderProUI();

    const params = new URLSearchParams(location.search);
    const docId = params.get("id");
    const newTpl = params.get("new");
    if (docId) {
      await loadProject(docId);
    } else if (newTpl) {
      createFromTemplate(newTpl);
    } else {
      createFromTemplate("instagram-post");
      openModal("modalNew");
    }
    updateHud();
  }

  function buildStageWrap() {
    const wrap = document.createElement("div");
    wrap.className = "stage-wrap";
    els.workspace.insertBefore(wrap, els.stage);
    wrap.appendChild(els.stage);
    els.stageWrap = wrap;
    // The text popover is positioned in workspace coordinates.
    els.workspaceWrap.appendChild(els.textPop);
  }

  function moveBrushCursorToWorkspace() {
    els.workspace.appendChild(els.brushCursor);
  }

  // ================================================================== document
  function createFromTemplate(tid, opts = {}) {
    const t = PFProject.TEMPLATES.find((x) => x.id === tid);
    state.doc = PFProject.createDoc({
      name: opts.name || (t ? t.name : "Untitled design"),
      width: opts.width || (t ? t.w : 1080),
      height: opts.height || (t ? t.h : 1080),
      template: tid,
      background: opts.background != null ? opts.background : "#ffffff",
    });
    state.selectedId = null;
    closeAllModals();
    setupCanvas(true);
    render();
    renderLayersPanel();
    updateTopbar();
    els.docName.value = state.doc.name;
    state.history = [JSON.stringify(PFProject.serializeDoc(state.doc))];
    state.hIndex = 0;
  }

  async function loadProject(id) {
    try {
      const record = await PFDB.get("projects", id);
      if (!record) throw new Error("Project not found");
      state.doc = await PFProject.deserializeDoc(record.data);
      state.selectedId = null;
      setupCanvas(true);
      render();
      renderLayersPanel();
      updateTopbar();
      els.docName.value = state.doc.name;
      state.history = [JSON.stringify(PFProject.serializeDoc(state.doc))];
      state.hIndex = 0;
      toast("Project loaded");
    } catch (err) {
      toast("Could not load project", true);
      createFromTemplate("instagram-post");
    }
  }

  function setupCanvas(fit = true) {
    const d = state.doc;
    els.docCanvas.width = d.width;
    els.docCanvas.height = d.height;
    els.previewCanvas.width = d.width;
    els.previewCanvas.height = d.height;
    // The stage's children (canvases + overlays) are all absolutely positioned,
    // so the stage would collapse to 0×0 without explicit dimensions — which
    // would clip/hide the whole artboard. Unscaled size is zoom-independent.
    els.stage.style.width = `${d.width}px`;
    els.stage.style.height = `${d.height}px`;
    if (fit) zoomFit();
    updateHud();
  }

  function updateHud() {
    els.hudSize.textContent = `${state.doc.width} × ${state.doc.height}`;
    els.hudZoom.textContent = `${Math.round(state.zoom * 100)}%`;
  }

  // ================================================================== render
  function render() {
    PFEngine.renderDoc(els.docCanvas, state.doc);
    refreshOverlay();
    syncInspector();
  }

  function refreshOverlay() {
    els.selectionOverlay.innerHTML = "";
    clearHover();
    const layer = selectedLayer();
    if (!layer || !layer.content) return;
    const corners = PFEngine.layerCorners(layer);
    if (!corners.length) return;
    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);

    const box = document.createElement("div");
    box.className = "sel-box";
    box.style.cssText = `left:${minX}px;top:${minY}px;width:${maxX - minX}px;height:${maxY - minY}px;`;
    els.selectionOverlay.appendChild(box);

    corners.forEach((c, i) => {
      const h = document.createElement("div");
      h.className = "sel-handle";
      h.dataset.hdl = `c${i}`;
      h.style.cssText = `left:${c.x}px;top:${c.y}px;`;
      els.selectionOverlay.appendChild(h);
    });

    // Edge midpoints for single-axis resize: right, bottom, left.
    // (The top edge is reserved for the corner-radius handle.)
    const edgeMids = [
      { x: (corners[1].x + corners[2].x) / 2, y: (corners[1].y + corners[2].y) / 2 },
      { x: (corners[2].x + corners[3].x) / 2, y: (corners[2].y + corners[3].y) / 2 },
      { x: (corners[3].x + corners[0].x) / 2, y: (corners[3].y + corners[0].y) / 2 },
    ];
    edgeMids.forEach((m, i) => {
      const h = document.createElement("div");
      h.className = "sel-handle edge";
      h.dataset.hdl = `e${i + 1}`;
      h.style.cssText = `left:${m.x}px;top:${m.y}px;`;
      els.selectionOverlay.appendChild(h);
    });

    // Rotate handle — offset above the top edge midpoint.
    const edge = { x: corners[1].x - corners[0].x, y: corners[1].y - corners[0].y };
    const len = Math.hypot(edge.x, edge.y) || 1;
    const mid = { x: (corners[0].x + corners[1].x) / 2, y: (corners[0].y + corners[1].y) / 2 };
    const off = 26 / state.zoom;
    const rh = document.createElement("div");
    rh.className = "sel-rotate";
    rh.dataset.hdl = "rot";
    rh.style.cssText = `left:${mid.x + (-edge.y / len) * off}px;top:${mid.y + (edge.x / len) * off}px;`;
    els.selectionOverlay.appendChild(rh);

    // Corner-radius handle — rides the top edge, offset right by the radius.
    const rp = radiusHandlePoint(layer);
    if (rp) {
      const rad = document.createElement("div");
      rad.className = "sel-radius";
      rad.dataset.hdl = "radius";
      rad.style.cssText = `left:${rp.x}px;top:${rp.y}px;`;
      els.selectionOverlay.appendChild(rad);
    }
  }

  // ---------------------------------------------------------------- selection helpers

  /** Map a content-space point through the layer transform into doc space. */
  function layerContentToDoc(layer, lx, ly) {
    const t = layer.transform;
    const cos = Math.cos(t.rotation), sin = Math.sin(t.rotation);
    const sx = t.scaleX || 1, sy = t.scaleY || 1;
    return {
      x: t.x + (lx * sx * cos - ly * sy * sin),
      y: t.y + (lx * sx * sin + ly * sy * cos),
    };
  }

  /** The layer's current corner radius (content units). */
  function effectiveRadius(layer) {
    if (layer.type === "shape") return Math.max(0, layer.radius || 0);
    const fx = PFEngine.mergeEffects(layer.effects);
    return Math.max(0, fx.border.radius || 0, fx.bg.radius || 0);
  }

  /** True when dragging the radius handle actually changes something visible. */
  function radiusHandleVisible(layer) {
    if (layer.type === "shape") return layer.shapeKind === "rect";
    if (layer.type === "text") {
      const fx = PFEngine.mergeEffects(layer.effects);
      return !!(fx.border.on && fx.border.width > 0);
    }
    return true; // raster — the radius clip always applies
  }

  /** Doc position of the corner-radius drag handle (top edge of the box). */
  function radiusHandlePoint(layer) {
    const c = layer.content;
    if (!c || !radiusHandleVisible(layer)) return null;
    const r = Math.min(effectiveRadius(layer), Math.max(0, c.width / 2 - 1));
    return layerContentToDoc(layer, r, -c.height / 2);
  }

  function clearHover() {
    if (state.hoverEl) { state.hoverEl.classList.remove("hot"); state.hoverEl = null; }
    if (els.dragHint) els.dragHint.classList.add("hidden");
  }

  function hdlAttrFor(hit) {
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      return i < 4 ? `c${i}` : `e${i - 4}`;
    }
    return hit === "rotate" ? "rot" : hit; // "radius"
  }

  function cursorForHandle(hit) {
    if (hit === "move") return "move";
    if (hit === "rotate") return "grab";
    if (hit === "radius") return "ew-resize";
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      if (i < 4) return i % 2 === 0 ? "nwse-resize" : "nesw-resize";
      return i === 6 ? "ns-resize" : "ew-resize";
    }
    return "default";
  }

  function labelForHandle(hit) {
    if (hit === "move") return "Move";
    if (hit === "rotate") return "Rotate — drag to turn";
    if (hit === "radius") return "Corner radius — drag along the edge";
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      if (i < 4) return "Resize — drag the corner";
      return i === 5 || i === 7 ? "Resize width" : "Resize height";
    }
    return "";
  }

  function showDragHint(text, pt) {
    const hint = els.dragHint;
    hint.textContent = text;
    const wrapR = els.workspace.getBoundingClientRect();
    const stageR = els.stage.getBoundingClientRect();
    hint.style.left = stageR.left - wrapR.left + pt.x * state.zoom + "px";
    hint.style.top = stageR.top - wrapR.top + pt.y * state.zoom + "px";
    hint.classList.remove("hidden");
  }

  function updateHover(e) {
    if (state.itemDragActive) return;
    if (state.hoverEl) { state.hoverEl.classList.remove("hot"); state.hoverEl = null; }
    const layer = selectedLayer();
    const pt = docPoint(e);
    const hit = layer && layer.content && state.tool === "move" ? hitSelectionHandle(pt) : null;
    if (hit) {
      const el = els.selectionOverlay.querySelector(`[data-hdl="${hdlAttrFor(hit)}"]`);
      if (el) { el.classList.add("hot"); state.hoverEl = el; }
      els.workspace.style.cursor = cursorForHandle(hit);
      showDragHint(labelForHandle(hit), pt);
    } else {
      els.workspace.style.cursor = "default";
      els.dragHint.classList.add("hidden");
    }
  }

  function hitSelectionHandle(pt) {
    const layer = selectedLayer();
    if (!layer || !layer.content) return null;
    const corners = PFEngine.layerCorners(layer);
    const tol = 12 / state.zoom;
    const tolR = 13 / state.zoom;

    // Corner + edge resize handles (corners first — they win near overlaps).
    for (let i = 0; i < 4; i++) {
      if (Math.hypot(pt.x - corners[i].x, pt.y - corners[i].y) <= tol) return "scale:" + i;
    }
    const edgeMids = [
      { x: (corners[1].x + corners[2].x) / 2, y: (corners[1].y + corners[2].y) / 2 },
      { x: (corners[2].x + corners[3].x) / 2, y: (corners[2].y + corners[3].y) / 2 },
      { x: (corners[3].x + corners[0].x) / 2, y: (corners[3].y + corners[0].y) / 2 },
    ];
    for (let i = 0; i < 3; i++) {
      if (Math.hypot(pt.x - edgeMids[i].x, pt.y - edgeMids[i].y) <= tol) return "scale:" + (i + 5);
    }

    // Corner-radius handle (owns the top edge midpoint).
    const rp = radiusHandlePoint(layer);
    if (rp && Math.hypot(pt.x - rp.x, pt.y - rp.y) <= tolR) return "radius";

    // Rotate handle — offset above the top edge midpoint (mid of c0→c1).
    const topMid = { x: (corners[0].x + corners[1].x) / 2, y: (corners[0].y + corners[1].y) / 2 };
    const edge = { x: corners[1].x - corners[0].x, y: corners[1].y - corners[0].y };
    const len = Math.hypot(edge.x, edge.y) || 1;
    const rhp = { x: topMid.x + (-edge.y / len) * (26 / state.zoom), y: topMid.y + (edge.x / len) * (26 / state.zoom) };
    if (Math.hypot(pt.x - rhp.x, pt.y - rhp.y) <= tol + 5) return "rotate";

    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    if (pt.x >= Math.min(...xs) && pt.x <= Math.max(...xs) && pt.y >= Math.min(...ys) && pt.y <= Math.max(...ys)) return "move";
    return null;
  }

  // ================================================================== history
  function pushHistory() {
    if (!state.doc) return;
    state.history = state.history.slice(0, state.hIndex + 1);
    state.history.push(JSON.stringify(PFProject.serializeDoc(state.doc)));
    if (state.history.length > 20) state.history.shift();
    state.hIndex = state.history.length - 1;
    updateTopbar();
  }

  async function undo() {
    if (state.hIndex <= 0) return;
    state.hIndex--;
    try {
      state.doc = await PFProject.deserializeDoc(JSON.parse(state.history[state.hIndex]));
    } catch { return; }
    if (!layerById(state.selectedId)) state.selectedId = null;
    applyHistoryRestore();
  }

  async function redo() {
    if (state.hIndex >= state.history.length - 1) return;
    state.hIndex++;
    try {
      state.doc = await PFProject.deserializeDoc(JSON.parse(state.history[state.hIndex]));
    } catch { return; }
    if (!layerById(state.selectedId)) state.selectedId = null;
    applyHistoryRestore();
  }

  function applyHistoryRestore() {
    setupCanvas(false);
    render();
    renderLayersPanel();
    updateContextBar();
    renderInspector();
    updateTopbar();
    markDirty();
  }

  function updateTopbar() {
    els.undoBtn.disabled = state.hIndex <= 0;
    els.redoBtn.disabled = state.hIndex >= state.history.length - 1;
  }

  // ================================================================== selection / layers
  function selectLayer(id, opts = {}) {
    state.selectedId = id;
    refreshOverlay();
    if (!opts.silent) {
      updateContextBar();
      renderLayersPanel();
      renderInspector();
    }
  }

  function addLayer(layer, opts = {}) {
    state.doc.layers.push(layer);
    if (opts.select) {
      selectLayer(layer.id, { silent: !!opts.silent });
      if (opts.silent) renderInspector();
    }
    if (!opts.silent) {
      render();
      renderLayersPanel();
      markDirty();
    }
  }

  function removeLayer(id) {
    const idx = state.doc.layers.findIndex((l) => l.id === id);
    if (idx < 0) return;
    pushHistory();
    state.doc.layers.splice(idx, 1);
    if (state.selectedId === id) {
      state.selectedId = (state.doc.layers[Math.min(idx, state.doc.layers.length - 1)] || {}).id || null;
    }
    render();
    renderLayersPanel();
    updateContextBar();
    renderInspector();
    markDirty();
  }

  function deleteSelected() {
    if (!state.selectedId) return;
    if (state.tool === "text" || state.tool === "shape") return; // don't nuke while creating
    removeLayer(state.selectedId);
  }

  function duplicateLayer() {
    const layer = selectedLayer();
    if (!layer) return toast("Select a layer first", true);
    pushHistory();
    const clone = {
      ...layer,
      id: PFProject.uid("lyr"),
      name: layer.name + " copy",
      content: layer.content ? cloneCanvas(layer.content) : null,
      effects: layer.effects ? JSON.parse(JSON.stringify(layer.effects)) : null,
    };
    const idx = state.doc.layers.findIndex((l) => l.id === layer.id);
    state.doc.layers.splice(idx + 1, 0, clone);
    selectLayer(clone.id, { silent: true });
    render();
    renderLayersPanel();
    renderInspector();
    markDirty();
  }

  function moveLayer(dir) {
    const idx = state.doc.layers.findIndex((l) => l.id === state.selectedId);
    const to = idx + dir;
    if (idx < 0 || to < 0 || to >= state.doc.layers.length) return;
    pushHistory();
    const [l] = state.doc.layers.splice(idx, 1);
    state.doc.layers.splice(to, 0, l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function layerThumb(layer) {
    if (!layer.content) return "";
    const scale = Math.min(1, 34 / Math.max(layer.content.width, layer.content.height));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(layer.content.width * scale));
    c.height = Math.max(1, Math.round(layer.content.height * scale));
    c.getContext("2d").drawImage(layer.content, 0, 0, c.width, c.height);
    return c.toDataURL("image/png");
  }

  let dragLayerId = null;

  function reorderLayer(fromId, toId) {
    const layers = state.doc.layers;
    const fromIdx = layers.findIndex((l) => l.id === fromId);
    const toIdx = layers.findIndex((l) => l.id === toId);
    if (fromIdx < 0 || toIdx < 0 || fromIdx === toIdx) return;
    pushHistory();
    const [moved] = layers.splice(fromIdx, 1);
    layers.splice(layers.findIndex((l) => l.id === toId), 0, moved);
    render();
    renderLayersPanel();
    markDirty();
  }

  function renderLayersPanel() {
    if (!state.layersTabActive) return;
    const list = els.layersList;
    list.innerHTML = "";
    if (!state.doc.layers.length) {
      list.innerHTML = '<div class="hint">No layers yet — add an image, text or shape to get started.</div>';
    }
    for (let i = state.doc.layers.length - 1; i >= 0; i--) {
      const layer = state.doc.layers[i];
      const row = document.createElement("div");
      row.className = "layer-row" + (layer.id === state.selectedId ? " selected" : "");
      row.draggable = true;
      row.innerHTML = `
        <span class="layer-drag">${PFIcons.svg("grip")}</span>
        <button class="layer-eye">${PFIcons.svg(layer.visible ? "eye" : "eye-off")}</button>
        <div class="layer-thumb"><img src="${layerThumb(layer)}" alt="" draggable="false"></div>
        <div class="layer-meta">
          <div class="layer-name"></div>
          <div class="layer-type">${layer.type}</div>
        </div>`;
      row.querySelector(".layer-name").textContent = layer.name;
      row.querySelector(".layer-eye").addEventListener("click", (ev) => {
        ev.stopPropagation();
        layer.visible = !layer.visible;
        render();
        renderLayersPanel();
        markDirty();
      });
      row.addEventListener("click", () => selectLayer(layer.id));
      row.addEventListener("dblclick", () => {
        if (layer.type === "text") openTextEditor(layer);
      });
      row.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        selectLayer(layer.id);
        openLayerContextMenu(ev.clientX, ev.clientY, layer);
      });
      row.addEventListener("dragstart", (ev) => {
        dragLayerId = layer.id;
        ev.dataTransfer.effectAllowed = "move";
        ev.dataTransfer.setData("text/plain", layer.id);
      });
      row.addEventListener("dragover", (ev) => {
        if (!dragLayerId || dragLayerId === layer.id) return;
        ev.preventDefault();
        row.classList.add("drag-over");
      });
      row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
      row.addEventListener("drop", (ev) => {
        ev.preventDefault();
        row.classList.remove("drag-over");
        if (!dragLayerId || dragLayerId === layer.id) return;
        reorderLayer(dragLayerId, layer.id);
        dragLayerId = null;
      });
      row.addEventListener("dragend", () => {
        dragLayerId = null;
        list.querySelectorAll(".layer-row.drag-over").forEach((r) => r.classList.remove("drag-over"));
      });
      list.appendChild(row);
    }
    const sel = selectedLayer();
    els.layerOpacity.value = sel ? Math.round(sel.opacity * 100) : 100;
    els.layerOpacityVal.textContent = sel ? Math.round(sel.opacity * 100) : 100;
  }

  // ================================================================== zoom / pan
  function applyZoom() {
    const z = state.zoom;
    els.stage.style.transform = `scale(${z})`;
    const pad = 60;
    els.stageWrap.style.width = `${state.doc.width * z + pad * 2}px`;
    els.stageWrap.style.height = `${state.doc.height * z + pad * 2}px`;
    els.stage.style.left = `${pad}px`;
    els.stage.style.top = `${pad}px`;
    els.zoomLabel.textContent = `${Math.round(z * 100)}%`;
    els.hudZoom.textContent = `${Math.round(z * 100)}%`;
    updateBrushCursor();
  }

  function zoomFit() {
    const w = els.workspace.clientWidth - 80;
    const h = els.workspace.clientHeight - 80;
    state.zoom = clamp(Math.min(w / state.doc.width, h / state.doc.height), 0.02, 2);
    applyZoom();
    els.workspace.scrollLeft = Math.max(0, (els.stageWrap.clientWidth - els.workspace.clientWidth) / 2);
    els.workspace.scrollTop = Math.max(0, (els.stageWrap.clientHeight - els.workspace.clientHeight) / 2);
  }

  function zoomAt(clientX, clientY, factor) {
    const z0 = state.zoom;
    const z1 = clamp(z0 * factor, 0.05, 8);
    if (z1 === z0) return;
    const r0 = els.stage.getBoundingClientRect();
    const dx = (clientX - r0.left) / z0;
    const dy = (clientY - r0.top) / z0;
    state.zoom = z1;
    applyZoom();
    const r1 = els.stage.getBoundingClientRect();
    els.workspace.scrollLeft += clientX - r1.left - dx * z1;
    els.workspace.scrollTop += clientY - r1.top - dy * z1;
    updateHud();
  }

  /** Zoom centered on a document point (used by the zoom tool). */
  function zoomTo(pt, factor) {
    const r = els.stage.getBoundingClientRect();
    zoomAt(r.left + pt.x * state.zoom, r.top + pt.y * state.zoom, factor);
  }

  function panBy(dx, dy) {
    els.workspace.scrollLeft += dx;
    els.workspace.scrollTop += dy;
  }

  function docPoint(e) {
    const r = els.stage.getBoundingClientRect();
    return { x: (e.clientX - r.left) / state.zoom, y: (e.clientY - r.top) / state.zoom };
  }

  function updateBrushCursor() {
    const show = state.tool === "brush" || state.tool === "eraser" || state.tool === "blur" || state.tool === "stamp";
    els.brushCursor.style.display = show ? "block" : "none";
    if (show) {
      const d = Math.max(6, state.toolOptions.size * 2 * state.zoom);
      els.brushCursor.style.width = d + "px";
      els.brushCursor.style.height = d + "px";
      if (state.tool === "blur" || state.tool === "stamp") {
        els.brushCursor.style.borderColor = state.tool === "blur" ? "#d29d3f" : "#3fb37f";
        els.brushCursor.style.boxShadow = "0 0 0 1px rgba(0,0,0,0.5)";
      } else {
        els.brushCursor.style.borderColor = "#3b82f6";
        els.brushCursor.style.boxShadow = "0 0 0 1px rgba(0,0,0,0.5)";
      }
    }
  }

  // ================================================================== tools
  const editorApi = {
    get doc() { return state.doc; },
    get canvas() { return els.docCanvas; },
    get previewCanvas() { return els.previewCanvas; },
    get zoom() { return state.zoom; },
    get toolOptions() { return state.toolOptions; },
    getSelected: () => selectedLayer(),
    getLayer: (id) => layerById(id),
    selectLayer: (id, o) => selectLayer(id, o),
    addLayer: (l, o) => addLayer(l, o),
    removeLayer: (id) => removeLayer(id),
    pushHistory: () => pushHistory(),
    markDirty: () => markDirty(),
    render: () => render(),
    refreshOverlay: () => refreshOverlay(),
    hitSelectionHandle: (pt) => hitSelectionHandle(pt),
    setColor: (hex) => setColor(hex),
    get previousPaintTool() { return state.previousPaintTool; },
    setTool: (id) => setTool(id),
    openTextEditor: (layer) => openTextEditor(layer),
    updateCropOverlay: (r) => updateCropOverlay(r),
    showCropBar: () => updateContextBar(),
    clearCrop: () => clearCrop(),
    applyCrop: (r) => applyCrop(r),
    panBy: (dx, dy) => panBy(dx, dy),
    zoomTo: (pt, factor) => zoomTo(pt, factor),
    toast: (m, e) => toast(m, e),
  };

  function setTool(id) {
    clearHover();
    els.workspace.style.cursor = "default";
    if (state.tool === "crop" && id !== "crop") clearCrop();
    if (state.toolInstance && state.toolInstance.deactivate) {
      try { state.toolInstance.deactivate(); } catch { /* noop */ }
    }
    state.tool = id;
    if (id === "brush" || id === "eraser") state.previousPaintTool = id;
    state.toolInstance = PFTools.createTool(id, editorApi);
    document.querySelectorAll("#leftBar .tool-btn").forEach((b) => b.classList.toggle("active", b.dataset.tool === id));
    updateContextBar();
    updateBrushCursor();
    updateHudTool();
  }

  function updateHudTool() {
    const t = PFTools.TOOLS.find((x) => x.id === state.tool);
    if (!t) return;
    els.hudTool.textContent = t.name;
    els.hudHint.textContent = t.desc || "";
  }

  function renderToolRail() {
    els.leftBar.innerHTML = "";
    PFTools.TOOLS.forEach((t) => {
      const btn = document.createElement("button");
      btn.className = "tool-btn";
      btn.dataset.tool = t.id;
      btn.dataset.tip = `${t.name}|${t.desc || ""}|${t.kbd}`;
      btn.innerHTML = `${t.icon}<span class="kbd">${t.kbd}</span>`;
      btn.addEventListener("click", () => setTool(t.id));
      els.leftBar.appendChild(btn);
    });
  }

  // ---------------------------------------------------------------- context bar
  function updateContextBar() {
    const bar = els.contextBar;
    bar.innerHTML = "";
    bar.classList.remove("hidden");
    const t = state.tool;
    if (t === "brush" || t === "eraser") buildBrushContext(bar);
    else if (t === "shape") buildShapeContext(bar);
    else if (t === "move") buildMoveContext(bar);
    else if (t === "text") buildTextContext(bar);
    else if (t === "crop") buildCropContext(bar);
    else if (t === "fill") buildFillContext(bar);
    else if (t === "gradient") buildGradientContext(bar);
    else if (t === "blur") buildSizeContext(bar, "Blur brush", "radius");
    else if (t === "stamp") buildStampContext(bar);
    else if (t === "zoom") {
      bar.innerHTML = '<span class="cb-hint">Click to zoom in · Alt-click (or right-click) to zoom out · scroll anywhere to zoom</span>';
    } else {
      bar.innerHTML = '<span class="cb-hint">Drag to pan · scroll to zoom</span>';
    }
  }

  function sliderFill(input) {
    const min = parseFloat(input.min) || 0;
    const max = parseFloat(input.max) || 100;
    const pct = ((parseFloat(input.value) - min) / (max - min)) * 100;
    input.style.setProperty("--fill", `${pct}%`);
  }

  function buildBrushContext(bar) {
    const erasing = state.tool === "eraser";
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${erasing ? "Eraser" : "Brush"}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Colour</label><input type="color" id="ctxColor" value="${o.color}"></div>
      <div class="cb-item"><label>Size</label><input type="range" id="ctxSize" min="2" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
      <div class="cb-item"><label>Softness</label><input type="range" id="ctxHard" min="0" max="100" value="${Math.round(o.hardness * 100)}"><span class="cb-val">${Math.round(o.hardness * 100)}</span></div>
      ${erasing ? "" : `<div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="10" max="100" value="${Math.round(o.opacity * 100)}"><span class="cb-val">${Math.round(o.opacity * 100)}</span></div>`}
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxColor").addEventListener("input", (e) => setColor(e.target.value));
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
    bar.querySelector("#ctxHard").addEventListener("input", (e) => {
      o.hardness = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
    const op = bar.querySelector("#ctxOp");
    if (op) op.addEventListener("input", (e) => {
      o.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
  }

  function buildShapeContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Shape</span></div>
      <div class="cb-item">
        <select id="ctxKind">
          ${PFTools.SHAPE_KINDS.map(([k, ic, name]) => `<option value="${k}" ${o.shapeKind === k ? "selected" : ""}>${ic} ${name}</option>`).join("")}
        </select>
      </div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Fill</label><input type="color" id="ctxFill" value="${o.fill}"></div>
      <div class="cb-item"><label>Outline</label><input type="color" id="ctxStroke" value="${o.stroke}"></div>
      <div class="cb-item"><label>Weight</label><input type="range" id="ctxSw" min="0" max="40" value="${o.strokeWidth}"><span class="cb-val">${o.strokeWidth}</span></div>
      <div class="cb-item" id="ctxPointsWrap"><label>Points</label><input type="range" id="ctxPoints" min="3" max="12" value="${o.points}"><span class="cb-val">${o.points}</span></div>
      <div class="cb-item" id="ctxRadiusWrap"><label>Radius</label><input type="range" id="ctxRadius" min="0" max="200" value="${o.radius}"><span class="cb-val">${o.radius}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    const syncExtras = () => {
      const star = o.shapeKind === "star";
      bar.querySelector("#ctxPointsWrap").style.display = star ? "flex" : "none";
      const rect = o.shapeKind === "rect";
      bar.querySelector("#ctxRadiusWrap").style.display = rect ? "flex" : "none";
    };
    bar.querySelector("#ctxKind").addEventListener("change", (e) => {
      o.shapeKind = e.target.value;
      syncExtras();
    });
    bar.querySelector("#ctxFill").addEventListener("input", (e) => { o.fill = e.target.value; });
    bar.querySelector("#ctxStroke").addEventListener("input", (e) => { o.stroke = e.target.value; });
    bar.querySelector("#ctxSw").addEventListener("input", (e) => {
      o.strokeWidth = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.strokeWidth;
    });
    bar.querySelector("#ctxPoints").addEventListener("input", (e) => {
      o.points = parseInt(e.target.value, 10);
      e.target.nextElementSibling.textContent = o.points;
    });
    bar.querySelector("#ctxRadius").addEventListener("input", (e) => {
      o.radius = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.radius;
    });
    syncExtras();
  }

  function buildFillContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Fill bucket</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Colour</label><input type="color" id="ctxColor" value="${o.color}"></div>
      <div class="cb-item"><label>Tolerance</label><input type="range" id="ctxTol" min="0" max="100" value="${o.tolerance}"><span class="cb-val">${o.tolerance}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxColor").addEventListener("input", (e) => setColor(e.target.value));
    bar.querySelector("#ctxTol").addEventListener("input", (e) => {
      o.tolerance = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.tolerance;
    });
  }

  function buildGradientContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Gradient</span></div>
      <div class="cb-item"><div class="seg" id="ctxGrad">
        <button class="seg-btn ${o.gradType === "linear" ? "active" : ""}" data-grad="linear">Linear</button>
        <button class="seg-btn ${o.gradType === "radial" ? "active" : ""}" data-grad="radial">Radial</button>
      </div></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>From</label><input type="color" id="ctxG1" value="${o.color}"></div>
      <div class="cb-item"><label>To</label><input type="color" id="ctxG2" value="${o.color2}"></div>
    `;
    bar.querySelectorAll("#ctxGrad .seg-btn").forEach((b) => b.addEventListener("click", () => {
      o.gradType = b.dataset.grad;
      bar.querySelectorAll("#ctxGrad .seg-btn").forEach((x) => x.classList.toggle("active", x === b));
    }));
    bar.querySelector("#ctxG1").addEventListener("input", (e) => { o.color = e.target.value; });
    bar.querySelector("#ctxG2").addEventListener("input", (e) => { o.color2 = e.target.value; });
  }

  function buildSizeContext(bar, label, unit = "size") {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${label}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>${unit[0].toUpperCase() + unit.slice(1)}</label><input type="range" id="ctxSize" min="4" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
  }

  function buildStampContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Clone stamp</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Size</label><input type="range" id="ctxSize" min="4" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
      <div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="10" max="100" value="${Math.round(o.opacity * 100)}"><span class="cb-val">${Math.round(o.opacity * 100)}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
    bar.querySelector("#ctxOp").addEventListener("input", (e) => {
      o.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
  }

  function applyTextControl(kind, value) {
    const layer = selectedLayer();
    const defs = state.toolOptions.textDefaults;
    if (layer && layer.type === "text") {
      pushHistory();
      layer[kind] = value;
      PFEngine.renderContent(layer);
      render();
      renderLayersPanel();
      markDirty();
    } else {
      defs[kind] = value;
    }
  }

  function buildTextContext(bar) {
    const layer = selectedLayer();
    const src = layer && layer.type === "text" ? layer : state.toolOptions.textDefaults;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Text</span></div>
      <div class="cb-item">
        <select id="ctxFont">
          ${FONTS.map((f) => `<option value="${f}" ${src.fontFamily === f ? "selected" : ""}>${f}</option>`).join("")}
        </select>
      </div>
      <div class="cb-item"><label>Size</label><input type="number" id="ctxFontSize" min="8" max="400" value="${src.fontSize}" style="width:64px;background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:5px 8px;color:var(--text)"></div>
      <div class="cb-item"><input type="color" id="ctxTextColor" value="${src.color}"></div>
      <div class="cb-item"><div class="seg" id="ctxStyle">
        <button class="seg-btn ${src.fontWeight >= 700 ? "active" : ""}" data-sty="bold" title="Bold"><b>B</b></button>
        <button class="seg-btn ${src.fontStyle === "italic" ? "active" : ""}" data-sty="italic" title="Italic"><i>I</i></button>
      </div></div>
      <div class="cb-item"><button class="btn ghost" id="ctxEditText">${PFIcons.svg("edit")} Edit text</button></div>
    `;
    bar.querySelector("#ctxFont").addEventListener("change", (e) => applyTextControl("fontFamily", e.target.value));
    bar.querySelector("#ctxFontSize").addEventListener("change", (e) => applyTextControl("fontSize", clamp(parseInt(e.target.value, 10) || 24, 8, 400)));
    bar.querySelector("#ctxTextColor").addEventListener("change", (e) => applyTextControl("color", e.target.value));
    bar.querySelectorAll("#ctxStyle .seg-btn").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.sty === "bold") applyTextControl("fontWeight", src.fontWeight >= 700 ? 400 : 700);
      else applyTextControl("fontStyle", src.fontStyle === "italic" ? "normal" : "italic");
      updateContextBar();
    }));
    bar.querySelector("#ctxEditText").addEventListener("click", () => {
      if (layer && layer.type === "text") openTextEditor(layer);
      else toast("Add a text layer first", true);
    });
  }

  function buildMoveContext(bar) {
    const layer = selectedLayer();
    if (!layer) {
      bar.innerHTML = '<span class="cb-hint">Select a layer to edit it · drag empty space to pan · double-click text to edit</span>';
      return;
    }
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${layer.name}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="5" max="100" value="${Math.round(layer.opacity * 100)}"><span class="cb-val">${Math.round(layer.opacity * 100)}</span></div>
      <div class="cb-item"><button class="btn ghost" id="ctxDup">${PFIcons.svg("duplicate")} Duplicate</button></div>
      <div class="cb-item"><button class="btn danger" id="ctxDel">${PFIcons.svg("trash")} Delete</button></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxOp").addEventListener("input", (e) => {
      layer.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
      render();
    });
    bar.querySelector("#ctxOp").addEventListener("change", () => { pushHistory(); markDirty(); });
    bar.querySelector("#ctxDup").addEventListener("click", duplicateLayer);
    bar.querySelector("#ctxDel").addEventListener("click", () => removeLayer(layer.id));
  }

  function buildCropContext(bar) {
    if (state.cropRect) {
      bar.innerHTML = `
        <div class="cb-item"><span class="cb-label">Crop</span></div>
        <div class="cb-item"><span class="cb-hint">${Math.round(state.cropRect.w)} × ${Math.round(state.cropRect.h)}px</span></div>
        <div class="cb-sep"></div>
        <div class="cb-item"><button class="btn primary" id="ctxApply">Apply crop</button></div>
        <div class="cb-item"><button class="btn ghost" id="ctxCancel">Cancel</button></div>
      `;
      bar.querySelector("#ctxApply").addEventListener("click", () => state.toolInstance.apply());
      bar.querySelector("#ctxCancel").addEventListener("click", () => { state.toolInstance.cancel(); });
    } else {
      bar.innerHTML = '<span class="cb-hint">Drag to select a crop area · drag corners to resize · drag inside to move · Enter to apply</span>';
    }
  }

  function setColor(hex) {
    state.toolOptions.color = hex;
    const c = els.contextBar.querySelector("#ctxColor");
    if (c) c.value = hex;
  }

  // ================================================================== crop
  function updateCropOverlay(rect) {
    state.cropRect = rect;
    els.cropOverlay.style.display = "block";
    const mask = els.cropOverlay.querySelector(".crop-mask");
    mask.style.cssText = `left:${rect.x}px;top:${rect.y}px;width:${rect.w}px;height:${rect.h}px;`;
    const hs = els.cropOverlay.querySelectorAll(".crop-handle");
    hs[0].style.cssText = `left:${rect.x}px;top:${rect.y}px;`;
    hs[1].style.cssText = `left:${rect.x + rect.w}px;top:${rect.y}px;`;
    hs[2].style.cssText = `left:${rect.x}px;top:${rect.y + rect.h}px;`;
    hs[3].style.cssText = `left:${rect.x + rect.w}px;top:${rect.y + rect.h}px;`;
  }

  function clearCrop() {
    state.cropRect = null;
    els.cropOverlay.style.display = "none";
    updateContextBar();
  }

  function applyCrop(rect) {
    const doc = state.doc;
    const r = {
      x: clamp(Math.round(rect.x), 0, doc.width - 1),
      y: clamp(Math.round(rect.y), 0, doc.height - 1),
      w: Math.max(1, Math.min(doc.width, Math.round(rect.w))),
      h: Math.max(1, Math.min(doc.height, Math.round(rect.h))),
    };
    if (r.w < 2 || r.h < 2) return;
    pushHistory();
    for (const layer of doc.layers) {
      if (layer.fullCanvas && layer.content) {
        const c = document.createElement("canvas");
        c.width = r.w;
        c.height = r.h;
        c.getContext("2d").drawImage(layer.content, -r.x, -r.y);
        layer.content = c;
        layer.transform = { x: r.w / 2, y: r.h / 2, rotation: 0, scaleX: 1, scaleY: 1 };
      } else {
        layer.transform.x -= r.x;
        layer.transform.y -= r.y;
      }
    }
    doc.width = r.w;
    doc.height = r.h;
    setupCanvas(false);
    render();
    renderLayersPanel();
    markDirty();
    toast(`Cropped to ${r.w} × ${r.h}`);
  }

  // ================================================================== text popover
  function openTextEditor(layer, opts = {}) {
    if (!layer || layer.type !== "text") return;
    if (state.textPopOpen) closeTextEditor();
    if (opts.push !== false) pushHistory();
    state.textPopOpen = true;
    state.textPopOrig = layer.text;
    els.textPopInput.value = layer.text;
    els.textPop.classList.remove("hidden");

    const wrapR = els.workspaceWrap.getBoundingClientRect();
    const stageR = els.stage.getBoundingClientRect();
    let left = stageR.left - wrapR.left + layer.transform.x * state.zoom - 150;
    let top = stageR.top - wrapR.top + layer.transform.y * state.zoom + 24;
    left = clamp(left, 8, Math.max(8, wrapR.width - 320));
    top = clamp(top, 8, Math.max(8, wrapR.height - 140));
    els.textPop.style.left = left + "px";
    els.textPop.style.top = top + "px";

    els.textPopInput.oninput = () => {
      layer.text = els.textPopInput.value;
      PFEngine.renderContent(layer);
      render();
    };
    els.textPopInput.onkeydown = (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); closeTextEditor(); }
      if (e.key === "Escape") { e.stopPropagation(); layer.text = state.textPopOrig; PFEngine.renderContent(layer); render(); closeTextEditor(); }
    };
    els.textPopInput.onblur = () => {
      // Don't close when focus just moved to the context bar (font controls etc).
      setTimeout(() => {
        const t = document.activeElement;
        if (t && (els.textPop.contains(t) || els.contextBar.contains(t))) return;
        closeTextEditor();
      }, 120);
    };
    els.textPopInput.focus();
    els.textPopInput.select();
  }

  function closeTextEditor() {
    if (!state.textPopOpen) return;
    state.textPopOpen = false;
    els.textPop.classList.add("hidden");
    renderLayersPanel();
    markDirty();
  }

  // ================================================================== filters / adjustments
  function renderPresets() {
    els.presetGrid.innerHTML = "";
    PFFilters.PRESETS.forEach((p) => {
      const chip = document.createElement("button");
      chip.className = "preset-chip";
      chip.innerHTML = `<span class="p-icon">${p.name.slice(0, 1)}</span><span class="p-name">${p.name}</span>`;
      chip.addEventListener("click", () => applyPresetToSelected(p.id));
      els.presetGrid.appendChild(chip);
    });
  }

  function applyPresetToSelected(presetId) {
    const layer = selectedLayer();
    if (!layer || !layer.content) return toast("Select a layer first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, layer);
    const out = PFFilters.applyPreset(src.content, presetId);
    pushHistory();
    replaceLayerContent(layer, out);
    toast("Filter applied");
  }

  function applyAdjustments() {
    const layer = selectedLayer();
    if (!layer || !layer.content) return toast("Select a layer first", true);
    const fx = {
      brightness: 1 + state.fx.brightness / 100,
      contrast: 1 + state.fx.contrast / 100,
      saturate: 1 + state.fx.saturate / 100,
      hue: state.fx.hue,
      blur: state.fx.blur,
    };
    const sharpen = state.fx.sharpen;
    const any = fx.brightness !== 1 || fx.contrast !== 1 || fx.saturate !== 1 || fx.hue !== 0 || fx.blur !== 0 || sharpen > 0;
    if (!any) return toast("Nothing to apply — move a slider first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, layer);
    const out = PFFilters.adjustCanvas(src.content, fx, sharpen);
    pushHistory();
    replaceLayerContent(layer, out);
    toast("Adjustments applied");
  }

  function replaceLayerContent(layer, canvas) {
    const idx = state.doc.layers.findIndex((l) => l.id === layer.id);
    if (idx < 0) return;
    const nl = PFEngine.makeFullCanvasLayer(canvas, { name: layer.name });
    nl.id = layer.id;
    // opacity was already baked into the flattened pixels
    state.doc.layers[idx] = nl;
    selectLayer(nl.id, { silent: true });
    render();
    renderLayersPanel();
    markDirty();
  }

  function resetFxSliders() {
    state.fx = { brightness: 0, contrast: 0, saturate: 0, hue: 0, blur: 0, sharpen: 0 };
    Object.entries(state.fx).forEach(([k, v]) => {
      const slider = els["fx" + k.charAt(0).toUpperCase() + k.slice(1)];
      if (slider) { slider.value = v; sliderFill(slider); }
      const val = els["v" + k.charAt(0).toUpperCase() + k.slice(1)];
      if (val) val.textContent = v;
    });
  }

  // ================================================================== tooltips
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  }

  function initTooltips() {
    const tip = els.tooltip;
    let timer = null;
    let current = null;

    function hideTip() {
      tip.classList.add("hidden");
    }

    function showTip(el) {
      const [title, desc, kbd] = String(el.dataset.tip || "").split("|");
      if (!title && !desc) return hideTip();
      tip.innerHTML =
        `<div class="tooltip-title"><span>${escapeHtml(title)}</span>${kbd ? `<span class="tooltip-kbd">${escapeHtml(kbd)}</span>` : ""}</div>` +
        (desc ? `<div class="tooltip-desc">${escapeHtml(desc)}</div>` : "");
      tip.classList.remove("hidden");
    }

    function moveTip(e) {
      if (tip.classList.contains("hidden")) return;
      const pad = 14;
      let x = e.clientX + pad;
      let y = e.clientY + pad;
      const r = tip.getBoundingClientRect();
      if (x + r.width > window.innerWidth - 8) x = e.clientX - r.width - pad;
      if (y + r.height > window.innerHeight - 8) y = e.clientY - r.height - pad;
      tip.style.left = Math.max(6, x) + "px";
      tip.style.top = Math.max(6, y) + "px";
    }

    document.addEventListener("pointerover", (e) => {
      const el = e.target.closest ? e.target.closest("[data-tip]") : null;
      if (!el) {
        clearTimeout(timer);
        if (current) { current = null; hideTip(); }
        return;
      }
      if (el === current) return;
      clearTimeout(timer);
      current = el;
      timer = setTimeout(() => { showTip(el); moveTip(e); }, 240);
    });
    document.addEventListener("pointermove", (e) => { if (current) moveTip(e); });
    document.addEventListener("pointerout", (e) => {
      const el = e.target.closest ? e.target.closest("[data-tip]") : null;
      if (el !== current) return;
      // Moving between children (icon → kbd) of the same button shouldn't hide.
      const rt = e.relatedTarget;
      const stillInside = rt && rt.closest && rt.closest("[data-tip]") === el;
      if (!stillInside) {
        clearTimeout(timer);
        current = null;
        hideTip();
      }
    });
  }

  // ================================================================== item inspector
  const FX_MAP = {
    shadow: {
      color: { id: "fxShadowColor", toLayer: (v) => v, toUI: (v) => v },
      blur: { id: "fxShadowBlur", toLayer: (v) => v, toUI: (v) => v },
      x: { id: "fxShadowX", toLayer: (v) => v, toUI: (v) => v },
      y: { id: "fxShadowY", toLayer: (v) => v, toUI: (v) => v },
      opacity: { id: "fxShadowOp", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
    },
    border: {
      color: { id: "fxBorderColor", toLayer: (v) => v, toUI: (v) => v },
      width: { id: "fxBorderWidth", toLayer: (v) => v, toUI: (v) => v },
      radius: { id: "fxBorderRadius", toLayer: (v) => v, toUI: (v) => v },
    },
    reflection: {
      opacity: { id: "fxReflOp", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
      gap: { id: "fxReflGap", toLayer: (v) => v, toUI: (v) => v },
      height: { id: "fxReflH", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
    },
    bg: {
      color: { id: "fxBgColor", toLayer: (v) => v, toUI: (v) => v },
      radius: { id: "fxBgRadius", toLayer: (v) => v, toUI: (v) => v },
    },
  };

  function bindInspector() {
    const num = (id, apply) => {
      const el = els[id];
      el.addEventListener("input", () => {
        const l = selectedLayer();
        if (!l) return;
        const v = parseFloat(el.value);
        if (!Number.isFinite(v)) return;
        apply(l, v);
        render();
      });
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    num("inspX", (l, v) => { l.transform.x = v; });
    num("inspY", (l, v) => { l.transform.y = v; });
    num("inspW", (l, v) => { const c = l.content; if (c) l.transform.scaleX = v / c.width; });
    num("inspH", (l, v) => { const c = l.content; if (c) l.transform.scaleY = v / c.height; });
    num("inspRot", (l, v) => { l.transform.rotation = (v * Math.PI) / 180; });
    num("inspOp", (l, v) => { l.opacity = clamp(v / 100, 0.05, 1); });

    els.inspFlipX.addEventListener("click", () => commitLayer((l) => { l.transform.scaleX *= -1; }));
    els.inspFlipY.addEventListener("click", () => commitLayer((l) => { l.transform.scaleY *= -1; }));
    els.inspRotL.addEventListener("click", () => commitLayer((l) => { l.transform.rotation -= Math.PI / 2; }));
    els.inspRotR.addEventListener("click", () => commitLayer((l) => { l.transform.rotation += Math.PI / 2; }));

    els.inspEye.addEventListener("click", () => {
      const l = selectedLayer();
      if (!l) return;
      l.visible = !l.visible;
      render();
      renderLayersPanel();
      markDirty();
    });
    els.inspDup.addEventListener("click", duplicateLayer);
    els.inspDel.addEventListener("click", () => { if (state.selectedId) removeLayer(state.selectedId); });
    els.inspReturn.addEventListener("click", () => selectLayer(null));

    els.inspToFront.addEventListener("click", () => moveToEdge(state.doc.layers.length - 1));
    els.inspFwd.addEventListener("click", () => moveLayer(1));
    els.inspBack.addEventListener("click", () => moveLayer(-1));
    els.inspToBack.addEventListener("click", () => moveToEdge(0));

    document.querySelectorAll("#inspector [data-align]").forEach((b) => b.addEventListener("click", () => alignLayer(b.dataset.align)));

    // effect groups
    document.querySelectorAll(".fx-group").forEach((g) => {
      const fxName = g.dataset.fx;
      const onInput = g.querySelector("input[type=checkbox]");
      const head = g.querySelector(".fx-head");
      head.addEventListener("click", (e) => {
        // The switch <label> natively toggles the checkbox (its <input> is a
        // descendant, so e.target.closest("label") is set). Calling
        // onInput.click() for label clicks would toggle it TWICE and cancel
        // the effect out. Only clicks outside the label toggle manually.
        if (!e.target.closest("label")) onInput.click();
      });
      onInput.addEventListener("change", () => {
        const l = selectedLayer();
        if (!l) return;
        if (onInput.checked && l.fullCanvas) {
          // Full-canvas layers (brush strokes, filtered images) fill the whole
          // document, so shadows/reflections would extend past the canvas and
          // look invisible. Trim to the item's actual pixels first.
          if (PFEngine.trimToContent(l)) l.fullCanvas = false;
        }
        l.effects[fxName].on = onInput.checked;
        g.classList.toggle("on", onInput.checked);
        pushHistory();
        render();
        renderLayersPanel();
        markDirty();
      });
      Object.entries(FX_MAP[fxName]).forEach(([prop, cfg]) => {
        const input = $(cfg.id);
        input.addEventListener("input", () => {
          const l = selectedLayer();
          if (!l) return;
          l.effects[fxName][prop] = cfg.toLayer(input.type === "color" ? input.value : parseFloat(input.value));
          render();
        });
        input.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
      });
    });
  }

  function commitLayer(fn) {
    const l = selectedLayer();
    if (!l) return;
    pushHistory();
    fn(l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function moveToEdge(index) {
    const idx = state.doc.layers.findIndex((l) => l.id === state.selectedId);
    if (idx < 0 || idx === index) return;
    pushHistory();
    const [l] = state.doc.layers.splice(idx, 1);
    state.doc.layers.splice(index, 0, l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function alignLayer(dir) {
    const l = selectedLayer();
    if (!l || !l.content) return;
    const corners = PFEngine.layerCorners(l);
    if (!corners.length) return;
    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const bw = maxX - minX, bh = maxY - minY;
    const dx = dir === "left" ? -minX
      : dir === "center" ? (state.doc.width - bw) / 2 - minX
        : dir === "right" ? state.doc.width - bw - minX : 0;
    const dy = dir === "top" ? -minY
      : dir === "middle" ? (state.doc.height - bh) / 2 - minY
        : dir === "bottom" ? state.doc.height - bh - minY : 0;
    pushHistory();
    l.transform.x += dx;
    l.transform.y += dy;
    render();
    markDirty();
  }

  function applyTextProp(kind, value, history = true) {
    const layer = selectedLayer();
    if (!layer || layer.type !== "text") return;
    if (history) pushHistory();
    layer[kind] = value;
    PFEngine.renderContent(layer);
    render();
    syncInspector();
    if (history) markDirty();
  }

  function applyShapeProp(kind, value, history = true) {
    const layer = selectedLayer();
    if (!layer || layer.type !== "shape") return;
    if (history) pushHistory();
    layer[kind] = value;
    PFEngine.renderContent(layer);
    render();
    syncInspector();
    if (history) markDirty();
  }

  function renderInspector() {
    const l = selectedLayer();
    if (!l) {
      els.inspector.classList.add("hidden");
      els.rightPanel.classList.remove("hidden");
      return;
    }
    els.inspector.classList.remove("hidden");
    els.rightPanel.classList.add("hidden"); // the two share one dock slot — only one shows at a time
    l.effects = PFEngine.mergeEffects(l.effects);

    els.inspIcon.innerHTML = PFIcons.svg(l.type === "text" ? "text" : l.type === "shape" ? "shape" : "image");
    els.inspName.textContent = l.name;
    els.inspType.textContent = l.type === "raster" ? (l.fullCanvas ? "image layer" : "image") : l.type;
    els.inspEye.innerHTML = PFIcons.svg(l.visible ? "eye" : "eye-off");

    els.inspTypeSection.innerHTML = "";
    const sec = els.inspTypeSection;
    if (l.type === "text") buildInspectorText(sec, l);
    else if (l.type === "shape") buildInspectorShape(sec, l);
    else buildInspectorImage(sec, l);

    syncInspector();
  }

  function syncInspector() {
    const l = selectedLayer();
    if (!l || els.inspector.classList.contains("hidden")) return;
    const t = l.transform;
    const fx = l.effects || {};
    const set = (el, v) => { if (document.activeElement !== el) el.value = v; };
    set(els.inspX, Math.round(t.x * 10) / 10);
    set(els.inspY, Math.round(t.y * 10) / 10);
    const c = l.content;
    if (c) {
      set(els.inspW, Math.round(c.width * Math.abs(t.scaleX) * 10) / 10);
      set(els.inspH, Math.round(c.height * Math.abs(t.scaleY) * 10) / 10);
    }
    set(els.inspRot, Math.round(((t.rotation * 180) / Math.PI) * 10) / 10);
    set(els.inspOp, Math.round(l.opacity * 100));
    els.inspEye.innerHTML = PFIcons.svg(l.visible ? "eye" : "eye-off");

    for (const fxName of Object.keys(FX_MAP)) {
      const g = document.querySelector(`.fx-group[data-fx="${fxName}"]`);
      if (!g) continue;
      const e = fx[fxName] || {};
      const on = g.querySelector("input[type=checkbox]");
      if (on.checked !== !!e.on) on.checked = !!e.on;
      g.classList.toggle("on", !!e.on);
      Object.entries(FX_MAP[fxName]).forEach(([prop, cfg]) => {
        const input = $(cfg.id);
        if (!input) return;
        const v = e[prop] == null ? (PFEngine.EFFECT_DEFAULTS[fxName] ? PFEngine.EFFECT_DEFAULTS[fxName][prop] : 0) : e[prop];
        const ui = cfg.toUI(v);
        if (document.activeElement !== input) input.value = ui;
        if (input.type === "range") sliderFill(input);
      });
    }
  }

  function buildInspectorImage(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Image</div>
      <div class="type-row2">
        <button class="ty-btn" id="inspReplace" data-tip="Replace image|Swap this item's image for another file">${PFIcons.svg("image")} Replace…</button>
        <button class="ty-btn" id="inspAiBg" data-tip="Remove background|Let AI cut out the main subject — Pro feature">${PFIcons.svg("sparkles")} Bg AI</button>
      </div>`;
    sec.querySelector("#inspReplace").addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => {
        const f = input.files[0];
        if (!f) return;
        const url = URL.createObjectURL(f);
        loadImage(url).then((img) => {
          URL.revokeObjectURL(url);
          const canvas = document.createElement("canvas");
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          canvas.getContext("2d").drawImage(img, 0, 0);
          pushHistory();
          const oldW = l.content.width * Math.abs(l.transform.scaleX);
          const oldH = l.content.height * Math.abs(l.transform.scaleY);
          l.content = canvas;
          l.transform.scaleX = oldW / canvas.width;
          l.transform.scaleY = oldH / canvas.height;
          render();
          renderLayersPanel();
          markDirty();
          toast("Image replaced");
        }).catch(() => toast("Could not load that image", true));
      };
      input.click();
    });
    sec.querySelector("#inspAiBg").addEventListener("click", () => aiEditSelection("Remove the background completely — keep only the main subject with a clean edge."));
  }

  function buildInspectorText(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Text</div>
      <div class="type-field"><label>Font</label>
        <select id="inspFont">${FONTS.map((f) => `<option value="${f}" ${l.fontFamily === f ? "selected" : ""}>${f}</option>`).join("")}</select></div>
      <div class="type-row">
        <div class="type-field"><label>Size</label><input type="number" id="inspFontSize" min="4" max="600" value="${l.fontSize}"></div>
        <div class="type-field"><label>Line height</label><input type="number" id="inspLineH" min="0.6" max="4" step="0.05" value="${l.lineHeight}"></div>
      </div>
      <div class="type-row">
        <div class="type-field"><label>Spacing</label><input type="number" id="inspSpacing" min="-4" max="40" step="0.5" value="${l.letterSpacing || 0}"></div>
        <div class="type-field"><label>Colour</label><input type="color" id="inspTextColor" value="${l.color}"></div>
      </div>
      <div class="type-field"><label>Style</label>
        <div class="seg-sm">
          <button class="${l.fontWeight >= 700 ? "active" : ""}" data-sty="bold"><b>B</b></button>
          <button class="${l.fontStyle === "italic" ? "active" : ""}" data-sty="italic"><i>I</i></button>
          <button class="${l.upper ? "active" : ""}" data-sty="upper">A̲A</button>
        </div>
      </div>
      <div class="type-field"><label>Align</label>
        <div class="seg-sm">
          <button class="${l.align === "left" ? "active" : ""}" data-txtalign="left">${PFIcons.svg("align-left")}</button>
          <button class="${l.align === "center" ? "active" : ""}" data-txtalign="center">${PFIcons.svg("align-center")}</button>
          <button class="${l.align === "right" ? "active" : ""}" data-txtalign="right">${PFIcons.svg("align-right")}</button>
        </div>
      </div>
      <div class="type-field"><label>Outline</label>
        <div class="type-row">
          <div class="type-field"><input type="color" id="inspStrokeColor" value="${l.textStroke || "#000000"}"></div>
          <div class="type-field"><input type="number" id="inspStrokeW" min="0" max="24" value="${l.textStrokeWidth || 0}"></div>
        </div>
      </div>
      <div class="type-field"><button class="ty-btn" id="inspEditText">${PFIcons.svg("edit")} Edit text…</button></div>
    `;
    const bindNum = (id, kind, parse = (v) => v) => {
      const el = sec.querySelector(id);
      el.addEventListener("input", () => applyTextProp(kind, parse(el.value), false));
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    sec.querySelector("#inspFont").addEventListener("change", (e) => applyTextProp("fontFamily", e.target.value));
    bindNum("#inspFontSize", "fontSize", (v) => clamp(parseFloat(v) || 12, 4, 600));
    bindNum("#inspLineH", "lineHeight", (v) => clamp(parseFloat(v) || 1.25, 0.6, 4));
    bindNum("#inspSpacing", "letterSpacing", (v) => clamp(parseFloat(v) || 0, -4, 40));
    sec.querySelector("#inspTextColor").addEventListener("change", (e) => applyTextProp("color", e.target.value));
    sec.querySelectorAll("[data-sty]").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.sty === "bold") applyTextProp("fontWeight", l.fontWeight >= 700 ? 400 : 700);
      else if (b.dataset.sty === "italic") applyTextProp("fontStyle", l.fontStyle === "italic" ? "normal" : "italic");
      else applyTextProp("upper", !l.upper);
      renderInspector();
    }));
    sec.querySelectorAll("[data-txtalign]").forEach((b) => b.addEventListener("click", () => {
      applyTextProp("align", b.dataset.txtalign);
      renderInspector();
    }));
    sec.querySelector("#inspStrokeColor").addEventListener("change", (e) => applyTextProp("textStroke", e.target.value));
    bindNum("#inspStrokeW", "textStrokeWidth", (v) => clamp(parseFloat(v) || 0, 0, 24));
    sec.querySelector("#inspEditText").addEventListener("click", () => openTextEditor(l));
  }

  function buildInspectorShape(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Shape</div>
      <div class="type-field"><label>Type</label>
        <select id="inspKind">${PFTools.SHAPE_KINDS.map(([k, ic, name]) => `<option value="${k}" ${l.shapeKind === k ? "selected" : ""}>${ic} ${name}</option>`).join("")}</select></div>
      <div class="type-row">
        <div class="type-field"><label>Fill</label><input type="color" id="inspFill" value="${l.fill}"></div>
        <div class="type-field"><label>Outline</label><input type="color" id="inspStroke" value="${l.stroke}"></div>
      </div>
      <div class="type-row">
        <div class="type-field"><label>Weight</label><input type="number" id="inspSw" min="0" max="80" value="${l.strokeWidth}"></div>
        <div class="type-field" id="inspRadiusWrap"><label>Radius</label><input type="number" id="inspRadius" min="0" max="400" value="${l.radius || 0}"></div>
        <div class="type-field" id="inspPointsWrap"><label>Points</label><input type="number" id="inspPoints" min="3" max="24" value="${l.points || 5}"></div>
      </div>`;
    const kindEl = sec.querySelector("#inspKind");
    const show = (v) => {
      sec.querySelector("#inspRadiusWrap").style.display = v === "rect" ? "flex" : "none";
      sec.querySelector("#inspPointsWrap").style.display = v === "star" ? "flex" : "none";
    };
    show(l.shapeKind);
    kindEl.addEventListener("change", (e) => { applyShapeProp("shapeKind", e.target.value); show(e.target.value); });
    sec.querySelector("#inspFill").addEventListener("change", (e) => applyShapeProp("fill", e.target.value));
    sec.querySelector("#inspStroke").addEventListener("change", (e) => applyShapeProp("stroke", e.target.value));
    const bindNum = (id, kind, parse = (v) => v) => {
      const el = sec.querySelector(id);
      el.addEventListener("input", () => applyShapeProp(kind, parse(el.value), false));
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    bindNum("#inspSw", "strokeWidth", (v) => clamp(parseFloat(v) || 0, 0, 80));
    bindNum("#inspRadius", "radius", (v) => clamp(parseFloat(v) || 0, 0, 400));
    bindNum("#inspPoints", "points", (v) => clamp(parseInt(v, 10) || 5, 3, 24));
  }

  /** AI-edit just the selected layer (used by the inspector's Remove background). */
  async function aiEditSelection(prompt) {
    if (state.aiBusy) return;
    if (!state.license || !state.license.active) { renderProUI(); return; }
    const l = selectedLayer();
    if (!l || !l.content) return toast("Select an image first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, l);
    const prepped = prepForAI(src.content);
    els.aiOutput.innerHTML = `<div class="busy-box"><div class="spinner"></div><span>AI is working…</span></div>`;
    switchTab("ai");
    state.aiBusy = true;
    try {
      const res = await sendMessage({ type: "ai:edit", image: prepped.dataURL, prompt });
      if (!res.ok) { showAIError(res); return; }
      const canvas = await cropResultToAspect(res.image, prepped.origW, prepped.origH);
      pushHistory();
      replaceLayerContent(l, canvas);
      els.aiOutput.innerHTML = "";
      toast("AI edit applied to selection");
    } catch (err) {
      showAIError({ error: (err && err.message) || "AI request failed." });
    } finally {
      state.aiBusy = false;
    }
  }

  // ================================================================== AI
  function renderAIChips() {
    els.aiChips.innerHTML = "";
    (AI_CHIPS[state.aiMode] || []).forEach((chip) => {
      const b = document.createElement("button");
      b.className = "ai-chip";
      b.textContent = chip;
      b.addEventListener("click", () => {
        els.aiPrompt.value = chip;
        runAI();
      });
      els.aiChips.appendChild(b);
    });
  }

  function prepForAI(canvas) {
    const long = Math.max(canvas.width, canvas.height);
    const scale = Math.min(1, 1536 / long);
    const w = Math.max(1, Math.round(canvas.width * scale));
    const h = Math.max(1, Math.round(canvas.height * scale));
    const side = Math.max(w, h);
    const padded = Math.ceil(side / 256) * 256;
    const out = document.createElement("canvas");
    out.width = padded;
    out.height = padded;
    const ctx = out.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, padded, padded);
    ctx.drawImage(canvas, (padded - w) / 2, (padded - h) / 2, w, h);
    return { dataURL: out.toDataURL("image/png"), w, h, origW: canvas.width, origH: canvas.height };
  }

  function cropResultToAspect(dataURL, origW, origH) {
    return loadImage(dataURL).then((img) => {
      const side = img.naturalWidth;
      const ar = origW / origH;
      let cw = side, ch = side;
      if (ar > 1) ch = Math.round(side / ar);
      else cw = Math.round(side * ar);
      const canvas = document.createElement("canvas");
      canvas.width = cw;
      canvas.height = ch;
      canvas.getContext("2d").drawImage(img, (side - cw) / 2, (side - ch) / 2, cw, ch);
      // Keep small source images small — don't return a 1536px upscale.
      const target = Math.max(origW, origH);
      if (Math.max(cw, ch) > target) {
        const s = target / Math.max(cw, ch);
        const out = document.createElement("canvas");
        out.width = Math.max(1, Math.round(cw * s));
        out.height = Math.max(1, Math.round(ch * s));
        out.getContext("2d").drawImage(canvas, 0, 0, out.width, out.height);
        return out;
      }
      return canvas;
    });
  }

  async function runAI() {
    if (state.aiBusy) return;
    const prompt = els.aiPrompt.value.trim();
    if (!prompt) return toast("Type a prompt first", true);
    if (!state.license || !state.license.active) {
      renderProUI();
      return;
    }
    state.aiBusy = true;
    els.aiGo.classList.add("busy");
    els.aiGo.disabled = true;
    els.aiOutput.innerHTML = `<div class="busy-box"><div class="spinner"></div><span>${state.aiMode === "analyze" ? "Analyzing image…" : "Generating with AI…"}</span></div>`;
    try {
      if (state.aiMode === "create") {
        const res = await sendMessage({ type: "ai:generate", prompt });
        if (res.ok) showImageResult(res.image);
        else showAIError(res);
      } else if (state.aiMode === "analyze") {
        const chatMode = ANALYZE_MODES[prompt] || "custom";
        const flat = PFEngine.flattenDoc(state.doc);
        const hasContent = state.doc.layers.some((l) => l.visible && l.content);
        const image = hasContent ? prepForAI(flat).dataURL : null;
        const res = await sendMessage({ type: "ai:chat", prompt, image, mode: chatMode });
        if (res.ok) showTextResult(res.text, chatMode);
        else showAIError(res);
      } else {
        const hasContent = state.doc.layers.some((l) => l.visible && l.content);
        if (!hasContent) { showAIError({ error: "Add an image layer before editing with AI." }); return; }
        const flat = PFEngine.flattenDoc(state.doc);
        const prepped = prepForAI(flat);
        const res = await sendMessage({ type: "ai:edit", image: prepped.dataURL, prompt });
        if (res.ok) showImageResult(res.image, prepped.origW, prepped.origH);
        else showAIError(res);
      }
    } finally {
      state.aiBusy = false;
      els.aiGo.classList.remove("busy");
      els.aiGo.disabled = false;
    }
  }

  function showAIError(res) {
    if (res.code === "PRO_REQUIRED") {
      renderProUI();
      return;
    }
    els.aiOutput.innerHTML = `<div class="ai-result"><div class="ai-result-text" style="color:var(--red)">${res.error || "AI request failed."}</div></div>`;
  }

  function showImageResult(dataURL, origW, origH) {
    cropResultToAspect(dataURL, origW || 1536, origH || 1536).then((canvas) => {
      els.aiOutput.innerHTML = `
        <div class="ai-result">
          <img src="${canvas.toDataURL("image/png")}" alt="AI result">
          <div class="btn-row">
            <button class="btn primary" id="aiAdd">Add as new layer</button>
            <button class="btn ghost" id="aiReplace">Replace selection</button>
          </div>
        </div>`;
      els.aiOutput.querySelector("#aiAdd").addEventListener("click", () => addAICanvas(canvas, false));
      els.aiOutput.querySelector("#aiReplace").addEventListener("click", () => addAICanvas(canvas, true));
    }).catch(() => showAIError({ error: "Could not process the AI result." }));
  }

  function addAICanvas(canvas, replace) {
    const layer = PFProject.newLayer("raster", { name: "AI result", content: canvas });
    layer.transform = { x: state.doc.width / 2, y: state.doc.height / 2, rotation: 0, scaleX: 1, scaleY: 1 };
    const idx = state.doc.layers.findIndex((l) => l.id === state.selectedId);
    pushHistory();
    if (replace && idx >= 0) {
      state.doc.layers[idx] = layer;
    } else {
      state.doc.layers.push(layer);
    }
    selectLayer(layer.id, { silent: true });
    render();
    renderLayersPanel();
    markDirty();
    els.aiOutput.innerHTML = "";
    toast("AI result added to your design");
  }

  function showTextResult(text, chatMode) {
    const box = document.createElement("div");
    box.className = "ai-result";
    box.innerHTML = `
      <div class="ai-result-text"></div>
      <div class="btn-row">
        <button class="btn ghost" id="aiCopy">${PFIcons.svg("copy")} Copy</button>
      </div>`;
    box.querySelector(".ai-result-text").textContent = text;
    box.querySelector("#aiCopy").addEventListener("click", () => {
      navigator.clipboard.writeText(text).then(() => toast("Copied to clipboard")).catch(() => toast("Copy failed", true));
    });
    els.aiOutput.innerHTML = "";
    els.aiOutput.appendChild(box);

    if (chatMode === "suggest") {
      const ideas = parseSuggestions(text);
      ideas.forEach((idea) => {
        const b = document.createElement("button");
        b.className = "ai-suggestion-chip";
        b.textContent = idea;
        b.addEventListener("click", () => {
          els.aiPrompt.value = idea;
          state.aiMode = "edit";
          syncAIModeUI();
          renderAIChips();
          runAI();
        });
        els.aiOutput.appendChild(b);
      });
    }
  }

  function parseSuggestions(text) {
    const m = String(text).match(/\[[\s\S]*\]/);
    if (!m) return [];
    try {
      const arr = JSON.parse(m[0]);
      return Array.isArray(arr) ? arr.filter((s) => typeof s === "string").slice(0, 5) : [];
    } catch { return []; }
  }

  // ================================================================== licensing / settings UI
  async function loadSettings() {
    const res = await sendMessage({ type: "settings:get" });
    if (res.ok) {
      state.settings = res.settings || {};
      els.setKey.value = state.settings.openaiKey || "";
      els.setModel.value = state.settings.openaiModel || "gpt-4o";
      if (state.settings.rightDockWidth) document.documentElement.style.setProperty("--rp-w", `${state.settings.rightDockWidth}px`);
      state.license = res.license && res.license.active ? res.license : null;
    }
  }

  function renderProUI() {
    const pro = !!(state.license && state.license.active);
    els.proBadge.classList.toggle("active", pro);
    els.aiLocked.classList.toggle("hidden", pro);
    els.aiBody.classList.toggle("hidden", !pro);
    if (!pro) {
      els.aiStatusLine.textContent = "";
      els.aiStatusLine.className = "ai-status";
    }
    renderLicStatus();
  }

  function renderLicStatus() {
    const lic = state.license;
    if (lic && lic.active) {
      const expText = lic.exp ? new Date(lic.exp * 1000).toLocaleDateString() : "never";
      els.licStatus.textContent = `✓ Pro active${lic.exp ? ` · expires ${expText}` : " · lifetime"}.`;
      els.licStatus.style.color = "var(--green)";
    } else {
      els.licStatus.textContent = "Not activated.";
      els.licStatus.style.color = "";
    }
  }

  async function activateLicense(key) {
    const clean = String(key || "").trim();
    if (!clean) return toast("Paste a Pro key first", true);
    const res = await sendMessage({ type: "license:validate", key: clean });
    if (res.ok) {
      state.license = { active: true, tier: res.tier, keyId: res.keyId, exp: res.exp, key: clean };
      renderProUI();
      toast("PixelForge Pro activated");
    } else {
      toast(res.reason === "expired" ? "This key has expired" : "Invalid Pro key", true);
    }
  }

  function bindSettingsUI() {
    let keyTimer = null;
    els.setKey.addEventListener("input", (e) => {
      clearTimeout(keyTimer);
      const value = e.target.value;
      keyTimer = setTimeout(() => sendMessage({ type: "settings:set", key: "openaiKey", value }), 400);
    });
    els.setModel.addEventListener("change", (e) => sendMessage({ type: "settings:set", key: "openaiModel", value: e.target.value }));

    els.aiActivateBtn.addEventListener("click", async () => {
      await activateLicense(els.aiKeyInput.value);
      els.aiKeyInput.value = "";
    });
    els.licActivateBtn.addEventListener("click", async () => {
      await activateLicense(els.licKeyInput.value);
      els.licKeyInput.value = "";
    });
    els.licClearBtn.addEventListener("click", async () => {
      await sendMessage({ type: "license:clear" });
      state.license = null;
      renderProUI();
      toast("Pro key removed");
    });

    els.btnDownloadProject.addEventListener("click", () => {
      const data = PFProject.serializeDoc(state.doc);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      PFProject.downloadBlob(blob, state.doc.name.replace(/[^\w\- ]+/g, "").trim() + ".pfproj");
      toast("Project downloaded");
    });
    els.btnClearProjects.addEventListener("click", () => {
      confirmDialog("Delete all saved projects from this browser? Your current design stays open.", async () => {
        await PFDB.clear("projects");
        toast("Projects cleared");
      });
    });
    els.btnResetAll.addEventListener("click", () => {
      confirmDialog("This wipes ALL PixelForge data: projects, settings and license. This cannot be undone.", async () => {
        await PFDB.clear("projects");
        await chrome.storage.local.clear();
        location.reload();
      }, "Reset all data?");
    });
  }

  // ================================================================== save
  function markDirty() {
    render();
    if (state.layersTabActive) renderLayersPanel();
    updateTopbar();
    clearTimeout(state.saveTimer);
    state.saveTimer = setTimeout(saveProject, 1500);
  }

  async function saveProject() {
    if (!state.doc) return;
    try {
      const flat = PFEngine.flattenDoc(state.doc);
      const data = PFProject.serializeDoc(state.doc);
      await PFDB.put("projects", {
        id: state.doc.id,
        name: state.doc.name,
        width: state.doc.width,
        height: state.doc.height,
        template: state.doc.template,
        updatedAt: Date.now(),
        thumbnail: PFProject.makeThumbnail(flat),
        data,
      });
    } catch (err) {
      console.error("PixelForge save failed:", err);
    }
  }

  // ================================================================== modals
  function openModal(id) {
    $(id).classList.remove("hidden");
  }
  function closeModal(id) {
    $(id).classList.add("hidden");
  }
  function closeAllModals() {
    document.querySelectorAll(".modal-back").forEach((m) => m.classList.add("hidden"));
  }

  function confirmDialog(text, onOk, title = "Are you sure?") {
    els.confirmText.textContent = text;
    els.confirmTitle.textContent = title;
    els.confirmCancel.classList.remove("hidden");
    els.confirmOk.textContent = "Confirm";
    els.confirmOk.className = "btn danger";
    els.confirmOk.onclick = () => {
      closeModal("modalConfirm");
      onOk();
    };
    els.confirmCancel.onclick = () => closeModal("modalConfirm");
    openModal("modalConfirm");
  }

  /** A plain info dialog (Help > Keyboard shortcuts) reusing the confirm modal. */
  function showHelpDialog(title, html) {
    els.confirmTitle.textContent = title;
    els.confirmText.innerHTML = html;
    els.confirmCancel.classList.add("hidden");
    els.confirmOk.textContent = "Got it";
    els.confirmOk.className = "btn primary";
    els.confirmOk.onclick = () => closeModal("modalConfirm");
    openModal("modalConfirm");
  }

  function showShortcutsHelp() {
    const rows = [
      ["V B E I T U", "Move / Brush / Eraser / Eyedropper / Text / Shape"],
      ["F G L S C Z H", "Fill / Gradient / Blur brush / Clone stamp / Crop / Zoom / Pan"],
      ["Ctrl+Z / Ctrl+Shift+Z", "Undo / Redo"],
      ["Ctrl+S / Ctrl+E", "Save project / Export"],
      ["0 / 1 / + / −", "Fit / 100% / Zoom in / Zoom out"],
      ["Delete", "Remove selected layer"],
      ["Arrow keys", "Nudge selection (Shift = ×10)"],
      ["Space (hold)", "Temporary pan"],
      ["Enter / Esc", "Apply / cancel crop"],
    ];
    const html = `<div style="display:grid;grid-template-columns:auto 1fr;gap:8px 16px;font-size:12.5px;text-align:left">${rows
      .map(([k, d]) => `<span class="tooltip-kbd" style="justify-self:start">${escapeHtml(k)}</span><span>${escapeHtml(d)}</span>`)
      .join("")}</div>`;
    showHelpDialog("Keyboard shortcuts", html);
  }

  // ================================================================== menu bar
  const MENUS = [
    { label: "File", items: [
      { label: "New…", action: () => openModal("modalNew") },
      { label: "Save", kbd: "Ctrl+S", action: async () => { await saveProject(); toast("Project saved"); } },
      { label: "Export…", kbd: "Ctrl+E", action: openExport },
      { sep: true },
      { label: "Download .pfproj", action: () => els.btnDownloadProject.click() },
    ] },
    { label: "Edit", items: [
      { label: "Undo", kbd: "Ctrl+Z", action: undo },
      { label: "Redo", kbd: "Ctrl+Shift+Z", action: redo },
      { sep: true },
      { label: "Delete", kbd: "Del", action: deleteSelected },
    ] },
    { label: "Image", items: [
      { label: "Resize canvas / image…", action: openResize },
      { label: "Adjustments", action: () => switchTab("adjust") },
    ] },
    { label: "Layer", items: [
      { label: "Add image", action: () => els.btnAddImage.click() },
      { label: "Add text", action: () => els.btnAddText.click() },
      { label: "Add shape", action: () => els.btnAddShape.click() },
      { sep: true },
      { label: "Duplicate", action: duplicateLayer },
      { label: "Delete", action: deleteSelected },
      { sep: true },
      { label: "Bring to front", action: () => moveToEdge(state.doc.layers.length - 1) },
      { label: "Send to back", action: () => moveToEdge(0) },
    ] },
    { label: "Select", items: [
      { label: "Deselect", action: () => selectLayer(null) },
    ] },
    { label: "View", items: [
      { label: "Zoom in", kbd: "+", action: () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2) },
      { label: "Zoom out", kbd: "−", action: () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2) },
      { label: "Zoom to fit", kbd: "0", action: zoomFit },
      { label: "Zoom to 100%", kbd: "1", action: () => { state.zoom = 1; applyZoom(); } },
    ] },
    { label: "Help", items: [
      { label: "Keyboard shortcuts", action: showShortcutsHelp },
    ] },
  ];

  function closeAllMenus() {
    document.querySelectorAll("#menuBar .menu-item.open").forEach((m) => m.classList.remove("open"));
  }

  function bindMenuBar() {
    els.menuBar.innerHTML = "";
    MENUS.forEach((menu) => {
      const item = document.createElement("div");
      item.className = "menu-item";
      item.textContent = menu.label;
      const dd = document.createElement("div");
      dd.className = "menu-dd";
      menu.items.forEach((it) => {
        if (it.sep) {
          const s = document.createElement("div");
          s.className = "menu-sep";
          dd.appendChild(s);
          return;
        }
        const b = document.createElement("button");
        b.className = "menu-dd-item";
        b.innerHTML = `<span>${escapeHtml(it.label)}</span>${it.kbd ? `<span class="dd-kbd">${escapeHtml(it.kbd)}</span>` : ""}`;
        b.addEventListener("click", () => { closeAllMenus(); it.action(); });
        dd.appendChild(b);
      });
      item.appendChild(dd);
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        const wasOpen = item.classList.contains("open");
        closeAllMenus();
        if (!wasOpen) item.classList.add("open");
      });
      els.menuBar.appendChild(item);
    });
    document.addEventListener("click", closeAllMenus);
  }

  // ================================================================== right-dock resizer
  function bindDockResizer() {
    document.querySelectorAll(".dock-resizer").forEach((handle) => {
      handle.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        handle.classList.add("active");
        handle.setPointerCapture(e.pointerId);
        const startX = e.clientX;
        const startW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--rp-w")) || 300;
        const onMove = (ev) => {
          // The handle sits on the dock's left edge, so dragging left widens it.
          const w = clamp(startW + (startX - ev.clientX), 220, 520);
          document.documentElement.style.setProperty("--rp-w", `${w}px`);
        };
        const onUp = () => {
          handle.classList.remove("active");
          window.removeEventListener("pointermove", onMove);
          window.removeEventListener("pointerup", onUp);
          const w = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--rp-w"));
          sendMessage({ type: "settings:set", key: "rightDockWidth", value: w });
        };
        window.addEventListener("pointermove", onMove);
        window.addEventListener("pointerup", onUp);
      });
    });
  }

  // ================================================================== right-click context menu
  function closeContextMenu() {
    els.ctxMenu.classList.add("hidden");
    els.ctxMenu.innerHTML = "";
  }

  function buildCtxItems(items) {
    els.ctxMenu.innerHTML = "";
    items.forEach((it) => {
      if (it.sep) {
        const s = document.createElement("div");
        s.className = "ctx-sep";
        els.ctxMenu.appendChild(s);
        return;
      }
      const b = document.createElement("button");
      b.className = "ctx-item" + (it.danger ? " danger" : "");
      b.disabled = !!it.disabled;
      b.innerHTML = `${PFIcons.svg(it.icon)}<span>${escapeHtml(it.label)}</span>${it.kbd ? `<span class="ctx-kbd">${escapeHtml(it.kbd)}</span>` : ""}`;
      if (!it.disabled) b.addEventListener("click", () => { closeContextMenu(); it.action(); });
      els.ctxMenu.appendChild(b);
    });
  }

  function positionCtxMenu(x, y) {
    els.ctxMenu.classList.remove("hidden");
    const r = els.ctxMenu.getBoundingClientRect();
    els.ctxMenu.style.left = Math.min(x, window.innerWidth - r.width - 8) + "px";
    els.ctxMenu.style.top = Math.min(y, window.innerHeight - r.height - 8) + "px";
  }

  function layerContextItems(layer) {
    return [
      { icon: "duplicate", label: "Duplicate", action: duplicateLayer },
      { icon: "trash", label: "Delete", kbd: "Del", danger: true, action: () => removeLayer(layer.id) },
      { sep: true },
      { icon: "arrange-front", label: "Bring to front", action: () => moveToEdge(state.doc.layers.length - 1) },
      { icon: "arrange-forward", label: "Bring forward", action: () => moveLayer(1) },
      { icon: "arrange-back", label: "Send backward", action: () => moveLayer(-1) },
      { icon: "arrange-toback", label: "Send to back", action: () => moveToEdge(0) },
    ];
  }

  function openCanvasContextMenu(x, y, layer) {
    if (!layer) return; // nothing to act on — let the plain preventDefault suppress the browser menu
    buildCtxItems(layerContextItems(layer));
    positionCtxMenu(x, y);
  }

  function openLayerContextMenu(x, y, layer) {
    buildCtxItems(layerContextItems(layer));
    positionCtxMenu(x, y);
  }

  function bindContextMenu() {
    document.addEventListener("pointerdown", (e) => {
      if (!els.ctxMenu.contains(e.target)) closeContextMenu();
    });
    window.addEventListener("blur", closeContextMenu);
    window.addEventListener("resize", closeContextMenu);
  }

  function renderTemplates() {
    els.templateGrid.innerHTML = "";
    PFProject.TEMPLATES.forEach((t) => {
      const card = document.createElement("button");
      card.className = "template-card";
      const ar = t.w / t.h;
      const boxW = ar >= 1 ? 26 : Math.round(26 * ar);
      const boxH = ar >= 1 ? Math.round(26 / ar) : 26;
      card.innerHTML = `<span class="t-icon" style="width:${boxW}px;height:${boxH}px"></span><span class="t-name">${t.name}</span><span class="t-hint">${t.hint}</span>`;
      card.addEventListener("click", () => createFromTemplate(t.id));
      els.templateGrid.appendChild(card);
    });
  }

  function openExport() {
    const pro = !!(state.license && state.license.active);
    const maxDim = pro ? 0 : PFProject.FREE_MAX_DIM;
    const long = Math.max(state.doc.width, state.doc.height);
    const scale = maxDim && long > maxDim ? maxDim / long : 1;
    const w = Math.round(state.doc.width * scale);
    const h = Math.round(state.doc.height * scale);
    els.expSizeNote.className = "exp-note " + (pro ? "pro" : "free");
    els.expSizeNote.textContent = pro
      ? "✓ Full resolution export (Pro)."
      : `Free exports are capped at ${PFProject.FREE_MAX_DIM}px — activate Pro for full resolution.`;
    els.expDims.textContent = `Will export ${w} × ${h}px`;
    openModal("modalExport");
  }

  function doExport() {
    const pro = !!(state.license && state.license.active);
    const maxDim = pro ? 0 : PFProject.FREE_MAX_DIM;
    const quality = parseFloat(els.expQuality.value) / 100;
    const flat = PFEngine.flattenDoc(state.doc);
    PFProject.exportBlob(flat, { format: state.exportFormat, quality, maxDim }).then((blob) => {
      PFProject.downloadBlob(blob, `${state.doc.name.replace(/[^\w\- ]+/g, "").trim() || "design"}.${state.exportFormat}`);
      closeModal("modalExport");
      toast("Exported");
    }).catch((err) => toast(err.message || "Export failed", true));
  }

  function openResize() {
    els.resW.value = state.doc.width;
    els.resH.value = state.doc.height;
    openModal("modalResize");
  }

  function applyResize() {
    const w = clamp(parseInt(els.resW.value, 10) || 0, 16, 8000);
    const h = clamp(parseInt(els.resH.value, 10) || 0, 16, 8000);
    const mode = document.querySelector('input[name="resizeMode"]:checked').value;
    const doc = state.doc;
    pushHistory();
    if (mode === "canvas") {
      for (const layer of doc.layers) {
        if (layer.fullCanvas && layer.content) {
          const c = document.createElement("canvas");
          c.width = w;
          c.height = h;
          c.getContext("2d").drawImage(layer.content, 0, 0);
          layer.content = c;
          layer.transform = { x: w / 2, y: h / 2, rotation: 0, scaleX: 1, scaleY: 1 };
        }
      }
    } else {
      const layers = [];
      for (const layer of doc.layers) {
        // Force-flatten hidden layers too (drawLayer skips them by default).
        const full = PFEngine.flattenLayerToFullCanvas(doc, layer, true);
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        c.getContext("2d").drawImage(full.content, 0, 0, w, h);
        const scaled = PFEngine.makeFullCanvasLayer(c, { name: layer.name });
        scaled.visible = layer.visible; // opacity was baked during flatten
        layers.push(scaled);
      }
      doc.layers = layers;
    }
    doc.width = w;
    doc.height = h;
    closeModal("modalResize");
    setupCanvas(false);
    render();
    renderLayersPanel();
    markDirty();
    toast(`Resized to ${w} × ${h}`);
  }

  // ================================================================== bindings
  function bindTopbar() {
    els.docName.addEventListener("input", () => {
      if (!state.doc) return;
      state.doc.name = els.docName.value || "Untitled design";
      clearTimeout(state.nameTimer);
      state.nameTimer = setTimeout(markDirty, 400);
    });
    els.undoBtn.addEventListener("click", undo);
    els.redoBtn.addEventListener("click", redo);
    els.zoomIn.addEventListener("click", () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2));
    els.zoomOut.addEventListener("click", () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2));
    els.zoomLabel.addEventListener("click", () => { state.zoom = 1; applyZoom(); });
    els.zoomFit.addEventListener("click", zoomFit);
    els.newBtn.addEventListener("click", () => openModal("modalNew"));
    els.saveBtn.addEventListener("click", async () => { await saveProject(); toast("Project saved"); });
    els.exportBtn.addEventListener("click", openExport);
    els.proBadge.addEventListener("click", () => switchTab("ai"));
  }

  function switchTab(tab) {
    document.querySelectorAll(".rp-tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
    document.querySelectorAll(".rp-panel").forEach((p) => p.classList.remove("active"));
    const panel = $("panel-" + tab);
    if (panel) panel.classList.add("active");
    state.layersTabActive = tab === "layers";
    if (state.layersTabActive) renderLayersPanel();
  }

  function bindPanels() {
    document.querySelectorAll(".rp-tab").forEach((b) => b.addEventListener("click", () => switchTab(b.dataset.tab)));

    const fxMap = { fxBrightness: "brightness", fxContrast: "contrast", fxSaturate: "saturate", fxHue: "hue", fxBlur: "blur", fxSharpen: "sharpen" };
    Object.entries(fxMap).forEach(([id, key]) => {
      const slider = els[id];
      const valEl = els["v" + key.charAt(0).toUpperCase() + key.slice(1)];
      slider.addEventListener("input", () => {
        state.fx[key] = parseFloat(slider.value);
        sliderFill(slider);
        valEl.textContent = slider.value;
      });
      sliderFill(slider);
    });

    els.applyFxBtn.addEventListener("click", applyAdjustments);
    els.resetFxBtn.addEventListener("click", resetFxSliders);
    els.resizeBtn.addEventListener("click", openResize);

    els.btnAddImage.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => { if (input.files[0]) addImageFile(input.files[0]); };
      input.click();
    });
    els.btnAddText.addEventListener("click", () => {
      const layer = PFProject.newLayer("text", {
        transform: { x: state.doc.width / 2, y: state.doc.height / 2, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
      openTextEditor(layer);
    });
    els.btnAddShape.addEventListener("click", () => { setTool("shape"); toast("Drag on the canvas to draw a shape"); });
    els.btnAddBrush.addEventListener("click", () => { setTool("brush"); });

    els.layerOpacity.addEventListener("input", () => {
      const layer = selectedLayer();
      if (!layer) return;
      layer.opacity = parseFloat(els.layerOpacity.value) / 100;
      els.layerOpacityVal.textContent = els.layerOpacity.value;
      render();
    });
    els.layerOpacity.addEventListener("change", () => { pushHistory(); markDirty(); });
    els.layerUp.addEventListener("click", () => moveLayer(1));
    els.layerDown.addEventListener("click", () => moveLayer(-1));
    els.layerDup.addEventListener("click", duplicateLayer);
    els.layerDel.addEventListener("click", deleteSelected);

    els.aiModeSeg.querySelectorAll(".seg-btn").forEach((b) => b.addEventListener("click", () => {
      state.aiMode = b.dataset.mode;
      syncAIModeUI();
    }));
    els.aiGo.addEventListener("click", runAI);
    els.aiPrompt.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); runAI(); }
    });
  }

  function syncAIModeUI() {
    els.aiModeSeg.querySelectorAll(".seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.mode === state.aiMode));
    els.aiPrompt.placeholder = state.aiMode === "edit"
      ? 'Tell the AI what to change… e.g. "make the sky a sunset"'
      : state.aiMode === "create"
        ? "Describe the image to create…"
        : "Ask anything about your image…";
    renderAIChips();
  }

  function bindModals() {
    document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => closeModal(b.dataset.close)));
    document.querySelectorAll(".modal-back").forEach((m) => m.addEventListener("click", (e) => {
      if (e.target === m) m.classList.add("hidden");
    }));
    els.newCreateBtn.addEventListener("click", () => {
      const w = clamp(parseInt(els.newW.value, 10) || 1080, 16, 8000);
      const h = clamp(parseInt(els.newH.value, 10) || 1080, 16, 8000);
      createFromTemplate("custom", { name: `Design ${w}×${h}`, width: w, height: h });
    });
    els.fmtSeg.querySelectorAll(".seg-btn").forEach((b) => b.addEventListener("click", () => {
      state.exportFormat = b.dataset.fmt;
      els.fmtSeg.querySelectorAll(".seg-btn").forEach((x) => x.classList.toggle("active", x === b));
    }));
    els.expQuality.addEventListener("input", () => {
      els.expQualityVal.textContent = els.expQuality.value;
      sliderFill(els.expQuality);
    });
    sliderFill(els.expQuality);
    els.expBtn.addEventListener("click", doExport);
    els.resizeApply.addEventListener("click", applyResize);
  }

  function bindDnD() {
    els.workspace.addEventListener("dragover", (e) => e.preventDefault());
    els.workspace.addEventListener("drop", (e) => {
      e.preventDefault();
      const file = Array.from(e.dataTransfer.files || []).find((f) => f.type.startsWith("image/"));
      if (file) addImageFile(file);
    });
    document.addEventListener("paste", (e) => {
      const items = e.clipboardData && e.clipboardData.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith("image/")) {
          const file = item.getAsFile();
          if (file) { addImageFile(file); break; }
        }
      }
    });
  }

  function addImageFile(file, center) {
    if (!file || !file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const layer = PFEngine.createRasterLayer(state.doc, img);
      if (center) {
        layer.transform.x = center.x;
        layer.transform.y = center.y;
      }
      pushHistory();
      addLayer(layer, { select: true });
      render();
      renderLayersPanel();
      toast("Image added");
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      toast("Could not load that image", true);
    };
    img.src = url;
  }

  // ================================================================== elements panel + drag-to-canvas
  function renderElementsPanel() {
    const grid = $("elShapeGrid");
    if (!grid) return;
    grid.innerHTML = "";
    PFTools.SHAPE_KINDS.forEach(([k, icon, name]) => {
      const chip = document.createElement("button");
      chip.className = "el-chip";
      chip.dataset.el = `shape:${k}`;
      chip.draggable = false;
      chip.dataset.tip = `${name}|Drag onto the canvas to drop a ${name.toLowerCase()} — or click to add it in the centre`;
      chip.innerHTML = `<span class="el-ico">${icon}</span><span class="el-name">${name}</span>`;
      grid.appendChild(chip);
    });
  }

  /** Add an element from the Elements panel — at a doc point, or centred on click. */
  function addElementAt(kind, pt) {
    if (kind === "image") {
      openImagePicker(pt);
      return;
    }
    if (kind === "text") {
      // The popover pushes history after the layer exists, so don't push twice.
      const d = state.toolOptions.textDefaults;
      const layer = PFProject.newLayer("text", {
        text: "Your text",
        fontFamily: d.fontFamily, fontSize: d.fontSize, fontWeight: d.fontWeight, fontStyle: d.fontStyle,
        color: d.color, align: d.align, letterSpacing: d.letterSpacing, upper: d.upper,
        transform: { x: pt.x, y: pt.y, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
      openTextEditor(layer, { push: false });
    } else if (kind.startsWith("shape:")) {
      pushHistory();
      const o = state.toolOptions;
      const shapeKind = kind.slice(6);
      const s = Math.max(48, Math.min(state.doc.width, state.doc.height) * 0.22);
      const isLine = shapeKind === "line" || shapeKind === "arrow";
      const layer = PFProject.newLayer("shape", {
        name: shapeKind,
        shapeKind,
        shapeRect: { x: 0, y: 0, w: s, h: isLine ? Math.max(2, s * 0.6) : s },
        radius: o.radius,
        points: o.points,
        fill: o.fill,
        stroke: o.stroke,
        strokeWidth: isLine ? Math.max(3, o.strokeWidth) : o.strokeWidth,
        transform: { x: pt.x, y: pt.y, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
    }
  }

  function openImagePicker(center) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => { if (input.files[0]) addImageFile(input.files[0], center); };
    input.click();
  }

  /** Pointer-based drag from an Elements chip onto the canvas, with a visible flow. */
  function initItemDrag() {
    let drag = null;

    function buildGhost(kind) {
      const g = document.createElement("div");
      g.className = "drag-ghost";
      if (kind === "text") {
        g.innerHTML = '<span class="dg-ico dg-text">T</span>';
      } else if (kind === "image") {
        g.innerHTML = `<span class="dg-ico">${PFIcons.svg("image")}</span>`;
      } else {
        const c = document.createElement("canvas");
        c.width = 40;
        c.height = 40;
        const ctx = c.getContext("2d");
        const k = kind.slice(6);
        PFTools.drawShapePath(ctx, k, 5, 5, 30, 30, { radius: 8, points: 5 });
        if (k !== "line" && k !== "arrow") { ctx.fillStyle = "#fff"; ctx.fill(); }
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.stroke();
        g.appendChild(c);
      }
      return g;
    }

    function moveDrag(e) {
      if (!drag) return;
      if (Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) > 5) drag.moved = true;
      drag.ghost.style.left = e.clientX + "px";
      drag.ghost.style.top = e.clientY + "px";
      const r = els.stage.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      els.stage.classList.toggle("drop-target", inside);
      const wr = els.workspace.getBoundingClientRect();
      drag.badge.style.left = e.clientX - wr.left + "px";
      drag.badge.style.top = e.clientY - wr.top + "px";
      drag.badge.classList.toggle("off", !inside);
    }

    function endDrag(e, cancelled) {
      if (!drag) return;
      const wasClick = !drag.moved && !cancelled;
      const kind = drag.kind;
      drag.ghost.remove();
      drag.badge.remove();
      drag = null;
      document.body.classList.remove("is-item-drag");
      els.stage.classList.remove("drop-target");
      state.itemDragActive = false;
      if (cancelled) return;
      const r = els.stage.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      if (inside) {
        addElementAt(kind, docPoint(e));
      } else if (wasClick) {
        addElementAt(kind, { x: state.doc.width / 2, y: state.doc.height / 2 });
      }
    }

    document.addEventListener("pointerdown", (e) => {
      const chip = e.target.closest ? e.target.closest("[data-el]") : null;
      if (!chip || e.button !== 0) return;
      e.preventDefault();
      // Capture the pointer so releasing outside the window still fires
      // pointerup (no stuck ghost / drop highlight / hover lockout).
      try { chip.setPointerCapture(e.pointerId); } catch { /* noop */ }
      const badge = document.createElement("div");
      badge.className = "drag-badge off";
      badge.innerHTML = "＋ <b>Release to add</b>";
      els.workspace.appendChild(badge);
      drag = {
        kind: chip.dataset.el,
        startX: e.clientX, startY: e.clientY,
        ghost: buildGhost(chip.dataset.el),
        badge,
        moved: false,
      };
      document.body.appendChild(drag.ghost);
      document.body.classList.add("is-item-drag");
      state.itemDragActive = true;
      moveDrag(e);
    });

    window.addEventListener("pointermove", moveDrag);
    window.addEventListener("pointerup", (e) => endDrag(e, false));
    window.addEventListener("pointercancel", (e) => endDrag(e, true));
  }

  // ================================================================== pointer + zoom
  function bindShortcuts() {
    document.addEventListener("keydown", (e) => {
      const target = e.target;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT");

      if (typing && !(e.key === "Escape")) {
        if (e.key === "Enter" && target === els.textPopInput && !e.shiftKey) closeTextEditor();
        return;
      }

      const ctrl = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();

      if (ctrl && k === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
      if (ctrl && k === "y") { e.preventDefault(); redo(); return; }
      if (ctrl && k === "s") { e.preventDefault(); saveProject(); toast("Project saved"); return; }
      if (ctrl && k === "e") { e.preventDefault(); openExport(); return; }
      if (e.key === "Escape") {
        closeAllModals();
        closeAllMenus();
        closeContextMenu();
        if (state.tool === "crop" && state.toolInstance.cancel) { state.toolInstance.cancel(); }
        closeTextEditor();
        return;
      }
      if (e.key === "Enter" && state.tool === "crop" && state.cropRect) { state.toolInstance.apply(); return; }
      if ((e.key === "Delete" || e.key === "Backspace") && !typing) { e.preventDefault(); deleteSelected(); return; }

      const toolKeys = { v: "move", b: "brush", e: "eraser", i: "eyedropper", t: "text", u: "shape", c: "crop", h: "pan", f: "fill", g: "gradient", l: "blur", s: "stamp", z: "zoom" };
      if (toolKeys[k] && !ctrl) { setTool(toolKeys[k]); return; }

      if (k === "0") { e.preventDefault(); zoomFit(); return; }
      if (k === "1") { e.preventDefault(); state.zoom = 1; applyZoom(); return; }
      if (k === "=" || k === "+") { e.preventDefault(); zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2); return; }
      if (k === "-") { e.preventDefault(); zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2); return; }

      if (e.key.startsWith("Arrow")) {
        const layer = selectedLayer();
        if (!layer) return;
        e.preventDefault();
        if (!state.nudgePushed) { pushHistory(); state.nudgePushed = true; }
        const n = e.shiftKey ? 10 : 1;
        if (e.key === "ArrowLeft") layer.transform.x -= n;
        if (e.key === "ArrowRight") layer.transform.x += n;
        if (e.key === "ArrowUp") layer.transform.y -= n;
        if (e.key === "ArrowDown") layer.transform.y += n;
        render();
        markDirty();
        return;
      }

      // space → temporary pan
      if (e.code === "Space" && !typing) {
        e.preventDefault();
        if (!state.spacePan) {
          state.spacePan = true;
          state.toolBeforeSpace = state.tool;
          setTool("pan");
        }
      }
    });

    document.addEventListener("keyup", (e) => {
      if (e.code === "Space" && state.spacePan) {
        state.spacePan = false;
        setTool(state.toolBeforeSpace || "move");
      }
      if (e.key.startsWith("Arrow")) state.nudgePushed = false;
    });

    // pointer
    els.workspace.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      const layer = PFEngine.topLayerAt(state.doc, docPoint(e));
      if (layer) selectLayer(layer.id);
      openCanvasContextMenu(e.clientX, e.clientY, layer);
    });

    els.workspace.addEventListener("pointerdown", (e) => {
      if (e.button === 1) {
        state.dragging = true;
        state.middlePan = true;
        els.workspace.setPointerCapture(e.pointerId);
        e.preventDefault();
        return;
      }
      if (e.button !== 0) return;
      state.dragging = true;
      state.nudgePushed = false;
      clearHover();
      if (state.tool === "move" && hitSelectionHandle(docPoint(e))) {
        els.workspace.style.cursor = "grabbing";
      }
      try {
        state.toolInstance.pointerDown(docPoint(e), e);
      } catch (err) {
        console.error("PixelForge tool error:", err);
      }
      els.workspace.setPointerCapture(e.pointerId);
    });

    els.workspace.addEventListener("pointermove", (e) => {
      updateBrushCursorPos(e);
      const p = docPoint(e);
      els.hudCursor.textContent = `${Math.round(p.x)}, ${Math.round(p.y)}`;
      if (state.dragging) {
        if (state.middlePan) { panBy(e.movementX, e.movementY); return; }
        try {
          state.toolInstance.pointerMove(docPoint(e), e);
        } catch (err) {
          console.error("PixelForge tool error:", err);
        }
        return;
      }
      // Hover feedback: highlight the handle under the cursor, swap the cursor
      // and show a hint naming the action (resize / rotate / radius / move).
      updateHover(e);
    });

    els.workspace.addEventListener("pointerleave", () => {
      els.hudCursor.textContent = "—, —";
      if (state.dragging) return;
      clearHover();
      els.workspace.style.cursor = "default";
    });

    window.addEventListener("pointerup", (e) => {
      if (!state.dragging) return;
      state.dragging = false;
      state.middlePan = false;
      try {
        state.toolInstance.pointerUp(docPoint(e), e);
      } catch (err) {
        console.error("PixelForge tool error:", err);
      }
      updateHover(e);
    });

    els.workspace.addEventListener("wheel", (e) => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.12 : 1 / 1.12);
    }, { passive: false });

    window.addEventListener("beforeunload", () => {
      saveProject();
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) saveProject();
    });
  }

  function updateBrushCursorPos(e) {
    if (els.brushCursor.style.display === "none") return;
    const r = els.workspace.getBoundingClientRect();
    els.brushCursor.style.left = e.clientX - r.left + "px";
    els.brushCursor.style.top = e.clientY - r.top + "px";
  }

  // ================================================================== go
  boot();
})();
