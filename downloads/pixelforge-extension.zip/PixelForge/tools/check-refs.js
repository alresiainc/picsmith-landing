#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");

function idsIn(html) {
  return new Set([...html.matchAll(/id="([^"]+)"/g)].map((m) => m[1]));
}
function refsIn(js) {
  return new Set([...js.matchAll(/\$\("([^"]+)"\)/g)].map((m) => m[1]));
}

let fail = false;
for (const [htmlFile, jsFile] of [
  ["editor.html", "editor.js"],
  ["popup.html", "popup.js"],
]) {
  const ids = idsIn(fs.readFileSync(path.join(root, htmlFile), "utf8"));
  const refs = refsIn(fs.readFileSync(path.join(root, jsFile), "utf8"));
  const missing = [...refs].filter((r) => !ids.has(r));
  if (missing.length) {
    fail = true;
    console.log(`MISSING in ${htmlFile} (referenced by ${jsFile}):`, missing);
  } else {
    console.log(`OK: all $() refs in ${jsFile} exist in ${htmlFile}`);
  }
}
// tool panel / tab data attributes
const editorHtml = fs.readFileSync(path.join(root, "editor.html"), "utf8");
const editorJs = fs.readFileSync(path.join(root, "editor.js"), "utf8");
const tabs = [...editorHtml.matchAll(/data-tab="([^"]+)"/g)].map((m) => m[1]);
const missingPanels = tabs.filter((t) => !editorHtml.includes(`id="panel-${t}"`));
if (missingPanels.length) { fail = true; console.log("MISSING panels:", missingPanels); }
else console.log("OK: all tab panels exist:", tabs.join(", "));

process.exit(fail ? 1 : 0);
