#!/usr/bin/env node
"use strict";
const { sign, validate } = require("../lib/license.js");

(async () => {
  const key = await sign({ exp: Math.floor(Date.now() / 1000) + 86400 });
  console.log("minted key :", key);
  const check = await validate(key);
  console.log("validate   :", JSON.stringify(check));

  // Structural edge cases
  const tampered = key.replace(/./, (c) => (c === "0" ? "1" : "0"));
  console.log("tampered   :", JSON.stringify(await validate(tampered)));
  console.log("lowercase  :", JSON.stringify(await validate(key.toLowerCase())));
  console.log("no dashes  :", JSON.stringify(await validate(key.replace(/-/g, ""))));
  console.log("spaces     :", JSON.stringify(await validate("  " + key + "  ")));
  console.log("garbage    :", JSON.stringify(await validate("PF-1234-5678-90AB-CDEF-1234-5678-90A")));
})();
