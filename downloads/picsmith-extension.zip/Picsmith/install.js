/* Picsmith install/welcome page */
"use strict";

const ctaBtn = document.getElementById("ctaBtn");
const statusLine = document.getElementById("statusLine");

function openEditor() {
  chrome.tabs.create({ url: chrome.runtime.getURL("editor.html") });
}

ctaBtn.addEventListener("click", () => {
  statusLine.textContent = "Launching Picsmith…";
  setTimeout(openEditor, 250);
});

// Also open when the page itself loads in a tab.
if (document.visibilityState === "visible") {
  setTimeout(() => {
    statusLine.textContent = "Picsmith installed — ready when you are.";
  }, 1200);
}
