#!/usr/bin/env node
/**
 * Picsmith key minting tool.
 *
 *   node tools/mint-key.js                  # one pro key, never expires
 *   node tools/mint-key.js 365              # one pro key valid 365 days
 *   node tools/mint-key.js 365 5            # five pro keys valid 365 days
 */
"use strict";
const { sign, validate } = require("../lib/license.js");

(async () => {
  const days = parseInt(process.argv[2], 10) || 0;
  const count = parseInt(process.argv[3], 10) || 1;
  const exp = days > 0 ? Math.floor(Date.now() / 1000) + days * 86400 : 0;

  for (let i = 0; i < count; i++) {
    const key = await sign({ exp });
    const check = await validate(key);
    const label = check.ok ? "OK" : "FAIL";
    const expiry = check.exp ? new Date(check.exp * 1000).toISOString() : "never";
    console.log(`${key}   [${label} · pro · expires ${expiry}]`);
  }
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
