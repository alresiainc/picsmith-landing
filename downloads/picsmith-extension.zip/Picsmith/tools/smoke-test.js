/**
 * Picsmith smoke test — runs the core libs headlessly in Node with minimal
 * canvas/2d-context stubs. Catches runtime errors (undefined refs, bad API
 * usage, broken pipeline) that syntax checks can't.
 */
"use strict";

// ------------------------------------------------------------------ stubs
function makeCtx(store, w, h) {
  const ctx = {
    canvas: { width: w || 0, height: h || 0 },
    save() {}, restore() {}, beginPath() {}, closePath() {},
    translate() {}, rotate() {}, scale() {}, clip() {},
    moveTo() {}, lineTo() {}, arc() {}, ellipse() {}, roundRect() {}, rect() {},
    bezierCurveTo() {}, fill() {}, stroke() {}, fillRect() {}, clearRect() {},
    fillText() {}, strokeText() {}, drawImage() {}, setTransform() {},
    createLinearGradient: () => ({ addColorStop() {} }),
    createRadialGradient: () => ({ addColorStop() {} }),
    measureText: () => ({ width: 10 }),
    getImageData: (x, y, cw, ch) => {
      const out = new Uint8ClampedArray(cw * ch * 4);
      if (store) {
        for (let yy = 0; yy < ch; yy++) {
          for (let xx = 0; xx < cw; xx++) {
            const si = ((y + yy) * w + (x + xx)) * 4;
            const di = (yy * cw + xx) * 4;
            if (si >= 0 && si + 4 <= store.length) out.set(store.subarray(si, si + 4), di);
          }
        }
      }
      return { data: out, width: cw, height: ch };
    },
    putImageData(img) { if (store) store.set(img.data); },
  };
  return ctx;
}

function makeCanvas(w, h, store) {
  return {
    width: w,
    height: h,
    getContext: () => makeCtx(store, w, h),
    toDataURL: () => "data:image/png;base64,",
  };
}

global.document = {
  createElement: (tag) => (tag === "canvas" ? makeCanvas(4, 4) : { style: {}, classList: { add() {}, remove() {}, toggle() {} } }),
};
global.window = global;
global.location = { search: "" };
global.chrome = { runtime: { sendMessage: async () => ({ ok: true }) }, storage: { local: { get: async () => ({}), set: async () => {} } } };

const fs = require("fs");
const path = require("path");
const assert = require("assert");
const root = path.join(__dirname, "..");

function loadAll() {
  const files = ["lib/project.js", "lib/canvas-engine.js", "lib/tools.js"];
  const code = files.map((f) => fs.readFileSync(path.join(root, f), "utf8")).join("\n;\n");
  const fn = new Function(code + "\n;return { PFProject, PFEngine, PFTools };");
  return fn();
}
const { PFProject, PFEngine, PFTools } = loadAll();

let passed = 0;
function ok(name, cond) {
  if (!cond) throw new Error("FAIL: " + name);
  passed++;
  console.log("  ✓ " + name);
}

// ------------------------------------------------------------------ mergeEffects
console.log("mergeEffects");
const fx = PFEngine.mergeEffects({ shadow: { on: true, blur: 5 } });
ok("defaults merged", fx.shadow.blur === 5 && fx.shadow.opacity === 0.45 && fx.bg.color === "#ffffff");

// ------------------------------------------------------------------ shape paths (all kinds)
console.log("pathShape kinds");
const kinds = ["rect", "ellipse", "line", "arrow", "triangle", "diamond", "pentagon", "hexagon", "star", "heart"];
for (const k of kinds) {
  const c = makeCanvas(200, 200).getContext();
  PFEngine.pathShape(c, k, 10, 10, 100, 80, { radius: 12, points: 5 });
  ok("pathShape " + k, true);
}

// ------------------------------------------------------------------ text + shape content render
console.log("renderContent");
const textLayer = PFProject.newLayer("text", { text: "Hello\nWorld", fontSize: 24, letterSpacing: 1.5 });
PFEngine.renderContent(textLayer);
ok("text renders", !!textLayer.content);

const shapeLayer = PFProject.newLayer("shape", { shapeKind: "star", shapeRect: { x: 0, y: 0, w: 90, h: 90 }, points: 8, fill: "#f00", stroke: "#000", strokeWidth: 3 });
PFEngine.renderContent(shapeLayer);
ok("star renders", !!shapeLayer.content);

// ------------------------------------------------------------------ flood fill
console.log("flood fill");
{
  const w = 12, h = 12;
  const store = new Uint8ClampedArray(w * h * 4);
  // checker: fill all white
  for (let i = 0; i < store.length; i += 4) { store[i] = 255; store[i + 1] = 255; store[i + 2] = 255; store[i + 3] = 255; }
  // a blue blocker at (6,6)
  const bi = (6 * w + 6) * 4;
  store[bi] = 0; store[bi + 1] = 0; store[bi + 2] = 255; store[bi + 3] = 255;
  const canvas = makeCanvas(w, h, store);
  const mask = PFEngine.floodFillMask(canvas, 0, 0, 24);
  ok("mask produced", !!mask && mask.length === w * h);
  ok("mask size", mask.reduce((a, b) => a + b, 0) === w * h - 1); // everything except blocker
  ok("blocker excluded", mask[6 * w + 6] === 0);
  PFEngine.applyMask(canvas, mask, "#00ff00");
  const after = store[0];
  ok("applyMask painted", store[0] === 0 && store[1] === 255 && store[2] === 0);
  ok("blocker untouched", store[bi] === 0 && store[bi + 1] === 0 && store[bi + 2] === 255);
}

// ------------------------------------------------------------------ drawLayer with effects
console.log("effects rendering");
{
  const doc = PFProject.createDoc({ width: 100, height: 100 });
  const imgLayer = PFProject.newLayer("raster", {
    content: makeCanvas(30, 30),
    transform: { x: 50, y: 50, rotation: 0.3, scaleX: 1.2, scaleY: 1 },
    effects: PFEngine.mergeEffects({
      shadow: { on: true, blur: 10, x: 4, y: 6, opacity: 0.6 },
      border: { on: true, color: "#ff0000", width: 5, radius: 8 },
      reflection: { on: true, opacity: 0.4, gap: 3, height: 0.5 },
      bg: { on: true, color: "#00ff00", radius: 8 },
    }),
  });
  doc.layers.push(imgLayer);
  const out = PFEngine.flattenDoc(doc);
  ok("flatten with effects", out.width === 100 && out.height === 100);
  ok("layerCorners", PFEngine.layerCorners(imgLayer).length === 4);
  ok("topLayerAt", PFEngine.topLayerAt(doc, { x: 50, y: 50 }) === imgLayer);
  const lp = PFEngine.layerPoint(imgLayer, { x: 50, y: 50 });
  ok("layerPoint", lp && Math.abs(lp.x - 15) < 0.1);
}

// ------------------------------------------------------------------ trimToContent
console.log("trimToContent");
{
  const w = 100, h = 80;
  const store = new Uint8ClampedArray(w * h * 4); // transparent everywhere
  // opaque red rect from (10,20) to (49,39) — off-centre
  for (let y = 20; y < 40; y++) {
    for (let x = 10; x < 50; x++) {
      const i = (y * w + x) * 4;
      store[i] = 255; store[i + 1] = 0; store[i + 2] = 0; store[i + 3] = 255;
    }
  }
  const canvas = makeCanvas(w, h, store);
  const layer = PFProject.newLayer("raster", {
    content: canvas,
    fullCanvas: true,
    transform: { x: 500, y: 400, rotation: 0, scaleX: 1, scaleY: 1 },
  });
  const trimmed = PFEngine.trimToContent(layer);
  ok("trimmed returned true", trimmed === true);
  ok("content cropped to 40x20", layer.content.width === 40 && layer.content.height === 20);
  // new content centre = (30, 30); old centre = (50, 40) → delta (-20, -10)
  ok("transform shifted X", Math.abs(layer.transform.x - 480) < 0.001);
  ok("transform shifted Y", Math.abs(layer.transform.y - 390) < 0.001);
  // trim again should be a no-op (nothing to crop)
  const again = PFEngine.trimToContent(layer);
  ok("second trim no-op", again === false);
}

// ------------------------------------------------------------------ tools factory
console.log("tool factory");
{
  const editor = {
    doc: PFProject.createDoc({ width: 100, height: 100 }),
    canvas: makeCanvas(100, 100),
    previewCanvas: makeCanvas(100, 100),
    zoom: 1,
    toolOptions: {
      size: 10, hardness: 0.8, opacity: 1, color: "#6366f1", tolerance: 24,
      gradType: "linear", color2: "#0ea5e9", points: 5,
      shapeKind: "rect", fill: "#6366f1", stroke: "#111827", strokeWidth: 3, radius: 12,
      textDefaults: { fontFamily: "Arial", fontSize: 64, fontWeight: 400, fontStyle: "normal", color: "#111827", align: "center" },
    },
    getSelected: () => null,
    getLayer: () => null,
    selectLayer() {}, addLayer() {}, removeLayer() {}, pushHistory() {}, markDirty() {},
    render() {}, refreshOverlay() {}, hitSelectionHandle: () => null, setColor() {},
    setTool() {}, openTextEditor() {}, updateCropOverlay() {}, showCropBar() {},
    clearCrop() {}, applyCrop() {}, panBy() {}, zoomTo() {}, toast() {},
  };
  for (const t of PFTools.TOOLS) {
    const inst = PFTools.createTool(t.id, editor);
    ok("createTool " + t.id, !!inst && typeof inst.pointerDown === "function" && typeof inst.deactivate === "function");
    inst.pointerDown({ x: 20, y: 20 }, { shiftKey: false, altKey: false, button: 0, currentTarget: { style: {} } });
    inst.pointerMove({ x: 30, y: 25 }, { movementX: 1, movementY: 1, shiftKey: false, currentTarget: { style: {} } });
    inst.pointerUp({ x: 30, y: 25 }, { currentTarget: { style: {} } });
    inst.deactivate();
  }
}

// ------------------------------------------------------------------ move tool: scaling + radius math
console.log("move tool math");
{
  const doc = PFProject.createDoc({ width: 400, height: 400 });
  const layer = PFProject.newLayer("shape", { shapeKind: "rect", shapeRect: { x: 0, y: 0, w: 100, h: 80 }, fill: "#f00" });
  PFEngine.renderContent(layer);
  layer.transform = { x: 200, y: 200, rotation: 0, scaleX: 2, scaleY: 2 };
  doc.layers.push(layer);
  const editor = {
    doc,
    canvas: makeCanvas(400, 400),
    previewCanvas: makeCanvas(400, 400),
    zoom: 1,
    toolOptions: {},
    getSelected: () => layer,
    getLayer: () => layer,
    selectLayer() {}, addLayer() {}, removeLayer() {}, pushHistory() {}, markDirty() {},
    render() {}, refreshOverlay() {}, setColor() {},
    setTool() {}, openTextEditor() {}, updateCropOverlay() {}, showCropBar() {},
    clearCrop() {}, applyCrop() {}, panBy() {}, zoomTo() {}, toast() {},
    hitSelectionHandle: () => "scale:2",
  };
  const move = PFTools.createTool("move", editor);

  // Corner scaling: drag the bottom-right corner to (400,400). Content canvas is
  // padded by strokeWidth+4, so derive half-sizes from the real content. The
  // anchor (top-left) must stay pinned — the old math drifted on pre-scaled layers.
  const hw = layer.content.width / 2, hh = layer.content.height / 2;
  const anchor = { x: 200 - 2 * hw, y: 200 - 2 * hh };
  const br = { x: 200 + 2 * hw, y: 200 + 2 * hh };
  move.pointerDown({ x: br.x, y: br.y }, { shiftKey: false, button: 0, currentTarget: { style: {} } });
  move.pointerMove({ x: 400, y: 400 }, { shiftKey: false, movementX: 0, movementY: 0, currentTarget: { style: {} } });
  ok("corner scale on pre-scaled layer",
    Math.abs(layer.transform.scaleX - (400 - anchor.x) / (2 * hw)) < 1e-9 &&
    Math.abs(layer.transform.scaleY - (400 - anchor.y) / (2 * hh)) < 1e-9);
  const tl = PFEngine.layerCorners(layer)[0];
  ok("scale anchor pinned", Math.abs(tl.x - anchor.x) < 1e-9 && Math.abs(tl.y - anchor.y) < 1e-9);
  move.pointerUp({ x: 400, y: 400 }, { currentTarget: { style: {} } });

  // Bottom edge handle (scale:6) — only Y scales; X untouched.
  editor.hitSelectionHandle = () => "scale:6";
  const t2 = { ...layer.transform };
  const anchorY2 = t2.y - t2.scaleY * hh;
  const expSy2 = (340 - anchorY2) / (2 * hh);
  move.pointerDown({ x: t2.x, y: t2.y + t2.scaleY * hh }, { shiftKey: false, button: 0, currentTarget: { style: {} } });
  move.pointerMove({ x: t2.x, y: 340 }, { shiftKey: false, movementX: 0, movementY: 0, currentTarget: { style: {} } });
  ok("edge handle scales one axis", Math.abs(layer.transform.scaleX - t2.scaleX) < 1e-9 && Math.abs(layer.transform.scaleY - expSy2) < 1e-9);
  move.pointerUp({ x: t2.x, y: 340 }, { currentTarget: { style: {} } });

  // Radius handle — drag along the top edge sets layer.radius (content units).
  editor.hitSelectionHandle = () => "radius";
  const t3 = layer.transform;
  const rp0 = { x: t3.x, y: t3.y - t3.scaleY * hh };
  move.pointerDown({ x: rp0.x, y: rp0.y }, { shiftKey: false, button: 0, currentTarget: { style: {} } });
  move.pointerMove({ x: t3.x + 20 * t3.scaleX, y: rp0.y }, { shiftKey: false, movementX: 0, movementY: 0, currentTarget: { style: {} } });
  ok("radius drag sets shape radius", Math.abs(layer.radius - 20) < 1e-9);
  move.pointerUp({ x: t3.x + 20 * t3.scaleX, y: rp0.y }, { currentTarget: { style: {} } });
}

console.log(`\nAll ${passed} smoke checks passed ✅`);
