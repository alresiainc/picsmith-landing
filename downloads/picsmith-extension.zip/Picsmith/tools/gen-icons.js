// Picsmith icon generator — renders a gradient tile + magic spark to PNG.
// Pure Node.js (zlib built-in), no dependencies. Run: node tools/gen-icons.js
"use strict";
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

// ---------- PNG encoder ----------
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, "ascii");
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

function encodePNG(width, height, rgba) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6; // RGBA
  const raw = Buffer.alloc(height * (1 + width * 4));
  for (let y = 0; y < height; y++) {
    raw[y * (1 + width * 4)] = 0;
    rgba.copy(raw, y * (1 + width * 4) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([sig, chunk("IHDR", ihdr), chunk("IDAT", idat), chunk("IEND", Buffer.alloc(0))]);
}

// ---------- math helpers ----------
const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (v) => Math.max(0, Math.min(1, v));

// 4-pointed magic spark (normalized 0..1 coords)
const SPARK = [
  [0.5, 0.055], [0.622, 0.378], [0.945, 0.5], [0.622, 0.622],
  [0.5, 0.945], [0.378, 0.622], [0.055, 0.5], [0.378, 0.378],
];
const DOTS = [
  [0.24, 0.79, [56, 222, 244]],   // cyan
  [0.36, 0.79, [251, 191, 36]],   // amber
  [0.48, 0.79, [251, 113, 133]],  // rose
];

function inPolygon(px, py, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
    if (yi > py !== yj > py && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

function roundedRectSDF(px, py, w, h, r) {
  const cx = clamp01(px / w), cy = clamp01(py / h);
  const dx = px - cx * w, dy = py - cy * h;
  return Math.sqrt(dx * dx + dy * dy) - r;
}

// ---------- renderer ----------
function renderIcon(size) {
  const SS = 4;
  const W = size, H = size;
  const img = Buffer.alloc(W * H * 4);
  const ss = SS * SS;

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let sy = 0; sy < SS; sy++) {
        for (let sx = 0; sx < SS; sx++) {
          const px = x + (sx + 0.5) / SS;
          const py = y + (sy + 0.5) / SS;

          const m = Math.max(1.5, size * 0.045);
          const bw = size - m * 2, bh = size - m * 2;
          const dist = roundedRectSDF(px - m, py - m, bw, bh, size * 0.24);
          let cover = clamp01(0.5 - dist);
          if (cover <= 0) continue;

          // diagonal gradient: deep indigo -> violet -> magenta
          const t = clamp01((px / size) * 0.45 + (py / size) * 0.75);
          const c1 = [24, 14, 64];   // #180e40
          const c2 = [109, 40, 217]; // #6d28d9
          const c3 = [217, 70, 160]; // #d946a0
          let cr = t < 0.55 ? lerp(c1[0], c2[0], t / 0.55) : lerp(c2[0], c3[0], (t - 0.55) / 0.45);
          let cg = t < 0.55 ? lerp(c1[1], c2[1], t / 0.55) : lerp(c2[1], c3[1], (t - 0.55) / 0.45);
          let cb = t < 0.55 ? lerp(c1[2], c2[2], t / 0.55) : lerp(c2[2], c3[2], (t - 0.55) / 0.45);

          // soft cyan glow near top-left
          const gd = Math.sqrt((px - size * 0.38) ** 2 + (py - size * 0.3) ** 2) / (size * 0.6);
          const glow = clamp01(1 - gd) * 0.42;
          cr = lerp(cr, 103, glow); cg = lerp(cg, 232, glow); cb = lerp(cb, 249, glow);

          // magic spark (white)
          if (inPolygon(px, py, SPARK.map(([sx2, sy2]) => [sx2 * size, sy2 * size]))) {
            cr = lerp(cr, 255, 0.97); cg = lerp(cg, 255, 0.97); cb = lerp(cb, 255, 0.97);
          }

          // palette dots
          for (const [dx, dy, col] of DOTS) {
            const rr = size * 0.085;
            const ddx = px - dx * size, ddy = py - dy * size;
            const dc = Math.sqrt(ddx * ddx + ddy * ddy);
            const dotCover = clamp01((rr - dc) / 1.2);
            if (dotCover > 0) {
              cr = lerp(cr, col[0], dotCover * 0.95);
              cg = lerp(cg, col[1], dotCover * 0.95);
              cb = lerp(cb, col[2], dotCover * 0.95);
            }
          }

          // top rim light
          const rimAmt = clamp01(0.5 - (dist + 1.1)) * 0.5 * (size >= 32 ? 1 : 0.55);
          cr = lerp(cr, 196, rimAmt); cg = lerp(cg, 181, rimAmt); cb = lerp(cb, 253, rimAmt);

          r += cr * cover; g += cg * cover; b += cb * cover; a += cover * 255;
        }
      }
      const i = (y * W + x) * 4;
      img[i] = Math.round(r / ss);
      img[i + 1] = Math.round(g / ss);
      img[i + 2] = Math.round(b / ss);
      img[i + 3] = Math.round(a / ss);
    }
  }
  return encodePNG(W, H, img);
}

const outDir = path.join(__dirname, "..", "icons");
fs.mkdirSync(outDir, { recursive: true });
for (const s of [16, 32, 48, 128]) {
  const file = path.join(outDir, `icon${s}.png`);
  fs.writeFileSync(file, renderIcon(s));
  console.log(`wrote ${file}`);
}
