/**
 * Background-segmentation worker.
 *
 * Runs U²-Net (u2netp) through ONNX Runtime Web. The RUNTIME'S OWN CODE
 * (this file, ort.wasm.min.mjs, ort-wasm-simd-threaded.mjs) ships inside the
 * extension — a Manifest V3 CSP of script-src 'self' means remote *script*
 * can never be loaded, bundled or not. What's remote is just two BINARIES —
 * the ~10.5MB wasm build of the runtime and the ~4.6MB model weights — which
 * are fetched as plain bytes on first use, cached in Cache Storage, and fed
 * to ORT directly (`wasmBinary` / a Uint8Array to `InferenceSession.create`).
 * No script ever executes from picsmith.alresia.tech; it only ever serves
 * data this worker's own bundled code chooses to compile.
 *
 * After the first successful run everything is served from the cache, so
 * this is genuinely offline from then on — same as the rest of the editor.
 *
 * Protocol
 *   in : { type:"segment", id, width, height, rgba:ArrayBuffer, assetBase }
 *   out: { type:"progress", id, stage:"downloading"|"loading"|"running", pct? }
 *   out: { type:"mask", id, size, mask:ArrayBuffer }   // size×size Float32 alpha 0..1
 *   out: { type:"error", id?, error }
 */
import * as ort from "../vendor/ort/ort.wasm.min.mjs";

const SIZE = 320; // u2netp's native input resolution
const CACHE_NAME = "picsmith-ai-assets-v1";

let session = null;
let loading = null;

/**
 * Fetch a URL's bytes, serving from Cache Storage on every call after the
 * first. Reports download progress via `onProgress(loaded, total)` — total
 * may be 0 if the server doesn't send Content-Length.
 */
async function fetchBytesCached(url, onProgress) {
  const cache = await caches.open(CACHE_NAME);
  const hit = await cache.match(url);
  if (hit) return new Uint8Array(await hit.arrayBuffer());

  const res = await fetch(url);
  if (!res.ok) throw new Error(`Couldn't download ${url.split("/").pop()} (server said ${res.status}).`);

  // Cache the untouched response before we consume it, so a HEAD-less content
  // length or a read error never leaves a half-cached entry.
  const toCache = res.clone();

  const total = parseInt(res.headers.get("content-length") || "0", 10);
  if (!res.body || !onProgress) {
    const buf = new Uint8Array(await res.arrayBuffer());
    await cache.put(url, toCache);
    return buf;
  }

  const reader = res.body.getReader();
  const chunks = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    loaded += value.byteLength;
    onProgress(loaded, total);
  }
  const buf = new Uint8Array(loaded);
  let off = 0;
  for (const c of chunks) { buf.set(c, off); off += c.byteLength; }
  await cache.put(url, toCache);
  return buf;
}

/** True once both assets are already sitting in the cache — no download needed. */
async function assetsCached(assetBase) {
  const cache = await caches.open(CACHE_NAME);
  const [a, b] = await Promise.all([
    cache.match(`${assetBase}/ort-wasm-simd-threaded.wasm`),
    cache.match(`${assetBase}/u2netp.onnx`),
  ]);
  return !!(a && b);
}

/** Build the session once and reuse it — loading it costs real time either way. */
function ensureSession(assetBase, onProgress) {
  if (session) return Promise.resolve(session);
  if (loading) return loading;

  loading = (async () => {
    // `total` comes from Content-Length, which describes bytes ON THE WIRE.
    // fetch() transparently decompresses the response body, so if the host
    // gzip/brotli-compresses these files (GitHub Pages does, for eligible
    // types), decoded bytes read can exceed the wire size — percentages went
    // over 100% (seen up to 328% in testing) before this guard existed. Once
    // that mismatch is caught, stop trusting `total` for the rest of that
    // transfer rather than keep emitting a number that no longer means anything.
    const report = (label) => {
      let trustworthy = true;
      return (loaded, total) => {
        if (trustworthy && total && loaded > total) trustworthy = false;
        const pct = trustworthy && total ? Math.min(99, Math.round((loaded / total) * 100)) : null;
        onProgress && onProgress("downloading", pct, label);
      };
    };

    onProgress && onProgress("downloading", 0, "runtime");
    const wasmBytes = await fetchBytesCached(`${assetBase}/ort-wasm-simd-threaded.wasm`, report("runtime"));
    onProgress && onProgress("downloading", 0, "model");
    const modelBytes = await fetchBytesCached(`${assetBase}/u2netp.onnx`, report("model"));

    onProgress && onProgress("loading", null);
    ort.env.wasm.wasmBinary = wasmBytes; // skips ORT's own fetch entirely — see env.d.ts
    ort.env.wasm.numThreads = (typeof SharedArrayBuffer !== "undefined")
      ? Math.max(1, Math.min(4, self.navigator?.hardwareConcurrency || 1))
      : 1;
    ort.env.logLevel = "error";

    session = await ort.InferenceSession.create(modelBytes, {
      executionProviders: ["wasm"],
      graphOptimizationLevel: "all",
    });
    return session;
  })();

  loading.catch(() => { loading = null; }); // let a failed attempt be retried
  return loading;
}

/**
 * U²-Net wants a 320×320 RGB tensor in CHW order, normalised the way the
 * original repo does: scale to 0..1 against the image's own max, then apply
 * ImageNet mean/std.
 */
function toTensor(rgba, w, h) {
  const chw = new Float32Array(3 * SIZE * SIZE);
  const MEAN = [0.485, 0.456, 0.406];
  const STD = [0.229, 0.224, 0.225];
  const plane = SIZE * SIZE;

  let maxV = 0;
  const tmp = new Float32Array(3 * plane);
  for (let y = 0; y < SIZE; y++) {
    const sy = Math.min(h - 1, Math.floor((y * h) / SIZE));
    for (let x = 0; x < SIZE; x++) {
      const sx = Math.min(w - 1, Math.floor((x * w) / SIZE));
      const si = (sy * w + sx) * 4;
      const di = y * SIZE + x;
      const r = rgba[si], g = rgba[si + 1], b = rgba[si + 2];
      tmp[di] = r; tmp[plane + di] = g; tmp[2 * plane + di] = b;
      if (r > maxV) maxV = r;
      if (g > maxV) maxV = g;
      if (b > maxV) maxV = b;
    }
  }
  const scale = maxV > 0 ? 1 / maxV : 1 / 255;
  for (let c = 0; c < 3; c++) {
    for (let i = 0; i < plane; i++) {
      chw[c * plane + i] = (tmp[c * plane + i] * scale - MEAN[c]) / STD[c];
    }
  }
  return chw;
}

self.onmessage = async (e) => {
  const msg = e.data || {};
  try {
    if (msg.type === "check") {
      self.postMessage({ type: "cached", id: msg.id, cached: await assetsCached(msg.assetBase) });
      return;
    }

    if (msg.type === "segment") {
      const { id, width, height, assetBase } = msg;
      const rgba = new Uint8ClampedArray(msg.rgba);

      const sess = await ensureSession(assetBase, (stage, pct, label) =>
        self.postMessage({ type: "progress", id, stage, pct, label }));

      self.postMessage({ type: "progress", id, stage: "running" });
      const input = new ort.Tensor("float32", toTensor(rgba, width, height), [1, 3, SIZE, SIZE]);
      const out = await sess.run({ [sess.inputNames[0]]: input });

      // u2netp emits seven side outputs; the first is the refined one.
      const raw = out[sess.outputNames[0]].data;

      // Normalise to 0..1 — the network's range drifts per image.
      let mn = Infinity, mx = -Infinity;
      for (let i = 0; i < raw.length; i++) {
        if (raw[i] < mn) mn = raw[i];
        if (raw[i] > mx) mx = raw[i];
      }
      const span = mx - mn || 1;
      const mask = new Float32Array(raw.length);
      for (let i = 0; i < raw.length; i++) mask[i] = (raw[i] - mn) / span;

      self.postMessage({ type: "mask", id, size: SIZE, mask: mask.buffer }, [mask.buffer]);
      return;
    }
  } catch (err) {
    session = null; // don't let a bad session poison every future attempt
    self.postMessage({ type: "error", id: msg.id, error: String((err && err.message) || err) });
  }
};
