# Third-party components

Picsmith bundles these so background removal works with no network access.
Both licences permit commercial use, including the paid Pro tier.

## ONNX Runtime Web — `vendor/ort/`
Microsoft. **MIT licence.** Version 1.19.2.
Only the WASM backend is shipped (`ort.wasm.min.js`, `ort.wasm.min.mjs`,
`ort-wasm-simd-threaded.mjs`, `ort-wasm-simd-threaded.wasm`).
https://github.com/microsoft/onnxruntime

## U²-Net (u2netp) — `models/u2netp.onnx`
Qin et al., "U²-Net: Going Deeper with Nested U-Structure for Salient Object
Detection". **Apache-2.0 licence.** The small 4.6MB variant.
Weights obtained from the rembg distribution of the authors' released model.
https://github.com/xuebinqin/U-2-Net

Deliberately NOT used: MODNet and RMBG-1.4. Both are far better known for this
task, and both are licensed for non-commercial use only, which would conflict
with charging for Pro.
