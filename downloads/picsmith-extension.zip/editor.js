/* Picsmith editor — main controller. Vanilla JS, no build step. */
"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const els = {
    menuBar: $("menuBar"),
    docName: $("docName"), undoBtn: $("undoBtn"), redoBtn: $("redoBtn"),
    zoomOut: $("zoomOut"), zoomLabel: $("zoomLabel"), zoomIn: $("zoomIn"), zoomFit: $("zoomFit"),
    newBtn: $("newBtn"), saveBtn: $("saveBtn"), exportBtn: $("exportBtn"), proBadge: $("proBadge"),
    contextBar: $("contextBar"),
    leftBar: $("leftBar"),
    workspace: $("workspace"), workspaceWrap: $("workspaceWrap"),
    stage: $("stage"), docCanvas: $("docCanvas"), previewCanvas: $("previewCanvas"),
    snapLayer: $("snapLayer"),
    selectionOverlay: $("selectionOverlay"), cropOverlay: $("cropOverlay"), brushCursor: $("brushCursor"),
    hudZoom: $("hudZoom"), hudSize: $("hudSize"), hudTool: $("hudTool"), hudHint: $("hudHint"), hudCursor: $("hudCursor"),
    dragHint: $("dragHint"),
    rightPanel: $("rightPanel"), ctxMenu: $("ctxMenu"),
    presetGrid: $("presetGrid"),
    fxBrightness: $("fxBrightness"), fxContrast: $("fxContrast"), fxSaturate: $("fxSaturate"),
    fxHue: $("fxHue"), fxBlur: $("fxBlur"), fxSharpen: $("fxSharpen"),
    vBrightness: $("vBrightness"), vContrast: $("vContrast"), vSaturate: $("vSaturate"),
    vHue: $("vHue"), vBlur: $("vBlur"), vSharpen: $("vSharpen"),
    applyFxBtn: $("applyFxBtn"), resetFxBtn: $("resetFxBtn"), resizeBtn: $("resizeBtn"),
    layersList: $("layersList"), btnAddImage: $("btnAddImage"), btnAddText: $("btnAddText"),
    btnAddShape: $("btnAddShape"), btnAddBrush: $("btnAddBrush"),
    layerOpacity: $("layerOpacity"), layerOpacityVal: $("layerOpacityVal"),
    layerUp: $("layerUp"), layerDown: $("layerDown"), layerDup: $("layerDup"), layerDel: $("layerDel"),
    aiOwnKeyInput: $("aiOwnKeyInput"), aiPrompt: $("aiPrompt"), aiGo: $("aiGo"),
    aiThread: $("aiThread"), aiChatNew: $("aiChatNew"), aiEngineStatus: $("aiEngineStatus"),
    aiEngineDot: $("aiEngineDot"), aiEngineText: $("aiEngineText"), aiByokStrip: $("aiByokStrip"),
    aiByokDismiss: $("aiByokDismiss"),
    setKey: $("setKey"), setModel: $("setModel"), setProvider: $("setProvider"),
    setBaseUrlField: $("setBaseUrlField"), setBaseUrl: $("setBaseUrl"), setBaseUrlConnect: $("setBaseUrlConnect"),
    licKeyInput: $("licKeyInput"), licActivateBtn: $("licActivateBtn"), licClearBtn: $("licClearBtn"), licStatus: $("licStatus"),
    btnDownloadProject: $("btnDownloadProject"), btnClearProjects: $("btnClearProjects"), btnResetAll: $("btnResetAll"),
    setUpdateCheck: $("setUpdateCheck"), btnCheckUpdate: $("btnCheckUpdate"), btnGetUpdate: $("btnGetUpdate"),
    updateStatus: $("updateStatus"), btnSupport: $("btnSupport"),
    verText: $("verText"),
    textPop: $("textPop"), textPopInput: $("textPopInput"),
    templateGrid: $("templateGrid"), newW: $("newW"), newH: $("newH"), newCreateBtn: $("newCreateBtn"),
    fmtSeg: $("fmtSeg"), expQuality: $("expQuality"), expQualityVal: $("expQualityVal"),
    expSizeNote: $("expSizeNote"), expDims: $("expDims"), expBtn: $("expBtn"),
    resW: $("resW"), resH: $("resH"), resizeApply: $("resizeApply"),
    confirmText: $("confirmText"), confirmTitle: $("confirmTitle"),
    confirmOk: $("confirmOk"), confirmCancel: $("confirmCancel"),
    toast: $("toast"), tooltip: $("tooltip"),
    modalImageTool: $("modalImageTool"), itTitle: $("itTitle"), itDesc: $("itDesc"),
    itControls: $("itControls"), itStatus: $("itStatus"),
    itApply: $("itApply"), itCancel: $("itCancel"), itReset: $("itReset"),
    inspector: $("inspector"), inspIcon: $("inspIcon"), inspName: $("inspName"), inspType: $("inspType"),
    inspEye: $("inspEye"), inspLock: $("inspLock"), inspDup: $("inspDup"), inspDel: $("inspDel"), inspReturn: $("inspReturn"),
    inspX: $("inspX"), inspY: $("inspY"), inspW: $("inspW"), inspH: $("inspH"),
    inspRot: $("inspRot"), inspOp: $("inspOp"), inspBlend: $("inspBlend"),
    inspFlipX: $("inspFlipX"), inspFlipY: $("inspFlipY"),
    inspRotL: $("inspRotL"), inspRotR: $("inspRotR"),
    inspToFront: $("inspToFront"), inspFwd: $("inspFwd"), inspBack: $("inspBack"), inspToBack: $("inspToBack"),
    inspTypeSection: $("inspTypeSection"),
    fxShadowOn: $("fxShadowOn"), fxShadowColor: $("fxShadowColor"), fxShadowBlur: $("fxShadowBlur"),
    fxShadowX: $("fxShadowX"), fxShadowY: $("fxShadowY"), fxShadowOp: $("fxShadowOp"),
    fxBorderOn: $("fxBorderOn"), fxBorderColor: $("fxBorderColor"), fxBorderWidth: $("fxBorderWidth"), fxBorderRadius: $("fxBorderRadius"),
    fxReflOn: $("fxReflOn"), fxReflOp: $("fxReflOp"), fxReflGap: $("fxReflGap"), fxReflH: $("fxReflH"),
    fxBgOn: $("fxBgOn"), fxBgColor: $("fxBgColor"), fxBgRadius: $("fxBgRadius"),
  };

  // ================================================================== state
  const FONTS = [
    "Arial", "Helvetica", "Georgia", "Times New Roman", "Courier New", "Verdana",
    "Trebuchet MS", "Impact", "Comic Sans MS", "Palatino", "Tahoma", "Segoe UI",
  ];

  const state = {
    doc: null,
    tool: "move",
    toolInstance: null,
    selectedId: null,
    zoom: 1,
    undoStack: [],
    redoStack: [],
    saveTimer: null,
    settings: {},
    license: null,
    previousPaintTool: "brush",
    toolOptions: {
      size: 14, hardness: 0.85, opacity: 1, color: "#6366f1",
      strength: 50, // sharpen / dodge / burn intensity, 0-100
      tolerance: 24,
      gradType: "linear", color2: "#0ea5e9",
      points: 5,
      shapeKind: "rect", fill: "#6366f1", stroke: "#111827", strokeWidth: 3, radius: 12,
      textDefaults: { fontFamily: "Arial", fontSize: 64, fontWeight: 400, fontStyle: "normal", color: "#111827", align: "center", letterSpacing: 0, upper: false },
    },
    fx: { brightness: 0, contrast: 0, saturate: 0, hue: 0, blur: 0, sharpen: 0 },
    cropRect: null,
    aiBusy: false, // true while a cloud AI request (chat stream, or the inspector's AI-bg edit) is in flight
    aiChatStreaming: false,
    layersTabActive: false,
    // Which right-dock tab is active (elements/adjust/layers/ai/settings) —
    // independent of selection, so switching tabs never deselects the item
    // you're working on. See renderRightDock().
    rpTab: "elements",
    itemDragActive: false,
    dragging: false,
    middlePan: false,
    exportFormat: "png",
    textPopOrig: "",
    clipboard: null,
    updateInfo: null,
    pasteCount: 0,
    lastCanvasPt: null,
    showGrid: false,
    snapEnabled: true,
    snapLines: [],
    swatches: [],
  };

  // Quick-start suggestions shown above an empty AI Chat composer — every one
  // of these routes cleanly through the offline command router with no cloud
  // needed, so they work identically whether or not you have a key/Pro.
  const AI_CHAT_SUGGESTIONS = [
    "Make this black and white", "Add a vignette", "Rotate it 90 degrees",
    "Remove the background", "Brighten it a little", "Add some text",
  ];

  // ================================================================== helpers
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const selectedLayer = () => layerById(state.selectedId);
  const layerById = (id) => (state.doc ? state.doc.layers.find((l) => l.id === id) : null);

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Failed to load image"));
      img.src = src;
    });
  }

  function cloneCanvas(c) {
    const n = document.createElement("canvas");
    n.width = c.width;
    n.height = c.height;
    n.getContext("2d").drawImage(c, 0, 0);
    return n;
  }

  function sendMessage(msg) {
    return chrome.runtime.sendMessage(msg).catch((err) => ({ ok: false, error: String(err) }));
  }

  let toastTimer = null;
  function toast(message, isError = false) {
    els.toast.textContent = message;
    els.toast.classList.toggle("error", !!isError);
    els.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove("show"), 2600);
  }

  // ================================================================== boot
  async function boot() {
    buildStageWrap();
    moveBrushCursorToWorkspace();
    renderToolRail();
    renderTemplates();
    renderPresets();
    bindMenuBar();
    bindTopbar();
    bindPanels();
    bindModals();
    bindShortcuts();
    bindDnD();
    bindSettingsUI();
    initTooltips();
    bindInspector();
    renderElementsPanel();
    bindRenameUI();
    initItemDrag();
    bindDockResizer();
    bindContextMenu();
    bindImageToolModal();
    setTool("move");

    await loadSettings();
    renderProUI();
    // Respects the setting and the once-a-day throttle; a no-op when off.
    runUpdateCheck();

    const params = new URLSearchParams(location.search);
    const docId = params.get("id");
    const newTpl = params.get("new");
    if (docId) {
      await loadProject(docId);
    } else if (newTpl) {
      createFromTemplate(newTpl);
    } else {
      createFromTemplate("instagram-post");
      openModal("modalNew");
    }
    updateHud();
  }

  function buildStageWrap() {
    const wrap = document.createElement("div");
    wrap.className = "stage-wrap";
    els.workspace.insertBefore(wrap, els.stage);
    wrap.appendChild(els.stage);
    els.stageWrap = wrap;
    // The text popover is positioned in workspace coordinates.
    els.workspaceWrap.appendChild(els.textPop);
  }

  function moveBrushCursorToWorkspace() {
    els.workspace.appendChild(els.brushCursor);
  }

  // ================================================================== document
  function createFromTemplate(tid, opts = {}) {
    const t = PFProject.TEMPLATES.find((x) => x.id === tid);
    state.doc = PFProject.createDoc({
      name: opts.name || (t ? t.name : "Untitled design"),
      width: opts.width || (t ? t.w : 1080),
      height: opts.height || (t ? t.h : 1080),
      template: tid,
      background: opts.background != null ? opts.background : "#ffffff",
    });
    state.selectedId = null;
    closeAllModals();
    setupCanvas(true);
    render();
    renderLayersPanel();
    renderAIChatThread();
    updateTopbar();
    els.docName.value = state.doc.name;
    resetHistory();
  }

  async function loadProject(id) {
    try {
      const record = await PFDB.get("projects", id);
      if (!record) throw new Error("Project not found");
      state.doc = await PFProject.deserializeDoc(record.data);
      state.selectedId = null;
      closeAllModals(); // none of the modal-back overlays default to hidden in markup alone
      setupCanvas(true);
      render();
      renderLayersPanel();
      renderAIChatThread();
      updateTopbar();
      els.docName.value = state.doc.name;
      resetHistory();
      toast("Project loaded");
    } catch (err) {
      toast("Could not load project", true);
      createFromTemplate("instagram-post");
    }
  }

  function setupCanvas(fit = true) {
    const d = state.doc;
    els.docCanvas.width = d.width;
    els.docCanvas.height = d.height;
    els.previewCanvas.width = d.width;
    els.previewCanvas.height = d.height;
    // The stage's children (canvases + overlays) are all absolutely positioned,
    // so the stage would collapse to 0×0 without explicit dimensions — which
    // would clip/hide the whole artboard. Unscaled size is zoom-independent.
    els.stage.style.width = `${d.width}px`;
    els.stage.style.height = `${d.height}px`;
    if (fit) zoomFit();
    updateHud();
  }

  function updateHud() {
    els.hudSize.textContent = `${state.doc.width} × ${state.doc.height}`;
    els.hudZoom.textContent = `${Math.round(state.zoom * 100)}%`;
  }

  // ================================================================== render
  function render() {
    PFEngine.renderDoc(els.docCanvas, state.doc);
    refreshOverlay();
    syncInspector();
  }

  function refreshOverlay() {
    els.selectionOverlay.innerHTML = "";
    clearHover();
    const layer = selectedLayer();
    if (!layer || !layer.content) return;
    const corners = PFEngine.layerCorners(layer);
    if (!corners.length) return;
    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);

    const box = document.createElement("div");
    box.className = "sel-box";
    box.style.cssText = `left:${minX}px;top:${minY}px;width:${maxX - minX}px;height:${maxY - minY}px;`;
    els.selectionOverlay.appendChild(box);

    corners.forEach((c, i) => {
      const h = document.createElement("div");
      h.className = "sel-handle";
      h.dataset.hdl = `c${i}`;
      h.style.cssText = `left:${c.x}px;top:${c.y}px;`;
      els.selectionOverlay.appendChild(h);
    });

    // Edge midpoints for single-axis resize: right, bottom, left.
    // (The top edge is reserved for the corner-radius handle.)
    const edgeMids = [
      { x: (corners[1].x + corners[2].x) / 2, y: (corners[1].y + corners[2].y) / 2 },
      { x: (corners[2].x + corners[3].x) / 2, y: (corners[2].y + corners[3].y) / 2 },
      { x: (corners[3].x + corners[0].x) / 2, y: (corners[3].y + corners[0].y) / 2 },
    ];
    edgeMids.forEach((m, i) => {
      const h = document.createElement("div");
      h.className = "sel-handle edge";
      h.dataset.hdl = `e${i + 1}`;
      h.style.cssText = `left:${m.x}px;top:${m.y}px;`;
      els.selectionOverlay.appendChild(h);
    });

    // Rotate handle — offset above the top edge midpoint.
    const edge = { x: corners[1].x - corners[0].x, y: corners[1].y - corners[0].y };
    const len = Math.hypot(edge.x, edge.y) || 1;
    const mid = { x: (corners[0].x + corners[1].x) / 2, y: (corners[0].y + corners[1].y) / 2 };
    const off = 26 / state.zoom;
    const rh = document.createElement("div");
    rh.className = "sel-rotate";
    rh.dataset.hdl = "rot";
    rh.style.cssText = `left:${mid.x + (-edge.y / len) * off}px;top:${mid.y + (edge.x / len) * off}px;`;
    els.selectionOverlay.appendChild(rh);

    // Corner-radius handle — rides the top edge, offset right by the radius.
    const rp = radiusHandlePoint(layer);
    if (rp) {
      const rad = document.createElement("div");
      rad.className = "sel-radius";
      rad.dataset.hdl = "radius";
      rad.style.cssText = `left:${rp.x}px;top:${rp.y}px;`;
      els.selectionOverlay.appendChild(rad);
    }
  }

  // ---------------------------------------------------------------- selection helpers

  /** Map a content-space point through the layer transform into doc space. */
  function layerContentToDoc(layer, lx, ly) {
    const t = layer.transform;
    const cos = Math.cos(t.rotation), sin = Math.sin(t.rotation);
    const sx = t.scaleX || 1, sy = t.scaleY || 1;
    return {
      x: t.x + (lx * sx * cos - ly * sy * sin),
      y: t.y + (lx * sx * sin + ly * sy * cos),
    };
  }

  /** The layer's current corner radius (content units). */
  function effectiveRadius(layer) {
    if (layer.type === "shape") return Math.max(0, layer.radius || 0);
    const fx = PFEngine.mergeEffects(layer.effects);
    return Math.max(0, fx.border.radius || 0, fx.bg.radius || 0);
  }

  /** True when dragging the radius handle actually changes something visible. */
  function radiusHandleVisible(layer) {
    if (layer.type === "shape") return layer.shapeKind === "rect";
    if (layer.type === "text") {
      const fx = PFEngine.mergeEffects(layer.effects);
      return !!(fx.border.on && fx.border.width > 0);
    }
    return true; // raster — the radius clip always applies
  }

  /** Doc position of the corner-radius drag handle (top edge of the box). */
  function radiusHandlePoint(layer) {
    const c = layer.content;
    if (!c || !radiusHandleVisible(layer)) return null;
    const r = Math.min(effectiveRadius(layer), Math.max(0, c.width / 2 - 1));
    return layerContentToDoc(layer, r, -c.height / 2);
  }

  function clearHover() {
    if (state.hoverEl) { state.hoverEl.classList.remove("hot"); state.hoverEl = null; }
    if (els.dragHint) els.dragHint.classList.add("hidden");
  }

  function hdlAttrFor(hit) {
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      return i < 4 ? `c${i}` : `e${i - 4}`;
    }
    return hit === "rotate" ? "rot" : hit; // "radius"
  }

  function cursorForHandle(hit) {
    if (hit === "move") return "move";
    if (hit === "rotate") return "grab";
    if (hit === "radius") return "ew-resize";
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      if (i < 4) return i % 2 === 0 ? "nwse-resize" : "nesw-resize";
      return i === 6 ? "ns-resize" : "ew-resize";
    }
    return "default";
  }

  function labelForHandle(hit) {
    if (hit === "move") return "Move";
    if (hit === "rotate") return "Rotate — drag to turn";
    if (hit === "radius") return "Corner radius — drag along the edge";
    if (hit.startsWith("scale:")) {
      const i = parseInt(hit.split(":")[1], 10);
      if (i < 4) return "Resize — drag the corner";
      return i === 5 || i === 7 ? "Resize width" : "Resize height";
    }
    return "";
  }

  function showDragHint(text, pt) {
    const hint = els.dragHint;
    hint.textContent = text;
    const wrapR = els.workspace.getBoundingClientRect();
    const stageR = els.stage.getBoundingClientRect();
    hint.style.left = stageR.left - wrapR.left + pt.x * state.zoom + "px";
    hint.style.top = stageR.top - wrapR.top + pt.y * state.zoom + "px";
    hint.classList.remove("hidden");
  }

  function updateHover(e) {
    if (state.itemDragActive) return;
    if (state.hoverEl) { state.hoverEl.classList.remove("hot"); state.hoverEl = null; }
    const layer = selectedLayer();
    const pt = docPoint(e);
    const hit = layer && layer.content && state.tool === "move" ? hitSelectionHandle(pt) : null;
    if (hit) {
      const el = els.selectionOverlay.querySelector(`[data-hdl="${hdlAttrFor(hit)}"]`);
      if (el) { el.classList.add("hot"); state.hoverEl = el; }
      els.workspace.style.cursor = cursorForHandle(hit);
      showDragHint(labelForHandle(hit), pt);
    } else {
      els.workspace.style.cursor = "default";
      els.dragHint.classList.add("hidden");
    }
  }

  function hitSelectionHandle(pt) {
    const layer = selectedLayer();
    if (!layer || !layer.content) return null;
    const corners = PFEngine.layerCorners(layer);
    const tol = 12 / state.zoom;
    const tolR = 13 / state.zoom;

    // Corner + edge resize handles (corners first — they win near overlaps).
    for (let i = 0; i < 4; i++) {
      if (Math.hypot(pt.x - corners[i].x, pt.y - corners[i].y) <= tol) return "scale:" + i;
    }
    const edgeMids = [
      { x: (corners[1].x + corners[2].x) / 2, y: (corners[1].y + corners[2].y) / 2 },
      { x: (corners[2].x + corners[3].x) / 2, y: (corners[2].y + corners[3].y) / 2 },
      { x: (corners[3].x + corners[0].x) / 2, y: (corners[3].y + corners[0].y) / 2 },
    ];
    for (let i = 0; i < 3; i++) {
      if (Math.hypot(pt.x - edgeMids[i].x, pt.y - edgeMids[i].y) <= tol) return "scale:" + (i + 5);
    }

    // Corner-radius handle (owns the top edge midpoint).
    const rp = radiusHandlePoint(layer);
    if (rp && Math.hypot(pt.x - rp.x, pt.y - rp.y) <= tolR) return "radius";

    // Rotate handle — offset above the top edge midpoint (mid of c0→c1).
    const topMid = { x: (corners[0].x + corners[1].x) / 2, y: (corners[0].y + corners[1].y) / 2 };
    const edge = { x: corners[1].x - corners[0].x, y: corners[1].y - corners[0].y };
    const len = Math.hypot(edge.x, edge.y) || 1;
    const rhp = { x: topMid.x + (-edge.y / len) * (26 / state.zoom), y: topMid.y + (edge.x / len) * (26 / state.zoom) };
    if (Math.hypot(pt.x - rhp.x, pt.y - rhp.y) <= tol + 5) return "rotate";

    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    if (pt.x >= Math.min(...xs) && pt.x <= Math.max(...xs) && pt.y >= Math.min(...ys) && pt.y <= Math.max(...ys)) return "move";
    return null;
  }

  // ================================================================== history
  /**
   * Undo/redo as two stacks.
   *
   * Every caller of pushHistory() snapshots the document *before* mutating it,
   * so the undo stack holds "the state to go back to" and the live document is
   * always the newest thing. Stepping back therefore has to stash the current
   * state on the redo stack first — an index into a single array can't express
   * that, which is why the old cursor model skipped a step on every undo and
   * handed back a pre-change state on redo.
   */
  const HISTORY_LIMIT = 20;
  const snapshot = () => JSON.stringify(PFProject.serializeDoc(state.doc));

  function resetHistory() {
    state.undoStack = [];
    state.redoStack = [];
    updateTopbar();
  }

  function pushHistory() {
    if (!state.doc) return;
    state.undoStack.push(snapshot());
    if (state.undoStack.length > HISTORY_LIMIT) state.undoStack.shift();
    state.redoStack.length = 0; // a fresh edit invalidates the redo branch
    updateTopbar();
  }

  async function applySnapshot(json) {
    // AI Chat history is intentionally NOT part of the image undo/redo stack
    // — it's a running conversation, not an edit. Undoing a brightness change
    // from five minutes ago shouldn't also delete the three chat messages
    // sent since. Keep whatever the live thread currently is, regardless of
    // what this (older or newer) snapshot's own aiChat says.
    const keepChat = state.doc ? state.doc.aiChat : null;
    try {
      state.doc = await PFProject.deserializeDoc(JSON.parse(json));
    } catch {
      return false;
    }
    if (keepChat) state.doc.aiChat = keepChat;
    if (!layerById(state.selectedId)) state.selectedId = null;
    applyHistoryRestore();
    return true;
  }

  async function undo() {
    if (!state.undoStack.length) return;
    const current = snapshot();
    const prev = state.undoStack.pop();
    if (await applySnapshot(prev)) state.redoStack.push(current);
    else state.undoStack.push(prev); // restore failed — leave the stack intact
    updateTopbar();
  }

  async function redo() {
    if (!state.redoStack.length) return;
    const current = snapshot();
    const next = state.redoStack.pop();
    if (await applySnapshot(next)) state.undoStack.push(current);
    else state.redoStack.push(next);
    updateTopbar();
  }

  function applyHistoryRestore() {
    setupCanvas(false);
    render();
    renderLayersPanel();
    updateContextBar();
    renderInspector();
    updateTopbar();
    markDirty();
  }

  function updateTopbar() {
    els.undoBtn.disabled = !state.undoStack.length;
    els.redoBtn.disabled = !state.redoStack.length;
  }

  // ================================================================== selection / layers
  function selectLayer(id, opts = {}) {
    // Jump to the element view when the selection actually CHANGES to a new
    // item (so its properties are immediately visible) — but re-clicking the
    // already-selected item (e.g. every pointerdown while dragging it on the
    // canvas) must not keep yanking the user back from Adjust/AI/Settings.
    const changed = !!id && id !== state.selectedId;
    state.selectedId = id;
    refreshOverlay();
    if (changed) state.rpTab = "elements";
    if (!opts.silent) {
      updateContextBar();
      // Only the highlight changes — don't rebuild the list. A full render
      // re-encodes every layer thumbnail to a dataURL, and replacing the row
      // nodes mid-click also breaks double-click (rename / edit text).
      syncLayerRowSelection();
      renderInspector();
    }
  }

  /** Move the "selected" highlight without rebuilding the layer rows. */
  function syncLayerRowSelection() {
    if (!state.layersTabActive) return;
    els.layersList.querySelectorAll(".layer-row").forEach((r) =>
      r.classList.toggle("selected", r.dataset.layerId === state.selectedId));
  }

  function addLayer(layer, opts = {}) {
    state.doc.layers.push(layer);
    if (opts.select) {
      selectLayer(layer.id, { silent: !!opts.silent });
      if (opts.silent) renderInspector();
    }
    if (!opts.silent) {
      render();
      renderLayersPanel();
      markDirty();
    }
  }

  function removeLayer(id) {
    const idx = state.doc.layers.findIndex((l) => l.id === id);
    if (idx < 0) return;
    pushHistory();
    state.doc.layers.splice(idx, 1);
    if (state.selectedId === id) {
      state.selectedId = (state.doc.layers[Math.min(idx, state.doc.layers.length - 1)] || {}).id || null;
    }
    render();
    renderLayersPanel();
    updateContextBar();
    renderInspector();
    markDirty();
  }

  function deleteSelected() {
    if (!state.selectedId) return;
    if (state.tool === "text" || state.tool === "shape") return; // don't nuke while creating
    removeLayer(state.selectedId);
  }

  /**
   * "rect" → "rect copy" → "rect copy 2" → "rect copy 3", rather than
   * piling up "rect copy copy copy".
   */
  function copyName(name) {
    const m = /^(.*?) copy(?: (\d+))?$/.exec(name || "");
    if (!m) return `${name} copy`;
    return `${m[1]} copy ${m[2] ? parseInt(m[2], 10) + 1 : 2}`;
  }

  /** Deep-copy a layer (new id, own content canvas + effects). */
  function cloneLayer(layer, rename = false) {
    return {
      ...layer,
      id: PFProject.uid("lyr"),
      name: rename ? copyName(layer.name) : layer.name,
      content: layer.content ? cloneCanvas(layer.content) : null,
      effects: layer.effects ? JSON.parse(JSON.stringify(layer.effects)) : null,
      transform: { ...layer.transform },
      shapeRect: layer.shapeRect ? { ...layer.shapeRect } : undefined,
    };
  }

  /** Insert a layer directly above `aboveId` (or on top when omitted). */
  function insertLayerAbove(layer, aboveId) {
    const idx = aboveId ? state.doc.layers.findIndex((l) => l.id === aboveId) : -1;
    if (idx < 0) state.doc.layers.push(layer);
    else state.doc.layers.splice(idx + 1, 0, layer);
  }

  function duplicateLayer() {
    const layer = selectedLayer();
    if (!layer) return toast("Select a layer first", true);
    pushHistory();
    const clone = cloneLayer(layer, true);
    // Offset slightly so the copy is visibly its own object.
    clone.transform.x += 16;
    clone.transform.y += 16;
    insertLayerAbove(clone, layer.id);
    selectLayer(clone.id, { silent: true });
    render();
    renderLayersPanel();
    renderInspector();
    markDirty();
    toast("Duplicated");
  }

  // ================================================================== clipboard
  // In-memory clipboard for same-tab copy/paste (fast, lossless), mirrored to
  // chrome.storage so a copy in one design can be pasted into another tab.
  function copySelected({ cut = false } = {}) {
    const layer = selectedLayer();
    if (!layer) { toast("Select something to copy first", true); return false; }
    state.clipboard = cloneLayer(layer);
    state.pasteCount = 0;
    // Mirror to storage for cross-tab paste (async, best-effort).
    try {
      sendMessage({ type: "clipboard:set", value: PFProject.serializeLayer(layer) });
    } catch { /* storage mirror is best-effort */ }
    if (cut) {
      removeLayer(layer.id);
      toast("Cut");
    } else {
      toast("Copied");
    }
    return true;
  }

  /** Paste the internal clipboard, or fall back to the cross-tab mirror. */
  async function pasteClipboard(at) {
    let layer = null;
    if (state.clipboard) {
      layer = cloneLayer(state.clipboard);
    } else {
      const res = await sendMessage({ type: "clipboard:get" });
      if (res && res.layer) {
        try { layer = await PFProject.deserializeLayer(res.layer); } catch { layer = null; }
      }
    }
    if (!layer) { toast("Nothing to paste", true); return false; }

    pushHistory();
    layer.name = copyName(layer.name);
    if (at) {
      layer.transform.x = at.x;
      layer.transform.y = at.y;
    } else {
      // Stagger repeat pastes so they don't stack invisibly.
      state.pasteCount = (state.pasteCount || 0) + 1;
      const off = 16 * state.pasteCount;
      layer.transform.x += off;
      layer.transform.y += off;
    }
    // A pasted full-canvas layer from a differently-sized doc would be
    // mispositioned, so treat it as a free-floating item instead.
    if (layer.fullCanvas && layer.content &&
        (layer.content.width !== state.doc.width || layer.content.height !== state.doc.height)) {
      layer.fullCanvas = false;
    }
    addLayer(layer, { select: true });
    renderInspector();
    toast("Pasted");
    return true;
  }

  /** Ctrl+A — with no real multi-select, select the topmost usable layer. */
  function selectTopLayer() {
    const layers = state.doc.layers.filter((l) => l.visible && !l.locked);
    if (!layers.length) { toast("Nothing to select", true); return; }
    selectLayer(layers[layers.length - 1].id);
  }

  function toggleLockSelected() {
    const layer = selectedLayer();
    if (!layer) { toast("Select a layer first", true); return; }
    pushHistory();
    layer.locked = !layer.locked;
    if (layer.locked && state.selectedId === layer.id) refreshOverlay();
    renderLayersPanel();
    renderInspector();
    markDirty();
    toast(layer.locked ? "Layer locked" : "Layer unlocked");
  }

  function toggleGrid() {
    state.showGrid = !state.showGrid;
    els.stageWrap.classList.toggle("show-grid", state.showGrid);
    toast(state.showGrid ? "Grid on" : "Grid off");
  }

  function toggleSnap() {
    state.snapEnabled = !state.snapEnabled;
    if (!state.snapEnabled) drawSnapGuides([]);
    toast(state.snapEnabled ? "Smart guides on" : "Smart guides off");
  }

  /** Zoom so the selected layer fills most of the viewport. */
  function zoomToSelection() {
    const l = selectedLayer();
    if (!l || !l.content) { zoomFit(); return; }
    const b = PFEngine.layerBounds(l);
    if (!b || b.w < 1 || b.h < 1) { zoomFit(); return; }
    const pad = 80;
    const z = clamp(Math.min(
      (els.workspace.clientWidth - pad) / b.w,
      (els.workspace.clientHeight - pad) / b.h,
    ), 0.02, 16);
    state.zoom = z;
    applyZoom();
    // Centre the viewport on the layer.
    const sw = els.stageWrap;
    els.workspace.scrollLeft = (b.cx * z) + (sw.offsetLeft || 0) - els.workspace.clientWidth / 2;
    els.workspace.scrollTop = (b.cy * z) + (sw.offsetTop || 0) - els.workspace.clientHeight / 2;
  }

  /** Merge every visible layer into one raster layer. */
  function flattenAll() {
    if (!state.doc.layers.length) { toast("Nothing to flatten", true); return; }
    confirmDialog("Flatten every visible layer into a single image? Hidden layers are discarded.", () => {
      pushHistory();
      const flat = PFEngine.flattenDoc(state.doc);
      const layer = PFEngine.makeFullCanvasLayer(flat, { name: "Flattened" });
      state.doc.layers = [layer];
      selectLayer(layer.id, { silent: true });
      render();
      renderLayersPanel();
      renderInspector();
      markDirty();
      toast("Flattened");
    }, "Flatten design");
  }

  /** Copy the flattened selection (or whole design) to the OS clipboard as PNG. */
  async function copyImageToSystem() {
    const layer = selectedLayer();
    let canvas;
    if (layer) {
      canvas = document.createElement("canvas");
      canvas.width = state.doc.width;
      canvas.height = state.doc.height;
      PFEngine.drawLayer(canvas.getContext("2d"), layer, true);
    } else {
      canvas = PFEngine.flattenDoc(state.doc);
    }
    try {
      const blob = await new Promise((res, rej) =>
        canvas.toBlob((b) => (b ? res(b) : rej(new Error("encode failed"))), "image/png"));
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      toast(layer ? "Layer copied as image" : "Design copied as image");
    } catch {
      toast("Your browser blocked the image copy", true);
    }
  }

  function moveLayer(dir) {
    const idx = state.doc.layers.findIndex((l) => l.id === state.selectedId);
    const to = idx + dir;
    if (idx < 0 || to < 0 || to >= state.doc.layers.length) return;
    pushHistory();
    const [l] = state.doc.layers.splice(idx, 1);
    state.doc.layers.splice(to, 0, l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function layerThumb(layer) {
    if (!layer.content) return "";
    const scale = Math.min(1, 34 / Math.max(layer.content.width, layer.content.height));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(layer.content.width * scale));
    c.height = Math.max(1, Math.round(layer.content.height * scale));
    c.getContext("2d").drawImage(layer.content, 0, 0, c.width, c.height);
    return c.toDataURL("image/png");
  }

  let dragLayerId = null;

  function reorderLayer(fromId, toId) {
    const layers = state.doc.layers;
    const fromIdx = layers.findIndex((l) => l.id === fromId);
    const toIdx = layers.findIndex((l) => l.id === toId);
    if (fromIdx < 0 || toIdx < 0 || fromIdx === toIdx) return;
    pushHistory();
    const [moved] = layers.splice(fromIdx, 1);
    layers.splice(layers.findIndex((l) => l.id === toId), 0, moved);
    render();
    renderLayersPanel();
    markDirty();
  }

  /**
   * Rename happens on the inspector's title, not in the layers list: clicking
   * a layer row selects the layer, which swaps the dock from the list over to
   * the inspector — so the second click of a double-click would land on an
   * inspector field, and a row-level dblclick can never fire.
   */
  function bindRenameUI() {
    els.inspName.addEventListener("dblclick", () => startRename());
  }

  /** Turn the inspector's title into an inline text input. */
  function startRename() {
    const layer = selectedLayer();
    if (!layer || els.inspName.querySelector("input")) return;
    const input = document.createElement("input");
    input.className = "layer-rename";
    input.value = layer.name;
    els.inspName.textContent = "";
    els.inspName.appendChild(input);
    input.focus();
    input.select();

    let done = false;
    const finish = (commit) => {
      if (done) return;
      done = true;
      const next = input.value.trim();
      if (commit && next && next !== layer.name) {
        pushHistory();
        layer.name = next;
        markDirty();
        renderLayersPanel();
      }
      els.inspName.textContent = layer.name;
    };
    input.addEventListener("blur", () => finish(true));
    input.addEventListener("keydown", (e) => {
      e.stopPropagation(); // don't let editor shortcuts fire while typing
      if (e.key === "Enter") { e.preventDefault(); finish(true); }
      if (e.key === "Escape") { e.preventDefault(); finish(false); }
    });
  }

  function renderLayersPanel() {
    if (!state.layersTabActive) return;
    const list = els.layersList;
    list.innerHTML = "";
    if (!state.doc.layers.length) {
      list.innerHTML = '<div class="hint">No layers yet — add an image, text or shape to get started.</div>';
    }
    for (let i = state.doc.layers.length - 1; i >= 0; i--) {
      const layer = state.doc.layers[i];
      const row = document.createElement("div");
      row.className = "layer-row" + (layer.id === state.selectedId ? " selected" : "");
      // Only the grip is draggable — a draggable *row* makes Chromium swallow
      // the second click of a double-click, which killed rename / edit-text.
      row.draggable = false;
      row.classList.toggle("locked", !!layer.locked);
      row.innerHTML = `
        <span class="layer-drag" draggable="true" data-tip="Reorder|Drag to move this layer up or down the stack">${PFIcons.svg("grip")}</span>
        <button class="layer-eye" data-tip="Show / hide|Toggle this layer's visibility">${PFIcons.svg(layer.visible ? "eye" : "eye-off")}</button>
        <div class="layer-thumb"><img src="${layerThumb(layer)}" alt="" draggable="false"></div>
        <div class="layer-meta">
          <div class="layer-name"></div>
          <div class="layer-type">${layer.type}${layer.blend && layer.blend !== "normal" ? ` · ${escapeHtml(layer.blend)}` : ""}</div>
        </div>
        <button class="layer-lock${layer.locked ? " on" : ""}" data-tip="Lock / unlock|A locked layer can't be selected or moved on the canvas|Ctrl+L">${PFIcons.svg(layer.locked ? "lock" : "unlock")}</button>`;
      row.querySelector(".layer-name").textContent = layer.name;
      row.querySelector(".layer-eye").addEventListener("click", (ev) => {
        ev.stopPropagation();
        layer.visible = !layer.visible;
        render();
        renderLayersPanel();
        markDirty();
      });
      row.querySelector(".layer-lock").addEventListener("click", (ev) => {
        ev.stopPropagation();
        pushHistory();
        layer.locked = !layer.locked;
        if (layer.locked && state.selectedId === layer.id) selectLayer(null);
        else renderLayersPanel();
        render();
        markDirty();
      });
      row.dataset.layerId = layer.id;
      row.addEventListener("click", () => selectLayer(layer.id));
      // NOTE: no per-row dblclick listener. The first click re-renders the
      // list, so the row node is replaced between the two clicks and the
      // dblclick lands on the list instead — see bindLayersListEvents().
      row.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        selectLayer(layer.id);
        openLayerContextMenu(ev.clientX, ev.clientY, layer);
      });
      row.querySelector(".layer-drag").addEventListener("dragstart", (ev) => {
        dragLayerId = layer.id;
        ev.dataTransfer.effectAllowed = "move";
        ev.dataTransfer.setData("text/plain", layer.id);
        // Drag the whole row as the ghost, not just the little grip icon.
        if (ev.dataTransfer.setDragImage) ev.dataTransfer.setDragImage(row, 20, 20);
      });
      row.addEventListener("dragover", (ev) => {
        if (!dragLayerId || dragLayerId === layer.id) return;
        ev.preventDefault();
        row.classList.add("drag-over");
      });
      row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
      row.addEventListener("drop", (ev) => {
        ev.preventDefault();
        row.classList.remove("drag-over");
        if (!dragLayerId || dragLayerId === layer.id) return;
        reorderLayer(dragLayerId, layer.id);
        dragLayerId = null;
      });
      row.addEventListener("dragend", () => {
        dragLayerId = null;
        list.querySelectorAll(".layer-row.drag-over").forEach((r) => r.classList.remove("drag-over"));
      });
      list.appendChild(row);
    }
    const sel = selectedLayer();
    els.layerOpacity.value = sel ? Math.round(sel.opacity * 100) : 100;
    els.layerOpacityVal.textContent = sel ? Math.round(sel.opacity * 100) : 100;
  }

  // ================================================================== zoom / pan
  function applyZoom() {
    const z = state.zoom;
    els.stage.style.transform = `scale(${z})`;
    const pad = 60;
    els.stageWrap.style.width = `${state.doc.width * z + pad * 2}px`;
    els.stageWrap.style.height = `${state.doc.height * z + pad * 2}px`;
    els.stage.style.left = `${pad}px`;
    els.stage.style.top = `${pad}px`;
    els.zoomLabel.textContent = `${Math.round(z * 100)}%`;
    els.hudZoom.textContent = `${Math.round(z * 100)}%`;
    updateBrushCursor();
  }

  function zoomFit() {
    const w = els.workspace.clientWidth - 80;
    const h = els.workspace.clientHeight - 80;
    state.zoom = clamp(Math.min(w / state.doc.width, h / state.doc.height), 0.02, 2);
    applyZoom();
    els.workspace.scrollLeft = Math.max(0, (els.stageWrap.clientWidth - els.workspace.clientWidth) / 2);
    els.workspace.scrollTop = Math.max(0, (els.stageWrap.clientHeight - els.workspace.clientHeight) / 2);
  }

  function zoomAt(clientX, clientY, factor) {
    const z0 = state.zoom;
    const z1 = clamp(z0 * factor, 0.05, 8);
    if (z1 === z0) return;
    const r0 = els.stage.getBoundingClientRect();
    const dx = (clientX - r0.left) / z0;
    const dy = (clientY - r0.top) / z0;
    state.zoom = z1;
    applyZoom();
    const r1 = els.stage.getBoundingClientRect();
    els.workspace.scrollLeft += clientX - r1.left - dx * z1;
    els.workspace.scrollTop += clientY - r1.top - dy * z1;
    updateHud();
  }

  /** Zoom centered on a document point (used by the zoom tool). */
  function zoomTo(pt, factor) {
    const r = els.stage.getBoundingClientRect();
    zoomAt(r.left + pt.x * state.zoom, r.top + pt.y * state.zoom, factor);
  }

  function panBy(dx, dy) {
    els.workspace.scrollLeft += dx;
    els.workspace.scrollTop += dy;
  }

  function docPoint(e) {
    const r = els.stage.getBoundingClientRect();
    return { x: (e.clientX - r.left) / state.zoom, y: (e.clientY - r.top) / state.zoom };
  }

  // Each pixel-brush gets its own cursor tint so the active tool is obvious.
  const BRUSH_CURSOR_COLORS = {
    blur: "#d29d3f",
    stamp: "#3fb37f",
    sharpen: "#b06fd6",
    dodge: "#e4d06a",
    burn: "#d97a4a",
  };

  function updateBrushCursor() {
    const show = Object.prototype.hasOwnProperty.call(BRUSH_CURSOR_COLORS, state.tool)
      || state.tool === "brush" || state.tool === "eraser";
    els.brushCursor.style.display = show ? "block" : "none";
    if (show) {
      const d = Math.max(6, state.toolOptions.size * 2 * state.zoom);
      els.brushCursor.style.width = d + "px";
      els.brushCursor.style.height = d + "px";
      els.brushCursor.style.borderColor = BRUSH_CURSOR_COLORS[state.tool] || "#3b82f6";
      els.brushCursor.style.boxShadow = "0 0 0 1px rgba(0,0,0,0.5)";
    }
  }

  // ================================================================== tools
  const editorApi = {
    get doc() { return state.doc; },
    get canvas() { return els.docCanvas; },
    get previewCanvas() { return els.previewCanvas; },
    get zoom() { return state.zoom; },
    get toolOptions() { return state.toolOptions; },
    getSelected: () => selectedLayer(),
    getLayer: (id) => layerById(id),
    selectLayer: (id, o) => selectLayer(id, o),
    addLayer: (l, o) => addLayer(l, o),
    removeLayer: (id) => removeLayer(id),
    pushHistory: () => pushHistory(),
    markDirty: () => markDirty(),
    render: () => render(),
    refreshOverlay: () => refreshOverlay(),
    hitSelectionHandle: (pt) => hitSelectionHandle(pt),
    setColor: (hex) => setColor(hex),
    get previousPaintTool() { return state.previousPaintTool; },
    setTool: (id) => setTool(id),
    openTextEditor: (layer) => openTextEditor(layer),
    updateCropOverlay: (r) => updateCropOverlay(r),
    showCropBar: () => updateContextBar(),
    clearCrop: () => clearCrop(),
    applyCrop: (r) => applyCrop(r),
    panBy: (dx, dy) => panBy(dx, dy),
    zoomTo: (pt, factor) => zoomTo(pt, factor),
    toast: (m, e) => toast(m, e),
    applySnap: (layer, x, y, e) => applySnap(layer, x, y, e),
    clearSnap: () => drawSnapGuides([]),
    duplicateForDrag: (id) => duplicateForDrag(id),
  };

  // ================================================================== smart guides
  const SNAP_PX = 6; // snap radius, in screen pixels (so it feels the same at any zoom)

  /**
   * Nudge a dragged layer onto meaningful alignments — canvas edges/centre and
   * the edges/centres of other layers — and record the guide lines to draw.
   * Holding Ctrl (or disabling smart guides) turns this off.
   */
  function applySnap(layer, x, y, e) {
    if (!state.snapEnabled || (e && (e.ctrlKey || e.metaKey))) {
      drawSnapGuides([]);
      return { x, y };
    }
    const b = PFEngine.layerBounds(layer);
    if (!b) return { x, y };
    // Bounds are computed from the layer's *current* transform; work out where
    // they'd land at the proposed position.
    const dx = x - layer.transform.x, dy = y - layer.transform.y;
    const left = b.left + dx, right = b.right + dx, cx = b.cx + dx;
    const top = b.top + dy, bottom = b.bottom + dy, cy = b.cy + dy;

    const tol = SNAP_PX / Math.max(0.01, state.zoom);
    const doc = state.doc;

    // Candidate lines: [position, kind] for each axis.
    const xTargets = [[0, "edge"], [doc.width / 2, "centre"], [doc.width, "edge"]];
    const yTargets = [[0, "edge"], [doc.height / 2, "centre"], [doc.height, "edge"]];
    for (const other of doc.layers) {
      if (other.id === layer.id || !other.visible || !other.content) continue;
      const ob = PFEngine.layerBounds(other);
      if (!ob) continue;
      xTargets.push([ob.left, "layer"], [ob.cx, "layer"], [ob.right, "layer"]);
      yTargets.push([ob.top, "layer"], [ob.cy, "layer"], [ob.bottom, "layer"]);
    }

    const guides = [];
    let bestX = null, bestY = null;

    // Our three anchors per axis (near edge, centre, far edge) each look for
    // the closest target line; the overall closest match wins.
    for (const value of [left, cx, right]) {
      for (const [target] of xTargets) {
        const d = Math.abs(value - target);
        if (d <= tol && (!bestX || d < bestX.d)) bestX = { d, delta: target - value, at: target };
      }
    }
    for (const value of [top, cy, bottom]) {
      for (const [target] of yTargets) {
        const d = Math.abs(value - target);
        if (d <= tol && (!bestY || d < bestY.d)) bestY = { d, delta: target - value, at: target };
      }
    }

    let outX = x, outY = y;
    if (bestX) { outX = x + bestX.delta; guides.push({ axis: "v", at: bestX.at }); }
    if (bestY) { outY = y + bestY.delta; guides.push({ axis: "h", at: bestY.at }); }
    drawSnapGuides(guides);
    return { x: outX, y: outY };
  }

  /**
   * Paint the alignment guides. #stage is CSS-scaled, so these use raw document
   * coordinates — and the line thickness is divided by the zoom so it stays
   * hairline-thin on screen at any magnification.
   */
  function drawSnapGuides(guides) {
    state.snapLines = guides;
    const host = els.snapLayer;
    if (!host) return;
    if (!guides.length) { host.innerHTML = ""; return; }
    const t = 1 / Math.max(0.01, state.zoom); // ~1 screen px
    const over = 24 * t; // let guides run slightly past the canvas edge
    host.innerHTML = guides.map((g) => g.axis === "v"
      ? `<i class="snap-line" style="left:${g.at}px;top:${-over}px;width:${t}px;height:${state.doc.height + over * 2}px"></i>`
      : `<i class="snap-line" style="top:${g.at}px;left:${-over}px;height:${t}px;width:${state.doc.width + over * 2}px"></i>`
    ).join("");
  }

  /** Alt-drag: leave the original in place and drag a fresh copy. */
  function duplicateForDrag(id) {
    const layer = layerById(id);
    if (!layer) return null;
    const clone = cloneLayer(layer, true);
    insertLayerAbove(clone, layer.id);
    selectLayer(clone.id, { silent: true });
    renderLayersPanel();
    renderInspector();
    return clone;
  }

  function setTool(id) {
    clearHover();
    els.workspace.style.cursor = "default";
    if (state.tool === "crop" && id !== "crop") clearCrop();
    if (state.toolInstance && state.toolInstance.deactivate) {
      try { state.toolInstance.deactivate(); } catch { /* noop */ }
    }
    state.tool = id;
    if (id === "brush" || id === "eraser") state.previousPaintTool = id;
    state.toolInstance = PFTools.createTool(id, editorApi);
    document.querySelectorAll("#leftBar .tool-btn").forEach((b) => b.classList.toggle("active", b.dataset.tool === id));
    updateContextBar();
    updateBrushCursor();
    updateHudTool();
  }

  function updateHudTool() {
    const t = PFTools.TOOLS.find((x) => x.id === state.tool);
    if (!t) return;
    els.hudTool.textContent = t.name;
    els.hudHint.textContent = t.desc || "";
  }

  function renderToolRail() {
    els.leftBar.innerHTML = "";
    PFTools.TOOLS.forEach((t) => {
      const btn = document.createElement("button");
      btn.className = "tool-btn";
      btn.dataset.tool = t.id;
      btn.dataset.tip = `${t.name}|${t.desc || ""}|${t.kbd}`;
      btn.innerHTML = `${t.icon}<span class="kbd">${t.kbd}</span>`;
      btn.addEventListener("click", () => setTool(t.id));
      els.leftBar.appendChild(btn);
    });
  }

  // ---------------------------------------------------------------- context bar
  function updateContextBar() {
    const bar = els.contextBar;
    bar.innerHTML = "";
    bar.classList.remove("hidden");
    const t = state.tool;
    if (t === "brush" || t === "eraser") buildBrushContext(bar);
    else if (t === "shape") buildShapeContext(bar);
    else if (t === "move") buildMoveContext(bar);
    else if (t === "text") buildTextContext(bar);
    else if (t === "crop") buildCropContext(bar);
    else if (t === "fill") buildFillContext(bar);
    else if (t === "gradient") buildGradientContext(bar);
    else if (t === "blur") buildSizeContext(bar, "Blur brush", "radius");
    else if (t === "sharpen") buildStrengthContext(bar, "Sharpen brush");
    else if (t === "dodge") buildStrengthContext(bar, "Dodge — lighten");
    else if (t === "burn") buildStrengthContext(bar, "Burn — darken");
    else if (t === "stamp") buildStampContext(bar);
    else if (t === "zoom") {
      bar.innerHTML = '<span class="cb-hint">Click to zoom in · Alt-click (or right-click) to zoom out · scroll anywhere to zoom</span>';
    } else {
      bar.innerHTML = '<span class="cb-hint">Drag to pan · scroll to zoom</span>';
    }
  }

  function sliderFill(input) {
    const min = parseFloat(input.min) || 0;
    const max = parseFloat(input.max) || 100;
    const pct = ((parseFloat(input.value) - min) / (max - min)) * 100;
    input.style.setProperty("--fill", `${pct}%`);
  }

  // ---------------------------------------------------------------- swatches
  // A fixed starter palette, then whatever colours the user has actually used
  // (most recent first) so building a consistent palette is one click.
  const BASE_SWATCHES = [
    "#111827", "#6b7280", "#ffffff", "#ef4444", "#f97316", "#eab308",
    "#22c55e", "#14b8a6", "#3b82f6", "#6366f1", "#a855f7", "#ec4899",
  ];

  function rememberSwatch(hex) {
    const h = String(hex || "").toLowerCase();
    if (!/^#[0-9a-f]{6}$/.test(h)) return;
    state.swatches = [h, ...state.swatches.filter((s) => s !== h)].slice(0, 8);
    sendMessage({ type: "settings:set", key: "swatches", value: state.swatches });
  }

  function swatchStripHTML() {
    const recent = state.swatches.length
      ? `<span class="sw-div"></span>` + state.swatches
        .map((c) => `<button class="sw-dot recent" data-sw="${escapeHtml(c)}" title="${escapeHtml(c)}" style="background:${escapeHtml(c)}"></button>`).join("")
      : "";
    return `<div class="cb-item cb-swatches">${
      BASE_SWATCHES.map((c) => `<button class="sw-dot" data-sw="${c}" title="${c}" style="background:${c}"></button>`).join("")
    }${recent}</div>`;
  }

  function bindSwatchStrip(bar, apply) {
    bar.querySelectorAll("[data-sw]").forEach((b) =>
      b.addEventListener("click", () => {
        apply(b.dataset.sw);
        updateContextBar(); // reflect the new colour in the picker + recents
      }));
  }

  function buildBrushContext(bar) {
    const erasing = state.tool === "eraser";
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${erasing ? "Eraser" : "Brush"}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Colour</label><input type="color" id="ctxColor" value="${o.color}"></div>
      ${erasing ? "" : swatchStripHTML()}
      <div class="cb-item"><label>Size</label><input type="range" id="ctxSize" min="2" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
      <div class="cb-item"><label>Softness</label><input type="range" id="ctxHard" min="0" max="100" value="${Math.round(o.hardness * 100)}"><span class="cb-val">${Math.round(o.hardness * 100)}</span></div>
      ${erasing ? "" : `<div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="10" max="100" value="${Math.round(o.opacity * 100)}"><span class="cb-val">${Math.round(o.opacity * 100)}</span></div>`}
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bindSwatchStrip(bar, (hex) => setColor(hex));
    bar.querySelector("#ctxColor").addEventListener("input", (e) => setColor(e.target.value));
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
    bar.querySelector("#ctxHard").addEventListener("input", (e) => {
      o.hardness = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
    const op = bar.querySelector("#ctxOp");
    if (op) op.addEventListener("input", (e) => {
      o.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
  }

  function buildShapeContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Shape</span></div>
      <div class="cb-item">
        <select id="ctxKind">
          ${/* names only — an <option> can't render the SVG chip icons */ ""}
          ${PFTools.SHAPE_KINDS.map(([k, , name]) => `<option value="${k}" ${o.shapeKind === k ? "selected" : ""}>${escapeHtml(name)}</option>`).join("")}
        </select>
      </div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Fill</label><input type="color" id="ctxFill" value="${o.fill}"></div>
      ${swatchStripHTML()}
      <div class="cb-item"><label>Outline</label><input type="color" id="ctxStroke" value="${o.stroke}"></div>
      <div class="cb-item"><label>Weight</label><input type="range" id="ctxSw" min="0" max="40" value="${o.strokeWidth}"><span class="cb-val">${o.strokeWidth}</span></div>
      <div class="cb-item" id="ctxPointsWrap"><label>Points</label><input type="range" id="ctxPoints" min="3" max="12" value="${o.points}"><span class="cb-val">${o.points}</span></div>
      <div class="cb-item" id="ctxRadiusWrap"><label>Radius</label><input type="range" id="ctxRadius" min="0" max="200" value="${o.radius}"><span class="cb-val">${o.radius}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    const syncExtras = () => {
      const star = o.shapeKind === "star";
      bar.querySelector("#ctxPointsWrap").style.display = star ? "flex" : "none";
      const rect = o.shapeKind === "rect";
      bar.querySelector("#ctxRadiusWrap").style.display = rect ? "flex" : "none";
    };
    bar.querySelector("#ctxKind").addEventListener("change", (e) => {
      o.shapeKind = e.target.value;
      syncExtras();
    });
    bindSwatchStrip(bar, (hex) => { o.fill = hex; rememberSwatch(hex); });
    bar.querySelector("#ctxFill").addEventListener("input", (e) => { o.fill = e.target.value; });
    bar.querySelector("#ctxFill").addEventListener("change", (e) => rememberSwatch(e.target.value));
    bar.querySelector("#ctxStroke").addEventListener("input", (e) => { o.stroke = e.target.value; });
    bar.querySelector("#ctxStroke").addEventListener("change", (e) => rememberSwatch(e.target.value));
    bar.querySelector("#ctxSw").addEventListener("input", (e) => {
      o.strokeWidth = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.strokeWidth;
    });
    bar.querySelector("#ctxPoints").addEventListener("input", (e) => {
      o.points = parseInt(e.target.value, 10);
      e.target.nextElementSibling.textContent = o.points;
    });
    bar.querySelector("#ctxRadius").addEventListener("input", (e) => {
      o.radius = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.radius;
    });
    syncExtras();
  }

  function buildFillContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Fill bucket</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Colour</label><input type="color" id="ctxColor" value="${o.color}"></div>
      <div class="cb-item"><label>Tolerance</label><input type="range" id="ctxTol" min="0" max="100" value="${o.tolerance}"><span class="cb-val">${o.tolerance}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxColor").addEventListener("input", (e) => setColor(e.target.value));
    bar.querySelector("#ctxTol").addEventListener("input", (e) => {
      o.tolerance = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.tolerance;
    });
  }

  function buildGradientContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Gradient</span></div>
      <div class="cb-item"><div class="seg" id="ctxGrad">
        <button class="seg-btn ${o.gradType === "linear" ? "active" : ""}" data-grad="linear">Linear</button>
        <button class="seg-btn ${o.gradType === "radial" ? "active" : ""}" data-grad="radial">Radial</button>
      </div></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>From</label><input type="color" id="ctxG1" value="${o.color}"></div>
      <div class="cb-item"><label>To</label><input type="color" id="ctxG2" value="${o.color2}"></div>
    `;
    bar.querySelectorAll("#ctxGrad .seg-btn").forEach((b) => b.addEventListener("click", () => {
      o.gradType = b.dataset.grad;
      bar.querySelectorAll("#ctxGrad .seg-btn").forEach((x) => x.classList.toggle("active", x === b));
    }));
    bar.querySelector("#ctxG1").addEventListener("input", (e) => { o.color = e.target.value; });
    bar.querySelector("#ctxG2").addEventListener("input", (e) => { o.color2 = e.target.value; });
  }

  function buildSizeContext(bar, label, unit = "size") {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${label}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>${unit[0].toUpperCase() + unit.slice(1)}</label><input type="range" id="ctxSize" min="4" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
  }

  /** Size + strength options, shared by the sharpen / dodge / burn brushes. */
  function buildStrengthContext(bar, label) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${escapeHtml(label)}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Size</label><input type="range" id="ctxSize" min="4" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
      <div class="cb-item"><label>Strength</label><input type="range" id="ctxStrength" min="5" max="100" value="${o.strength}"><span class="cb-val">${o.strength}</span></div>
      <div class="cb-sep"></div>
      <span class="cb-hint">Brush over the selected image layer</span>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
      sliderFill(e.target);
    });
    bar.querySelector("#ctxStrength").addEventListener("input", (e) => {
      o.strength = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.strength;
      sliderFill(e.target);
    });
  }

  function buildStampContext(bar) {
    const o = state.toolOptions;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Clone stamp</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Size</label><input type="range" id="ctxSize" min="4" max="120" value="${o.size}"><span class="cb-val">${o.size}</span></div>
      <div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="10" max="100" value="${Math.round(o.opacity * 100)}"><span class="cb-val">${Math.round(o.opacity * 100)}</span></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxSize").addEventListener("input", (e) => {
      o.size = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = o.size;
      updateBrushCursor();
    });
    bar.querySelector("#ctxOp").addEventListener("input", (e) => {
      o.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
    });
  }

  function applyTextControl(kind, value) {
    const layer = selectedLayer();
    const defs = state.toolOptions.textDefaults;
    if (layer && layer.type === "text") {
      pushHistory();
      layer[kind] = value;
      PFEngine.renderContent(layer);
      render();
      renderLayersPanel();
      markDirty();
    } else {
      defs[kind] = value;
    }
  }

  function buildTextContext(bar) {
    const layer = selectedLayer();
    const src = layer && layer.type === "text" ? layer : state.toolOptions.textDefaults;
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">Text</span></div>
      <div class="cb-item">
        <select id="ctxFont">
          ${FONTS.map((f) => `<option value="${f}" ${src.fontFamily === f ? "selected" : ""}>${f}</option>`).join("")}
        </select>
      </div>
      <div class="cb-item"><label>Size</label><input type="number" id="ctxFontSize" min="8" max="400" value="${src.fontSize}" style="width:64px;background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:5px 8px;color:var(--text)"></div>
      <div class="cb-item"><input type="color" id="ctxTextColor" value="${src.color}"></div>
      <div class="cb-item"><div class="seg" id="ctxStyle">
        <button class="seg-btn ${src.fontWeight >= 700 ? "active" : ""}" data-sty="bold" title="Bold"><b>B</b></button>
        <button class="seg-btn ${src.fontStyle === "italic" ? "active" : ""}" data-sty="italic" title="Italic"><i>I</i></button>
      </div></div>
      <div class="cb-item"><button class="btn ghost" id="ctxEditText">${PFIcons.svg("edit")} Edit text</button></div>
    `;
    bar.querySelector("#ctxFont").addEventListener("change", (e) => applyTextControl("fontFamily", e.target.value));
    bar.querySelector("#ctxFontSize").addEventListener("change", (e) => applyTextControl("fontSize", clamp(parseInt(e.target.value, 10) || 24, 8, 400)));
    bar.querySelector("#ctxTextColor").addEventListener("change", (e) => applyTextControl("color", e.target.value));
    bar.querySelectorAll("#ctxStyle .seg-btn").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.sty === "bold") applyTextControl("fontWeight", src.fontWeight >= 700 ? 400 : 700);
      else applyTextControl("fontStyle", src.fontStyle === "italic" ? "normal" : "italic");
      updateContextBar();
    }));
    bar.querySelector("#ctxEditText").addEventListener("click", () => {
      if (layer && layer.type === "text") openTextEditor(layer);
      else toast("Add a text layer first", true);
    });
  }

  function buildMoveContext(bar) {
    const layer = selectedLayer();
    if (!layer) {
      bar.innerHTML = '<span class="cb-hint">Select a layer to edit it · drag empty space to pan · double-click text to edit</span>';
      return;
    }
    bar.innerHTML = `
      <div class="cb-item"><span class="cb-label">${layer.name}</span></div>
      <div class="cb-sep"></div>
      <div class="cb-item"><label>Opacity</label><input type="range" id="ctxOp" min="5" max="100" value="${Math.round(layer.opacity * 100)}"><span class="cb-val">${Math.round(layer.opacity * 100)}</span></div>
      <div class="cb-item"><button class="btn ghost" id="ctxDup">${PFIcons.svg("duplicate")} Duplicate</button></div>
      <div class="cb-item"><button class="btn danger" id="ctxDel">${PFIcons.svg("trash")} Delete</button></div>
    `;
    bar.querySelectorAll("input[type=range]").forEach(sliderFill);
    bar.querySelector("#ctxOp").addEventListener("input", (e) => {
      layer.opacity = parseFloat(e.target.value) / 100;
      e.target.nextElementSibling.textContent = e.target.value;
      render();
    });
    bar.querySelector("#ctxOp").addEventListener("change", () => { pushHistory(); markDirty(); });
    bar.querySelector("#ctxDup").addEventListener("click", duplicateLayer);
    bar.querySelector("#ctxDel").addEventListener("click", () => removeLayer(layer.id));
  }

  function buildCropContext(bar) {
    if (state.cropRect) {
      bar.innerHTML = `
        <div class="cb-item"><span class="cb-label">Crop</span></div>
        <div class="cb-item"><span class="cb-hint">${Math.round(state.cropRect.w)} × ${Math.round(state.cropRect.h)}px</span></div>
        <div class="cb-sep"></div>
        <div class="cb-item"><button class="btn primary" id="ctxApply">Apply crop</button></div>
        <div class="cb-item"><button class="btn ghost" id="ctxCancel">Cancel</button></div>
      `;
      bar.querySelector("#ctxApply").addEventListener("click", () => state.toolInstance.apply());
      bar.querySelector("#ctxCancel").addEventListener("click", () => { state.toolInstance.cancel(); });
    } else {
      bar.innerHTML = '<span class="cb-hint">Drag to select a crop area · drag corners to resize · drag inside to move · Enter to apply</span>';
    }
  }

  function setColor(hex) {
    state.toolOptions.color = hex;
    const c = els.contextBar.querySelector("#ctxColor");
    if (c) c.value = hex;
    rememberSwatch(hex);
  }

  // ================================================================== crop
  function updateCropOverlay(rect) {
    state.cropRect = rect;
    els.cropOverlay.style.display = "block";
    const mask = els.cropOverlay.querySelector(".crop-mask");
    mask.style.cssText = `left:${rect.x}px;top:${rect.y}px;width:${rect.w}px;height:${rect.h}px;`;
    const hs = els.cropOverlay.querySelectorAll(".crop-handle");
    hs[0].style.cssText = `left:${rect.x}px;top:${rect.y}px;`;
    hs[1].style.cssText = `left:${rect.x + rect.w}px;top:${rect.y}px;`;
    hs[2].style.cssText = `left:${rect.x}px;top:${rect.y + rect.h}px;`;
    hs[3].style.cssText = `left:${rect.x + rect.w}px;top:${rect.y + rect.h}px;`;
  }

  function clearCrop() {
    state.cropRect = null;
    els.cropOverlay.style.display = "none";
    updateContextBar();
  }

  function applyCrop(rect) {
    const doc = state.doc;
    const r = {
      x: clamp(Math.round(rect.x), 0, doc.width - 1),
      y: clamp(Math.round(rect.y), 0, doc.height - 1),
      w: Math.max(1, Math.min(doc.width, Math.round(rect.w))),
      h: Math.max(1, Math.min(doc.height, Math.round(rect.h))),
    };
    if (r.w < 2 || r.h < 2) return;
    pushHistory();
    for (const layer of doc.layers) {
      if (layer.fullCanvas && layer.content) {
        const c = document.createElement("canvas");
        c.width = r.w;
        c.height = r.h;
        c.getContext("2d").drawImage(layer.content, -r.x, -r.y);
        layer.content = c;
        layer.transform = { x: r.w / 2, y: r.h / 2, rotation: 0, scaleX: 1, scaleY: 1 };
      } else {
        layer.transform.x -= r.x;
        layer.transform.y -= r.y;
      }
    }
    doc.width = r.w;
    doc.height = r.h;
    setupCanvas(false);
    render();
    renderLayersPanel();
    markDirty();
    toast(`Cropped to ${r.w} × ${r.h}`);
  }

  // ================================================================== text popover
  function openTextEditor(layer, opts = {}) {
    if (!layer || layer.type !== "text") return;
    if (state.textPopOpen) closeTextEditor();
    if (opts.push !== false) pushHistory();
    state.textPopOpen = true;
    state.textPopOrig = layer.text;
    els.textPopInput.value = layer.text;
    els.textPop.classList.remove("hidden");

    const wrapR = els.workspaceWrap.getBoundingClientRect();
    const stageR = els.stage.getBoundingClientRect();
    let left = stageR.left - wrapR.left + layer.transform.x * state.zoom - 150;
    let top = stageR.top - wrapR.top + layer.transform.y * state.zoom + 24;
    left = clamp(left, 8, Math.max(8, wrapR.width - 320));
    top = clamp(top, 8, Math.max(8, wrapR.height - 140));
    els.textPop.style.left = left + "px";
    els.textPop.style.top = top + "px";

    els.textPopInput.oninput = () => {
      layer.text = els.textPopInput.value;
      PFEngine.renderContent(layer);
      render();
    };
    els.textPopInput.onkeydown = (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); closeTextEditor(); }
      if (e.key === "Escape") { e.stopPropagation(); layer.text = state.textPopOrig; PFEngine.renderContent(layer); render(); closeTextEditor(); }
    };
    els.textPopInput.onblur = () => {
      // Don't close when focus just moved to the context bar (font controls etc).
      setTimeout(() => {
        const t = document.activeElement;
        if (t && (els.textPop.contains(t) || els.contextBar.contains(t))) return;
        closeTextEditor();
      }, 120);
    };
    els.textPopInput.focus();
    els.textPopInput.select();
  }

  function closeTextEditor() {
    if (!state.textPopOpen) return;
    state.textPopOpen = false;
    els.textPop.classList.add("hidden");
    renderLayersPanel();
    markDirty();
  }

  // ================================================================== filters / adjustments
  function renderPresets() {
    els.presetGrid.innerHTML = "";
    PFFilters.PRESETS.forEach((p) => {
      const chip = document.createElement("button");
      chip.className = "preset-chip";
      chip.innerHTML = `<span class="p-icon">${p.name.slice(0, 1)}</span><span class="p-name">${p.name}</span>`;
      chip.addEventListener("click", () => applyPresetToSelected(p.id));
      els.presetGrid.appendChild(chip);
    });
  }

  function applyPresetToSelected(presetId) {
    const layer = selectedLayer();
    if (!layer || !layer.content) return toast("Select a layer first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, layer);
    const out = PFFilters.applyPreset(src.content, presetId);
    pushHistory();
    replaceLayerContent(layer, out);
    toast("Filter applied");
  }

  function applyAdjustments() {
    const layer = selectedLayer();
    if (!layer || !layer.content) return toast("Select a layer first", true);
    const fx = {
      brightness: 1 + state.fx.brightness / 100,
      contrast: 1 + state.fx.contrast / 100,
      saturate: 1 + state.fx.saturate / 100,
      hue: state.fx.hue,
      blur: state.fx.blur,
    };
    const sharpen = state.fx.sharpen;
    const any = fx.brightness !== 1 || fx.contrast !== 1 || fx.saturate !== 1 || fx.hue !== 0 || fx.blur !== 0 || sharpen > 0;
    if (!any) return toast("Nothing to apply — move a slider first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, layer);
    const out = PFFilters.adjustCanvas(src.content, fx, sharpen);
    pushHistory();
    replaceLayerContent(layer, out);
    toast("Adjustments applied");
  }

  function replaceLayerContent(layer, canvas) {
    const idx = state.doc.layers.findIndex((l) => l.id === layer.id);
    if (idx < 0) return;
    const nl = PFEngine.makeFullCanvasLayer(canvas, { name: layer.name });
    nl.id = layer.id;
    // opacity was already baked into the flattened pixels
    state.doc.layers[idx] = nl;
    selectLayer(nl.id, { silent: true });
    render();
    renderLayersPanel();
    markDirty();
  }

  function resetFxSliders() {
    state.fx = { brightness: 0, contrast: 0, saturate: 0, hue: 0, blur: 0, sharpen: 0 };
    Object.entries(state.fx).forEach(([k, v]) => {
      const slider = els["fx" + k.charAt(0).toUpperCase() + k.slice(1)];
      if (slider) { slider.value = v; sliderFill(slider); }
      const val = els["v" + k.charAt(0).toUpperCase() + k.slice(1)];
      if (val) val.textContent = v;
    });
  }

  // ================================================================== tooltips
  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  }

  function initTooltips() {
    const tip = els.tooltip;
    let timer = null;
    let current = null;

    function hideTip() {
      tip.classList.add("hidden");
    }

    function showTip(el) {
      const [title, desc, kbd] = String(el.dataset.tip || "").split("|");
      if (!title && !desc) return hideTip();
      tip.innerHTML =
        `<div class="tooltip-title"><span>${escapeHtml(title)}</span>${kbd ? `<span class="tooltip-kbd">${escapeHtml(kbd)}</span>` : ""}</div>` +
        (desc ? `<div class="tooltip-desc">${escapeHtml(desc)}</div>` : "");
      tip.classList.remove("hidden");
    }

    function moveTip(e) {
      if (tip.classList.contains("hidden")) return;
      const pad = 14;
      let x = e.clientX + pad;
      let y = e.clientY + pad;
      const r = tip.getBoundingClientRect();
      if (x + r.width > window.innerWidth - 8) x = e.clientX - r.width - pad;
      if (y + r.height > window.innerHeight - 8) y = e.clientY - r.height - pad;
      tip.style.left = Math.max(6, x) + "px";
      tip.style.top = Math.max(6, y) + "px";
    }

    document.addEventListener("pointerover", (e) => {
      const el = e.target.closest ? e.target.closest("[data-tip]") : null;
      if (!el) {
        clearTimeout(timer);
        if (current) { current = null; hideTip(); }
        return;
      }
      if (el === current) return;
      clearTimeout(timer);
      current = el;
      timer = setTimeout(() => { showTip(el); moveTip(e); }, 240);
    });
    document.addEventListener("pointermove", (e) => { if (current) moveTip(e); });
    document.addEventListener("pointerout", (e) => {
      const el = e.target.closest ? e.target.closest("[data-tip]") : null;
      if (el !== current) return;
      // Moving between children (icon → kbd) of the same button shouldn't hide.
      const rt = e.relatedTarget;
      const stillInside = rt && rt.closest && rt.closest("[data-tip]") === el;
      if (!stillInside) {
        clearTimeout(timer);
        current = null;
        hideTip();
      }
    });
  }

  // ================================================================== item inspector
  const FX_MAP = {
    shadow: {
      color: { id: "fxShadowColor", toLayer: (v) => v, toUI: (v) => v },
      blur: { id: "fxShadowBlur", toLayer: (v) => v, toUI: (v) => v },
      x: { id: "fxShadowX", toLayer: (v) => v, toUI: (v) => v },
      y: { id: "fxShadowY", toLayer: (v) => v, toUI: (v) => v },
      opacity: { id: "fxShadowOp", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
    },
    border: {
      color: { id: "fxBorderColor", toLayer: (v) => v, toUI: (v) => v },
      width: { id: "fxBorderWidth", toLayer: (v) => v, toUI: (v) => v },
      radius: { id: "fxBorderRadius", toLayer: (v) => v, toUI: (v) => v },
    },
    reflection: {
      opacity: { id: "fxReflOp", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
      gap: { id: "fxReflGap", toLayer: (v) => v, toUI: (v) => v },
      height: { id: "fxReflH", toLayer: (v) => v / 100, toUI: (v) => Math.round((v || 0) * 100) },
    },
    bg: {
      color: { id: "fxBgColor", toLayer: (v) => v, toUI: (v) => v },
      radius: { id: "fxBgRadius", toLayer: (v) => v, toUI: (v) => v },
    },
  };

  function bindInspector() {
    const num = (id, apply) => {
      const el = els[id];
      el.addEventListener("input", () => {
        const l = selectedLayer();
        if (!l) return;
        const v = parseFloat(el.value);
        if (!Number.isFinite(v)) return;
        apply(l, v);
        render();
      });
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    num("inspX", (l, v) => { l.transform.x = v; });
    num("inspY", (l, v) => { l.transform.y = v; });
    num("inspW", (l, v) => { const c = l.content; if (c) l.transform.scaleX = v / c.width; });
    num("inspH", (l, v) => { const c = l.content; if (c) l.transform.scaleY = v / c.height; });
    num("inspRot", (l, v) => { l.transform.rotation = (v * Math.PI) / 180; });
    num("inspOp", (l, v) => { l.opacity = clamp(v / 100, 0.05, 1); });

    els.inspFlipX.addEventListener("click", () => commitLayer((l) => { l.transform.scaleX *= -1; }));
    els.inspFlipY.addEventListener("click", () => commitLayer((l) => { l.transform.scaleY *= -1; }));
    els.inspRotL.addEventListener("click", () => commitLayer((l) => { l.transform.rotation -= Math.PI / 2; }));
    els.inspRotR.addEventListener("click", () => commitLayer((l) => { l.transform.rotation += Math.PI / 2; }));

    els.inspEye.addEventListener("click", () => {
      const l = selectedLayer();
      if (!l) return;
      l.visible = !l.visible;
      render();
      renderLayersPanel();
      markDirty();
    });
    els.inspLock.addEventListener("click", toggleLockSelected);
    els.inspDup.addEventListener("click", duplicateLayer);
    els.inspDel.addEventListener("click", () => { if (state.selectedId) removeLayer(state.selectedId); });
    els.inspReturn.addEventListener("click", () => selectLayer(null));

    // Blend mode
    els.inspBlend.innerHTML = PFEngine.BLEND_MODES
      .map(([v, label]) => `<option value="${v}">${label}</option>`).join("");
    els.inspBlend.addEventListener("change", () => {
      const l = selectedLayer();
      if (!l) return;
      pushHistory();
      l.blend = els.inspBlend.value;
      render();
      markDirty();
    });

    els.inspToFront.addEventListener("click", () => moveToEdge(state.doc.layers.length - 1));
    els.inspFwd.addEventListener("click", () => moveLayer(1));
    els.inspBack.addEventListener("click", () => moveLayer(-1));
    els.inspToBack.addEventListener("click", () => moveToEdge(0));

    document.querySelectorAll("#inspector [data-align]").forEach((b) => b.addEventListener("click", () => alignLayer(b.dataset.align)));

    // effect groups
    document.querySelectorAll(".fx-group").forEach((g) => {
      const fxName = g.dataset.fx;
      const onInput = g.querySelector("input[type=checkbox]");
      const head = g.querySelector(".fx-head");
      head.addEventListener("click", (e) => {
        // The switch <label> natively toggles the checkbox (its <input> is a
        // descendant, so e.target.closest("label") is set). Calling
        // onInput.click() for label clicks would toggle it TWICE and cancel
        // the effect out. Only clicks outside the label toggle manually.
        if (!e.target.closest("label")) onInput.click();
      });
      onInput.addEventListener("change", () => {
        const l = selectedLayer();
        if (!l) return;
        if (onInput.checked && l.fullCanvas) {
          // Full-canvas layers (brush strokes, filtered images) fill the whole
          // document, so shadows/reflections would extend past the canvas and
          // look invisible. Trim to the item's actual pixels first.
          if (PFEngine.trimToContent(l)) l.fullCanvas = false;
        }
        l.effects[fxName].on = onInput.checked;
        g.classList.toggle("on", onInput.checked);
        pushHistory();
        render();
        renderLayersPanel();
        markDirty();
      });
      Object.entries(FX_MAP[fxName]).forEach(([prop, cfg]) => {
        const input = $(cfg.id);
        input.addEventListener("input", () => {
          const l = selectedLayer();
          if (!l) return;
          l.effects[fxName][prop] = cfg.toLayer(input.type === "color" ? input.value : parseFloat(input.value));
          render();
        });
        input.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
      });
    });
  }

  function commitLayer(fn) {
    const l = selectedLayer();
    if (!l) return;
    pushHistory();
    fn(l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function moveToEdge(index) {
    const idx = state.doc.layers.findIndex((l) => l.id === state.selectedId);
    if (idx < 0 || idx === index) return;
    pushHistory();
    const [l] = state.doc.layers.splice(idx, 1);
    state.doc.layers.splice(index, 0, l);
    render();
    renderLayersPanel();
    markDirty();
  }

  function alignLayer(dir) {
    const l = selectedLayer();
    if (!l || !l.content) return;
    const corners = PFEngine.layerCorners(l);
    if (!corners.length) return;
    const xs = corners.map((c) => c.x), ys = corners.map((c) => c.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const bw = maxX - minX, bh = maxY - minY;
    const dx = dir === "left" ? -minX
      : dir === "center" ? (state.doc.width - bw) / 2 - minX
        : dir === "right" ? state.doc.width - bw - minX : 0;
    const dy = dir === "top" ? -minY
      : dir === "middle" ? (state.doc.height - bh) / 2 - minY
        : dir === "bottom" ? state.doc.height - bh - minY : 0;
    pushHistory();
    l.transform.x += dx;
    l.transform.y += dy;
    render();
    markDirty();
  }

  function applyTextProp(kind, value, history = true) {
    const layer = selectedLayer();
    if (!layer || layer.type !== "text") return;
    if (history) pushHistory();
    layer[kind] = value;
    PFEngine.renderContent(layer);
    render();
    syncInspector();
    if (history) markDirty();
  }

  function applyShapeProp(kind, value, history = true) {
    const layer = selectedLayer();
    if (!layer || layer.type !== "shape") return;
    if (history) pushHistory();
    layer[kind] = value;
    PFEngine.renderContent(layer);
    render();
    syncInspector();
    if (history) markDirty();
  }

  function renderInspector() {
    const l = selectedLayer();
    if (!l) {
      renderRightDock();
      return;
    }
    l.effects = PFEngine.mergeEffects(l.effects);

    els.inspIcon.innerHTML = PFIcons.svg(l.type === "text" ? "text" : l.type === "shape" ? "shape" : "image");
    els.inspName.textContent = l.name;
    els.inspType.textContent = l.type === "raster" ? (l.fullCanvas ? "image layer" : "image") : l.type;
    els.inspEye.innerHTML = PFIcons.svg(l.visible ? "eye" : "eye-off");
    els.inspLock.innerHTML = PFIcons.svg(l.locked ? "lock" : "unlock");
    els.inspLock.classList.toggle("on", !!l.locked);
    els.inspector.classList.toggle("is-locked", !!l.locked);
    els.inspBlend.value = l.blend || "normal";

    els.inspTypeSection.innerHTML = "";
    const sec = els.inspTypeSection;
    if (l.type === "text") buildInspectorText(sec, l);
    else if (l.type === "shape") buildInspectorShape(sec, l);
    else buildInspectorImage(sec, l);

    renderRightDock();
    syncInspector();
  }

  function syncInspector() {
    const l = selectedLayer();
    if (!l || els.inspector.classList.contains("hidden")) return;
    const t = l.transform;
    const fx = l.effects || {};
    const set = (el, v) => { if (document.activeElement !== el) el.value = v; };
    set(els.inspX, Math.round(t.x * 10) / 10);
    set(els.inspY, Math.round(t.y * 10) / 10);
    const c = l.content;
    if (c) {
      set(els.inspW, Math.round(c.width * Math.abs(t.scaleX) * 10) / 10);
      set(els.inspH, Math.round(c.height * Math.abs(t.scaleY) * 10) / 10);
    }
    set(els.inspRot, Math.round(((t.rotation * 180) / Math.PI) * 10) / 10);
    set(els.inspOp, Math.round(l.opacity * 100));
    els.inspEye.innerHTML = PFIcons.svg(l.visible ? "eye" : "eye-off");

    for (const fxName of Object.keys(FX_MAP)) {
      const g = document.querySelector(`.fx-group[data-fx="${fxName}"]`);
      if (!g) continue;
      const e = fx[fxName] || {};
      const on = g.querySelector("input[type=checkbox]");
      if (on.checked !== !!e.on) on.checked = !!e.on;
      g.classList.toggle("on", !!e.on);
      Object.entries(FX_MAP[fxName]).forEach(([prop, cfg]) => {
        const input = $(cfg.id);
        if (!input) return;
        const v = e[prop] == null ? (PFEngine.EFFECT_DEFAULTS[fxName] ? PFEngine.EFFECT_DEFAULTS[fxName][prop] : 0) : e[prop];
        const ui = cfg.toUI(v);
        if (document.activeElement !== input) input.value = ui;
        if (input.type === "range") sliderFill(input);
      });
    }
  }

  function buildInspectorImage(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Image</div>
      <div class="type-row2">
        <button class="ty-btn" id="inspReplace" data-tip="Replace image|Swap this item's image for another file">${PFIcons.svg("image")} Replace…</button>
        <button class="ty-btn" id="inspAiBg" data-tip="Remove background|Let AI cut out the main subject — Pro feature">${PFIcons.svg("sparkles")} Bg AI</button>
      </div>`;
    sec.querySelector("#inspReplace").addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => {
        const f = input.files[0];
        if (!f) return;
        const url = URL.createObjectURL(f);
        loadImage(url).then((img) => {
          URL.revokeObjectURL(url);
          const canvas = document.createElement("canvas");
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          canvas.getContext("2d").drawImage(img, 0, 0);
          pushHistory();
          const oldW = l.content.width * Math.abs(l.transform.scaleX);
          const oldH = l.content.height * Math.abs(l.transform.scaleY);
          l.content = canvas;
          l.transform.scaleX = oldW / canvas.width;
          l.transform.scaleY = oldH / canvas.height;
          render();
          renderLayersPanel();
          markDirty();
          toast("Image replaced");
        }).catch(() => toast("Could not load that image", true));
      };
      input.click();
    });
    sec.querySelector("#inspAiBg").addEventListener("click", () => aiEditSelection("Remove the background completely — keep only the main subject with a clean edge."));
  }

  function buildInspectorText(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Text</div>
      <div class="type-field"><label>Font</label>
        <select id="inspFont">${FONTS.map((f) => `<option value="${f}" ${l.fontFamily === f ? "selected" : ""}>${f}</option>`).join("")}</select></div>
      <div class="type-row">
        <div class="type-field"><label>Size</label><input type="number" id="inspFontSize" min="4" max="600" value="${l.fontSize}"></div>
        <div class="type-field"><label>Line height</label><input type="number" id="inspLineH" min="0.6" max="4" step="0.05" value="${l.lineHeight}"></div>
      </div>
      <div class="type-row">
        <div class="type-field"><label>Spacing</label><input type="number" id="inspSpacing" min="-4" max="40" step="0.5" value="${l.letterSpacing || 0}"></div>
        <div class="type-field"><label>Colour</label><input type="color" id="inspTextColor" value="${l.color}"></div>
      </div>
      <div class="type-field"><label>Style</label>
        <div class="seg-sm">
          <button class="${l.fontWeight >= 700 ? "active" : ""}" data-sty="bold"><b>B</b></button>
          <button class="${l.fontStyle === "italic" ? "active" : ""}" data-sty="italic"><i>I</i></button>
          <button class="${l.upper ? "active" : ""}" data-sty="upper">A̲A</button>
        </div>
      </div>
      <div class="type-field"><label>Align</label>
        <div class="seg-sm">
          <button class="${l.align === "left" ? "active" : ""}" data-txtalign="left">${PFIcons.svg("align-left")}</button>
          <button class="${l.align === "center" ? "active" : ""}" data-txtalign="center">${PFIcons.svg("align-center")}</button>
          <button class="${l.align === "right" ? "active" : ""}" data-txtalign="right">${PFIcons.svg("align-right")}</button>
        </div>
      </div>
      <div class="type-field"><label>Outline</label>
        <div class="type-row">
          <div class="type-field"><input type="color" id="inspStrokeColor" value="${l.textStroke || "#000000"}"></div>
          <div class="type-field"><input type="number" id="inspStrokeW" min="0" max="24" value="${l.textStrokeWidth || 0}"></div>
        </div>
      </div>
      <div class="type-field"><button class="ty-btn" id="inspEditText">${PFIcons.svg("edit")} Edit text…</button></div>
    `;
    const bindNum = (id, kind, parse = (v) => v) => {
      const el = sec.querySelector(id);
      el.addEventListener("input", () => applyTextProp(kind, parse(el.value), false));
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    sec.querySelector("#inspFont").addEventListener("change", (e) => applyTextProp("fontFamily", e.target.value));
    bindNum("#inspFontSize", "fontSize", (v) => clamp(parseFloat(v) || 12, 4, 600));
    bindNum("#inspLineH", "lineHeight", (v) => clamp(parseFloat(v) || 1.25, 0.6, 4));
    bindNum("#inspSpacing", "letterSpacing", (v) => clamp(parseFloat(v) || 0, -4, 40));
    sec.querySelector("#inspTextColor").addEventListener("change", (e) => applyTextProp("color", e.target.value));
    sec.querySelectorAll("[data-sty]").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.sty === "bold") applyTextProp("fontWeight", l.fontWeight >= 700 ? 400 : 700);
      else if (b.dataset.sty === "italic") applyTextProp("fontStyle", l.fontStyle === "italic" ? "normal" : "italic");
      else applyTextProp("upper", !l.upper);
      renderInspector();
    }));
    sec.querySelectorAll("[data-txtalign]").forEach((b) => b.addEventListener("click", () => {
      applyTextProp("align", b.dataset.txtalign);
      renderInspector();
    }));
    sec.querySelector("#inspStrokeColor").addEventListener("change", (e) => applyTextProp("textStroke", e.target.value));
    bindNum("#inspStrokeW", "textStrokeWidth", (v) => clamp(parseFloat(v) || 0, 0, 24));
    sec.querySelector("#inspEditText").addEventListener("click", () => openTextEditor(l));
  }

  function buildInspectorShape(sec, l) {
    sec.innerHTML = `
      <div class="insp-label">Shape</div>
      <div class="type-field"><label>Type</label>
        <select id="inspKind">${PFTools.SHAPE_KINDS.map(([k, ic, name]) => `<option value="${k}" ${l.shapeKind === k ? "selected" : ""}>${ic} ${name}</option>`).join("")}</select></div>
      <div class="type-row">
        <div class="type-field"><label>Fill</label><input type="color" id="inspFill" value="${l.fill}"></div>
        <div class="type-field"><label>Outline</label><input type="color" id="inspStroke" value="${l.stroke}"></div>
      </div>
      <div class="type-row">
        <div class="type-field"><label>Weight</label><input type="number" id="inspSw" min="0" max="80" value="${l.strokeWidth}"></div>
        <div class="type-field" id="inspRadiusWrap"><label>Radius</label><input type="number" id="inspRadius" min="0" max="400" value="${l.radius || 0}"></div>
        <div class="type-field" id="inspPointsWrap"><label>Points</label><input type="number" id="inspPoints" min="3" max="24" value="${l.points || 5}"></div>
      </div>`;
    const kindEl = sec.querySelector("#inspKind");
    const show = (v) => {
      sec.querySelector("#inspRadiusWrap").style.display = v === "rect" ? "flex" : "none";
      sec.querySelector("#inspPointsWrap").style.display = v === "star" ? "flex" : "none";
    };
    show(l.shapeKind);
    kindEl.addEventListener("change", (e) => { applyShapeProp("shapeKind", e.target.value); show(e.target.value); });
    sec.querySelector("#inspFill").addEventListener("change", (e) => applyShapeProp("fill", e.target.value));
    sec.querySelector("#inspStroke").addEventListener("change", (e) => applyShapeProp("stroke", e.target.value));
    const bindNum = (id, kind, parse = (v) => v) => {
      const el = sec.querySelector(id);
      el.addEventListener("input", () => applyShapeProp(kind, parse(el.value), false));
      el.addEventListener("change", () => { if (selectedLayer()) { pushHistory(); markDirty(); } });
    };
    bindNum("#inspSw", "strokeWidth", (v) => clamp(parseFloat(v) || 0, 0, 80));
    bindNum("#inspRadius", "radius", (v) => clamp(parseFloat(v) || 0, 0, 400));
    bindNum("#inspPoints", "points", (v) => clamp(parseInt(v, 10) || 5, 3, 24));
  }

  /**
   * AI-edit just the selected layer (used by the inspector's Remove background
   * shortcut) — cloud only, since it's a real image-to-image edit, not
   * something the offline command router can do. Gates on hasCloudAI()
   * (Pro OR your own key), matching every other cloud call — it used to check
   * Pro alone, which silently no-op'd for BYOK-only users. The busy/result
   * status rides in the AI Chat thread rather than a separate output panel,
   * so it's visible alongside everything else the AI has done.
   */
  async function aiEditSelection(prompt) {
    if (state.aiBusy) return;
    if (!hasCloudAI()) { switchTab("ai"); return; }
    const l = selectedLayer();
    if (!l || !l.content) return toast("Select an image first", true);
    const src = PFEngine.flattenLayerToFullCanvas(state.doc, l);
    const prepped = prepForAI(src.content);
    switchTab("ai");
    const statusMsg = pushChatMessage("assistant", "Removing the background with cloud AI…", { provider: "cloud" });
    renderAIChatThread();
    state.aiBusy = true;
    try {
      const res = await sendMessage({ type: "ai:edit", image: prepped.dataURL, prompt });
      if (!res.ok) {
        statusMsg.text = res.code === "AI_LOCKED" ? res.error : `AI edit failed: ${res.error || "unknown error"}`;
        renderAIChatThread();
        return;
      }
      const canvas = await cropResultToAspect(res.image, prepped.origW, prepped.origH);
      pushHistory();
      replaceLayerContent(l, canvas);
      statusMsg.text = "Done — background removed on the selected layer.";
      renderAIChatThread();
      toast("AI edit applied to selection");
    } catch (err) {
      statusMsg.text = "AI edit failed: " + ((err && err.message) || err);
      renderAIChatThread();
    } finally {
      state.aiBusy = false;
    }
  }

  function prepForAI(canvas) {
    const long = Math.max(canvas.width, canvas.height);
    const scale = Math.min(1, 1536 / long);
    const w = Math.max(1, Math.round(canvas.width * scale));
    const h = Math.max(1, Math.round(canvas.height * scale));
    const side = Math.max(w, h);
    const padded = Math.ceil(side / 256) * 256;
    const out = document.createElement("canvas");
    out.width = padded;
    out.height = padded;
    const ctx = out.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, padded, padded);
    ctx.drawImage(canvas, (padded - w) / 2, (padded - h) / 2, w, h);
    return { dataURL: out.toDataURL("image/png"), w, h, origW: canvas.width, origH: canvas.height };
  }

  function cropResultToAspect(dataURL, origW, origH) {
    return loadImage(dataURL).then((img) => {
      const side = img.naturalWidth;
      const ar = origW / origH;
      let cw = side, ch = side;
      if (ar > 1) ch = Math.round(side / ar);
      else cw = Math.round(side * ar);
      const canvas = document.createElement("canvas");
      canvas.width = cw;
      canvas.height = ch;
      canvas.getContext("2d").drawImage(img, (side - cw) / 2, (side - ch) / 2, cw, ch);
      // Keep small source images small — don't return a 1536px upscale.
      const target = Math.max(origW, origH);
      if (Math.max(cw, ch) > target) {
        const s = target / Math.max(cw, ch);
        const out = document.createElement("canvas");
        out.width = Math.max(1, Math.round(cw * s));
        out.height = Math.max(1, Math.round(ch * s));
        out.getContext("2d").drawImage(canvas, 0, 0, out.width, out.height);
        return out;
      }
      return canvas;
    });
  }

  // ================================================================== AI Chat
  //
  // Two engines answer here, chosen automatically per message:
  //   OFFLINE (default, always available, instant, zero download) — a
  //     lightweight command router (lib/aiassist.js) that matches what you
  //     typed against the app's real actions and drives them through the
  //     exact same functions a manual click would, so nothing it produces is
  //     ever a flattened/uneditable result. Free for everyone.
  //   CLOUD (once you add your own OpenAI key, or activate Pro) — real
  //     conversational AI, streamed token-by-token over a background Port.
  //
  // Chat history is part of the project doc (state.doc.aiChat), so it saves
  // and loads with everything else — every project keeps its own thread.

  /** Everything the offline router is allowed to do, built from the real IT
   *  tool registry — adding a synonym here is the only thing needed to teach
   *  it a new phrase for an existing tool. */
  function buildAssistCatalog() {
    const toolNames = {
      grayscale: ["black and white", "black & white", "grayscale", "greyscale", "desaturate",
        "monochrome", "no color", "no colour", "colorless", "colourless", "remove the color", "remove the colour",
        "black n white", "make it gray", "make it grey", "old photo look"],
      invert: ["invert colors", "invert colours", "invert it", "negative", "flip the colors", "flip the colours"],
      sepia: ["sepia", "sepia tone", "old timey", "vintage brown"],
      posterize: ["posterize", "poster effect", "flatten the tones", "reduce colors", "reduce colours"],
      threshold: ["threshold", "pure black and white", "high contrast black and white"],
      duotone: ["duotone", "two tone", "two color", "two colour"],
      colorOverlay: ["color overlay", "colour overlay", "tint the whole image", "wash of color", "wash of colour"],
      replaceColor: ["replace color", "replace colour", "swap the color", "swap the colour", "change the color", "change the colour"],
      blur: ["blur it", "blur", "make it blurry", "soften it", "soft focus", "out of focus"],
      sharpen: ["sharpen", "make it sharper", "crisp it up", "make it crisper", "less blurry", "more detail"],
      unsharp: ["unsharp mask", "smart sharpen"],
      noise: ["grain", "add noise", "film grain", "add texture", "grainy look"],
      pixelate: ["pixelate", "censor", "mosaic", "blur out a face", "pixel effect", "8 bit look"],
      edges: ["find edges", "edge detect", "outline effect", "line art"],
      emboss: ["emboss", "embossed", "carved effect"],
      vignette: ["vignette", "dark edges", "darken the edges", "dark corners", "spotlight effect"],
      roundCorners: ["round corners", "rounded corners", "round the corners", "curve the corners"],
      flipH: ["flip horizontal", "mirror horizontally", "flip it left to right", "mirror it"],
      flipV: ["flip vertical", "mirror vertically", "flip top to bottom"],
      rotCW: ["rotate right", "rotate clockwise", "rotate 90", "turn it right", "spin it clockwise"],
      rotCCW: ["rotate left", "rotate anticlockwise", "rotate counterclockwise", "turn it left", "spin it counterclockwise"],
      rot180: ["rotate 180", "flip upside down", "turn upside down", "spin it around"],
      straighten: ["straighten", "tilt it", "level the horizon", "fix the angle", "de-skew"],
      trim: ["trim", "autocrop", "crop transparent edges", "trim the edges", "remove the empty space"],
      removeBgEdges: ["remove background", "remove the background", "cut out the background", "remove bg",
        "delete the background", "get rid of the background", "cut the subject out", "isolate the subject",
        "transparent background"],
      colorKey: ["remove a color", "remove a colour", "green screen", "chroma key", "key out a color", "key out a colour"],
      autoEnhance: ["auto enhance", "enhance this", "auto fix", "make it pop", "make it better", "improve this",
        "fix this up", "make it look good", "auto improve"],
      autoContrast: ["auto contrast", "fix the contrast automatically"],
      autoWhite: ["auto white balance", "white balance", "fix the colors", "fix the colours", "fix white balance",
        "color cast", "colour cast", "the colors look off", "the colours look off"],
      levels: ["levels", "adjust the levels", "fix the black and white points"],
    };
    const catalog = [];
    for (const [id, names] of Object.entries(toolNames)) {
      const tool = IT[id];
      if (!tool || tool.pro) continue; // never route to a Pro-gated tool from the free offline assistant
      const c = (tool.controls || [])[0];
      catalog.push({ type: "tool", id, names, control: c ? { k: c.k, min: c.min, max: c.max, def: c.def } : null });
    }
    // "Adjustments" has 8 sliders sharing one tool — route each keyword at
    // its OWN control (saying "contrast" should move Contrast, not whichever
    // slider happens to be listed first), by reading the real min/max/default
    // straight from IT.adjust.controls so they can never drift out of sync.
    const adjustNames = {
      exposure: ["exposure"],
      brightness: ["brightness", "brighten it", "make it brighter", "darker"],
      contrast: ["contrast", "more contrast"],
      saturation: ["saturation", "saturate it", "more colourful", "more colorful",
        "reduce the saturation", "less saturated", "lower the saturation", "less colorful", "less colourful",
        "desaturate it a bit", "desaturate slightly"],
      vibrance: ["vibrance"],
      hue: ["hue", "shift the hue"],
      temperature: ["temperature", "warmer", "cooler", "warmth"],
      tint: ["tint it"],
    };
    (IT.adjust.controls || []).forEach((c) => {
      const names = adjustNames[c.k];
      if (names) catalog.push({ type: "tool", id: "adjust", names, control: { k: c.k, min: c.min, max: c.max, def: c.def } });
    });
    catalog.push({ type: "tool", id: "adjust", names: ["adjust it", "adjustments", "adjust the colors", "adjust the colours"], control: null });
    catalog.push(
      { type: "action", id: "addText", names: ["add text", "insert text", "add a text box", "add a caption"] },
      { type: "action", id: "shape:rect", names: ["add a rectangle", "add a square", "add a rect"] },
      { type: "action", id: "shape:ellipse", names: ["add a circle", "add an ellipse", "add an oval"] },
      { type: "action", id: "shape:triangle", names: ["add a triangle"] },
      { type: "action", id: "shape:star", names: ["add a star"] },
      { type: "action", id: "shape:heart", names: ["add a heart"] },
      { type: "action", id: "shape:diamond", names: ["add a diamond"] },
      { type: "action", id: "shape:line", names: ["add a line"] },
      { type: "action", id: "shape:arrow", names: ["add an arrow"] },
      { type: "action", id: "align:left", names: ["align left"] },
      { type: "action", id: "align:center", names: ["align center", "align centre", "center it horizontally"] },
      { type: "action", id: "align:right", names: ["align right"] },
      { type: "action", id: "align:top", names: ["align top"] },
      { type: "action", id: "align:middle", names: ["align middle", "center it vertically", "centre it vertically"] },
      { type: "action", id: "align:bottom", names: ["align bottom"] },
      { type: "action", id: "front", names: ["bring to front", "move to front", "move to the front"] },
      { type: "action", id: "back", names: ["send to back", "move to back", "move to the back"] },
      { type: "action", id: "forward", names: ["bring forward", "move forward", "move it up one"] },
      { type: "action", id: "backward", names: ["send backward", "move backward", "move it down one"] },
      { type: "action", id: "undo", names: ["undo", "undo that"] },
      { type: "action", id: "redo", names: ["redo", "redo that"] },
    );
    catalog.push(
      { type: "faq", id: "howAddText", names: ["how do i add text", "how to add text"],
        answer: 'Ask me to "add text", or open the Elements tab and drag the Text chip onto the canvas — then double-click it to edit.' },
      { type: "faq", id: "howExport", names: ["how do i export", "how to export", "how do i download", "how do i save my image"],
        answer: "Click Export in the top bar to download PNG, JPG or WebP. Save (Ctrl+S) keeps your editable project in this browser instead." },
      { type: "faq", id: "howBg", names: ["how do i remove the background", "how to remove background"],
        answer: 'Ask me to "remove the background" for the instant, free version — or use Image → Remove background (AI) for the neural-network version (Picsmith Pro, works offline after a one-time download).' },
      { type: "faq", id: "howLayers", names: ["what is a layer", "how do layers work"],
        answer: "Every text box, shape and image sits on its own layer, stacked like sheets of glass. The Layers tab lists them — drag to reorder, or ask me to bring something forward or back." },
      { type: "faq", id: "howUndo", names: ["how do i undo", "how to undo"],
        answer: 'Ctrl+Z undoes, Ctrl+Shift+Z redoes — or just ask me to "undo".' },
      { type: "faq", id: "whatCanYouDo", names: ["what can you do", "help", "what can the ai do"],
        answer: 'I can apply any of Picsmith\'s image tools ("make this black and white", "blur it a lot", "reduce the contrast a little"), add text/shapes, align and arrange layers, chain a few of these in one message ("make this black and white then add a vignette"), and undo/redo — all instantly, offline.' },
    );
    return catalog;
  }

  /**
   * Run every decision from PFAssist.route() in order and combine their
   * replies into one message — a compound request ("black and white then a
   * vignette") reads as one confirmation, not two separate chat bubbles.
   */
  async function dispatchAssistDecisions(decisions) {
    const replies = [];
    for (const d of decisions) {
      try { replies.push(await dispatchAssistDecision(d)); }
      catch (err) { replies.push("Something went wrong: " + ((err && err.message) || err)); }
    }
    return replies.join(" ");
  }

  /** Actually perform a routed decision, returning the reply text. */
  async function dispatchAssistDecision(decision) {
    if (decision.kind === "faq") return decision.answer;
    if (decision.kind === "unknown") {
      // A moderate-but-not-confident match is a real guess, not a shrug —
      // and never repeat the "add your key" nag here; that lives once, in
      // the dismissible strip above the composer, not on every reply.
      if (decision.hint) return `Not sure what you meant by "${decision.segment}" — closest thing I know is "${decision.hint}". Try rephrasing, or ask "what can you do?".`;
      return 'I\'m not sure how to do that yet. Try something like "make this black and white", "add a vignette", or ask "what can you do?".';
    }
    if (decision.kind === "tool") {
      const tool = IT[decision.id];
      const layer = selectedLayer();
      if (!layer || !layer.content) return `Select an image, text or shape on the canvas first, then ask me to apply ${tool.name.toLowerCase()}.`;
      const preset = decision.control && decision.value !== undefined ? { [decision.control.k]: decision.value } : null;
      await openImageTool(decision.id, preset);
      if ((tool.controls || []).length) {
        return `Opened ${tool.name} — I've set it up${preset ? "" : " with the defaults"}. Check the preview and hit Apply if it looks right, or tweak the sliders first.`;
      }
      return `Done — applied ${tool.name.toLowerCase()}.`;
    }
    return dispatchAssistAction(decision.id);
  }

  async function dispatchAssistAction(id) {
    const center = { x: state.doc.width / 2, y: state.doc.height / 2 };
    if (id === "addText") { addElementAt("text", center); return "Added a text box — type your text and click away when you're done."; }
    if (id.startsWith("shape:")) { addElementAt(id, center); return `Added a ${id.slice(6)} shape.`; }
    if (id.startsWith("align:")) {
      if (!selectedLayer()) return "Select something on the canvas first, then ask me to align it.";
      const dir = id.slice(6);
      alignLayer(dir);
      return `Aligned to the ${dir}.`;
    }
    if (id === "front" || id === "back" || id === "forward" || id === "backward") {
      if (!selectedLayer()) return "Select a layer first, then ask me to move it.";
      if (id === "front") moveToEdge(state.doc.layers.length - 1);
      else if (id === "back") moveToEdge(0);
      else moveLayer(id === "forward" ? 1 : -1);
      return id === "front" ? "Brought it to the front." : id === "back" ? "Sent it to the back."
        : id === "forward" ? "Moved it forward one." : "Moved it backward one.";
    }
    if (id === "undo") { await undo(); return "Undone."; }
    if (id === "redo") { await redo(); return "Redone."; }
    return "Sorry, something went wrong running that.";
  }

  function buildChatBubble(m) {
    const div = document.createElement("div");
    div.className = `ai-msg ai-msg-${m.role}`;
    const badge = m.role === "assistant"
      ? `<span class="ai-msg-badge ai-msg-badge-${m.provider === "cloud" ? "cloud" : "offline"}">${m.provider === "cloud" ? "Cloud" : "Offline"}</span>`
      : "";
    div.innerHTML = `<div class="ai-msg-bubble">${badge}<div class="ai-msg-text"></div></div>`;
    div.querySelector(".ai-msg-text").textContent = m.text;
    return div;
  }

  function scrollChatToBottom() {
    els.aiThread.scrollTop = els.aiThread.scrollHeight;
  }

  function renderAIChatThread() {
    const thread = state.doc.aiChat || [];
    els.aiThread.innerHTML = "";
    if (!thread.length) {
      const empty = document.createElement("div");
      empty.className = "ai-empty";
      empty.innerHTML = `<div class="ai-empty-title">Ask the AI to do something, or ask a question.</div>
        <div class="ai-suggest-row">${AI_CHAT_SUGGESTIONS.map((s) => `<button class="ai-suggest-chip">${escapeHtml(s)}</button>`).join("")}</div>`;
      empty.querySelectorAll(".ai-suggest-chip").forEach((b) => b.addEventListener("click", () => {
        els.aiPrompt.value = b.textContent;
        sendChatMessage();
      }));
      els.aiThread.appendChild(empty);
      return;
    }
    thread.forEach((m) => els.aiThread.appendChild(buildChatBubble(m)));
    scrollChatToBottom();
  }

  /** Push a finished message into this project's persisted chat history and
   *  return it — callers can keep mutating `.text` in place for status
   *  updates (e.g. "Removing the background…" → "Done"), since it's the
   *  same object sitting in the array, not a copy. */
  function pushChatMessage(role, text, opts = {}) {
    if (!state.doc.aiChat) state.doc.aiChat = [];
    const msg = { role, text, provider: opts.provider || null, ts: Date.now() };
    state.doc.aiChat.push(msg);
    markDirty();
    return msg;
  }

  function renderAIEngineStatus() {
    const cloud = hasCloudAI();
    els.aiEngineDot.classList.toggle("cloud", cloud);
    els.aiEngineText.textContent = cloud ? `Cloud · ${(state.settings && state.settings.openaiModel) || "gpt-4o"}` : "Offline assistant";
    const dismissed = !!(state.settings && state.settings.aiByokDismissed);
    els.aiByokStrip.classList.toggle("hidden", cloud || dismissed);
  }

  function autoSizeComposer() {
    els.aiPrompt.style.height = "auto";
    els.aiPrompt.style.height = Math.min(120, els.aiPrompt.scrollHeight) + "px";
  }

  /** The conversation as OpenAI chat messages — the full thread lives in the
   *  doc already, so this is just a role/content reshape, capped to the most
   *  recent turns so a long-running project's thread doesn't balloon every
   *  request. */
  function chatHistoryForCloud() {
    const SYSTEM = "You are Picsmith's AI Chat assistant, built into a browser-based photo/graphic editor. "
      + "Be concise, friendly and practical — this is a chat panel, not an essay. You can discuss photo editing, "
      + "design feedback, captions and general questions. You cannot directly manipulate the user's canvas in this "
      + "mode — if they want an edit performed, tell them to phrase it as a short direct command (e.g. \"make this "
      + "black and white\", \"add a vignette\"), which Picsmith's built-in offline tools handle instantly.";
    const turns = (state.doc.aiChat || []).slice(-16).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text }));
    return [{ role: "system", content: SYSTEM }, ...turns];
  }

  function appendStreamingBubble() {
    const bubble = buildChatBubble({ role: "assistant", text: "", provider: "cloud" });
    bubble.classList.add("ai-msg-streaming");
    els.aiThread.appendChild(bubble);
    scrollChatToBottom();
    return bubble;
  }

  /** Cloud request failed or dropped mid-stream — never leave the user with
   *  nothing: fall back to the always-available offline router instead. */
  async function fallbackToOffline(text, note) {
    const decisions = PFAssist.route(text, buildAssistCatalog());
    const reply = await dispatchAssistDecisions(decisions);
    pushChatMessage("assistant", `${note} Answered offline instead: ${reply}`, { provider: "offline" });
    renderAIChatThread();
  }

  function sendCloudChatMessage(text) {
    return new Promise((resolve) => {
      state.aiChatStreaming = true;
      els.aiGo.disabled = true;
      const bubble = appendStreamingBubble();
      let acc = "";
      let port;
      const finish = () => {
        state.aiChatStreaming = false;
        els.aiGo.disabled = false;
        try { port && port.disconnect(); } catch { /* already gone */ }
      };
      try {
        port = chrome.runtime.connect({ name: "ai-chat-stream" });
      } catch (err) {
        bubble.remove();
        finish();
        fallbackToOffline(text, "Couldn't reach the cloud AI (" + ((err && err.message) || err) + ").").then(resolve);
        return;
      }
      port.onMessage.addListener((msg) => {
        if (msg.delta) {
          acc += msg.delta;
          bubble.querySelector(".ai-msg-text").textContent = acc;
          scrollChatToBottom();
          return;
        }
        if (msg.done) {
          bubble.remove();
          pushChatMessage("assistant", acc || "(no reply)", { provider: "cloud" });
          renderAIChatThread();
          finish();
          resolve();
          return;
        }
        if (msg.ok === false) {
          bubble.remove();
          finish();
          fallbackToOffline(text, msg.error || "Cloud AI request failed.").then(resolve);
        }
      });
      port.onDisconnect.addListener(() => {
        if (state.aiChatStreaming) {
          bubble.remove();
          finish();
          fallbackToOffline(text, "The connection to OpenAI dropped.").then(resolve);
        }
      });
      port.postMessage({ type: "start", messages: chatHistoryForCloud(), model: state.settings && state.settings.openaiModel });
    });
  }

  async function sendChatMessage() {
    const text = els.aiPrompt.value.trim();
    if (!text || state.aiChatStreaming) return;
    els.aiPrompt.value = "";
    autoSizeComposer();
    pushChatMessage("user", text);
    renderAIChatThread();

    if (hasCloudAI()) {
      await sendCloudChatMessage(text);
      return;
    }
    const decisions = PFAssist.route(text, buildAssistCatalog());
    const reply = await dispatchAssistDecisions(decisions);
    pushChatMessage("assistant", reply, { provider: "offline" });
    renderAIChatThread();
  }

  // ================================================================== licensing / settings UI
  async function loadSettings() {
    const res = await sendMessage({ type: "settings:get" });
    if (res.ok) {
      state.settings = res.settings || {};
      els.setKey.value = state.settings.openaiKey || "";
      els.aiOwnKeyInput.value = state.settings.openaiKey || "";
      els.setModel.value = state.settings.openaiModel || "gpt-4o";
      els.setProvider.value = state.settings.aiBaseUrl ? "custom" : "openai";
      els.setBaseUrl.value = state.settings.aiBaseUrl || "";
      els.setBaseUrlField.classList.toggle("hidden", els.setProvider.value !== "custom");
      if (state.settings.rightDockWidth) document.documentElement.style.setProperty("--rp-w", `${state.settings.rightDockWidth}px`);
      if (Array.isArray(state.settings.swatches)) state.swatches = state.settings.swatches.slice(0, 8);
      els.setUpdateCheck.checked = !!state.settings.updateCheck;
      els.verText.textContent = appVersion();
      setUpdateStatus(`Current version ${appVersion()}.`);
      state.license = res.license && res.license.active ? res.license : null;
    }
  }

  /** Cloud AI unlocks with either a Pro key or the user's own OpenAI key. */
  const hasCloudAI = () => !!(state.license && state.license.active) || !!(state.settings && state.settings.openaiKey);

  function renderProUI() {
    const pro = !!(state.license && state.license.active);
    els.proBadge.classList.toggle("active", pro);
    renderAIEngineStatus();
    renderLicStatus();
  }

  function renderLicStatus() {
    const lic = state.license;
    if (lic && lic.active) {
      const expText = lic.exp ? new Date(lic.exp * 1000).toLocaleDateString() : "never";
      els.licStatus.textContent = `✓ Pro active${lic.exp ? ` · expires ${expText}` : " · lifetime"}.`;
      els.licStatus.style.color = "var(--green)";
    } else {
      els.licStatus.textContent = "Not activated.";
      els.licStatus.style.color = "";
    }
  }

  async function activateLicense(key) {
    const clean = String(key || "").trim();
    if (!clean) return toast("Paste a Pro key first", true);
    const res = await sendMessage({ type: "license:validate", key: clean });
    if (res.ok) {
      state.license = { active: true, tier: res.tier, keyId: res.keyId, exp: res.exp, key: clean };
      renderProUI();
      toast("Picsmith Pro activated");
    } else {
      toast(res.reason === "expired" ? "This key has expired" : "Invalid Pro key", true);
    }
  }

  /**
   * The OpenAI key can be typed in two places — Settings, and the small BYOK
   * strip above the AI Chat composer — since bringing your own key is the
   * primary way to upgrade from offline to cloud, not a buried settings
   * option. Both fields represent the same setting, so keep them mirrored and
   * re-run the engine-status check on every keystroke rather than waiting on
   * the debounced save.
   */
  let keyTimer = null;
  function setOpenAIKey(value) {
    state.settings.openaiKey = value;
    if (els.setKey.value !== value) els.setKey.value = value;
    if (els.aiOwnKeyInput.value !== value) els.aiOwnKeyInput.value = value;
    renderProUI();
    clearTimeout(keyTimer);
    keyTimer = setTimeout(() => sendMessage({ type: "settings:set", key: "openaiKey", value }), 400);
  }

  /**
   * Point AI Chat at a custom OpenAI-compatible provider (Groq, Together,
   * OpenRouter, a local Ollama/LM Studio server, anything speaking the same
   * /chat/completions shape). Nothing outside api.openai.com/picsmith's own
   * site is in host_permissions up front — this asks for access to that ONE
   * host, right when the user opts in, via chrome.permissions.request()
   * (must run synchronously off a real click, not a debounced input handler,
   * or Chrome silently refuses the prompt).
   */
  async function connectCustomProvider() {
    const raw = els.setBaseUrl.value.trim().replace(/\/+$/, "");
    if (!raw) return toast("Enter a base URL first", true);
    let url;
    try { url = new URL(raw); } catch { return toast("That doesn't look like a valid URL", true); }
    if (url.protocol !== "http:" && url.protocol !== "https:") return toast("URL must start with http:// or https://", true);

    const pattern = `${url.protocol}//${url.host}/*`;
    // If this host is already granted, this resolves immediately with no
    // prompt. Otherwise Chrome shows its own native "let this extension
    // access this site?" dialog and this waits for a real answer — same as
    // any other blocking system dialog, not a bug if it looks "stuck" mid
    // test automation with nobody there to click it.
    let granted = false;
    try {
      granted = await chrome.permissions.request({ origins: [pattern] });
    } catch (err) {
      console.error("Picsmith: permission request failed", err);
    }

    state.settings.aiBaseUrl = raw;
    await sendMessage({ type: "settings:set", key: "aiBaseUrl", value: raw });
    renderAIEngineStatus();

    if (granted) {
      toast(`Connected — AI Chat will use ${url.host}`);
    } else {
      // Some providers send permissive CORS headers and work fine without
      // this grant; strict ones (and most local servers) need it. Save
      // either way and let the first real request be the actual test.
      toast(`Saved ${url.host} without extra permission — if requests fail, that host may need it (try again).`, true);
    }
  }

  function bindSettingsUI() {
    els.setKey.addEventListener("input", (e) => setOpenAIKey(e.target.value));
    els.aiOwnKeyInput.addEventListener("input", (e) => setOpenAIKey(e.target.value));
    els.setModel.addEventListener("change", (e) => {
      // Keep the client-side copy in sync immediately — sendCloudChatMessage()
      // reads state.settings.openaiModel straight off this object to build
      // the outgoing request; leaving it stale would send the OLD model name
      // to a brand new custom provider right after switching to it.
      state.settings.openaiModel = e.target.value;
      renderAIEngineStatus();
      sendMessage({ type: "settings:set", key: "openaiModel", value: e.target.value });
    });

    els.setProvider.addEventListener("change", () => {
      const custom = els.setProvider.value === "custom";
      els.setBaseUrlField.classList.toggle("hidden", !custom);
      if (!custom) {
        // Back to plain OpenAI — clear the override so aiChatStream() falls
        // back to the real api.openai.com base immediately, no extra click.
        els.setBaseUrl.value = "";
        state.settings.aiBaseUrl = "";
        sendMessage({ type: "settings:set", key: "aiBaseUrl", value: "" });
        renderAIEngineStatus();
      }
    });

    els.setBaseUrlConnect.addEventListener("click", () => connectCustomProvider());

    els.licActivateBtn.addEventListener("click", async () => {
      await activateLicense(els.licKeyInput.value);
      els.licKeyInput.value = "";
    });
    els.licClearBtn.addEventListener("click", async () => {
      await sendMessage({ type: "license:clear" });
      state.license = null;
      renderProUI();
      toast("Pro key removed");
    });

    els.btnDownloadProject.addEventListener("click", () => {
      const data = PFProject.serializeDoc(state.doc);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      PFProject.downloadBlob(blob, state.doc.name.replace(/[^\w\- ]+/g, "").trim() + ".pfproj");
      toast("Project downloaded");
    });
    els.btnClearProjects.addEventListener("click", () => {
      confirmDialog("Delete all saved projects from this browser? Your current design stays open.", async () => {
        await PFDB.clear("projects");
        toast("Projects cleared");
      });
    });
    els.btnResetAll.addEventListener("click", () => {
      confirmDialog("This wipes ALL Picsmith data: projects, settings and license. This cannot be undone.", async () => {
        await PFDB.clear("projects");
        await chrome.storage.local.clear();
        location.reload();
      }, "Reset all data?");
    });

    // ---- updates
    els.setUpdateCheck.addEventListener("change", async (e) => {
      const on = e.target.checked;
      await sendMessage({ type: "settings:set", key: "updateCheck", value: on });
      state.settings.updateCheck = on;
      toast(on ? "Update checks on" : "Update checks off");
      if (on) runUpdateCheck({ force: true });
      else setUpdateStatus(`Current version ${appVersion()}.`);
    });
    els.btnCheckUpdate.addEventListener("click", () => runUpdateCheck({ force: true }));
    els.btnGetUpdate.addEventListener("click", () => {
      const url = state.updateInfo && state.updateInfo.releaseUrl;
      if (url) chrome.tabs.create({ url });
    });

    // ---- support
    els.btnSupport.addEventListener("click", () => sendMessage({ type: "support:open" }));
  }

  // ================================================================== updates
  const appVersion = () => chrome.runtime.getManifest().version;

  function setUpdateStatus(text, tone = "") {
    els.updateStatus.textContent = text;
    els.updateStatus.className = "hint" + (tone ? " " + tone : "");
  }

  /**
   * Ask the worker to compare this build against the published version file.
   * Nothing is installed automatically — Chrome only lets Web Store extensions
   * self-update, so an unpacked build can at most point the user at the download.
   */
  async function runUpdateCheck({ force = false } = {}) {
    if (force) setUpdateStatus("Checking…");
    const res = await sendMessage({ type: "update:check", force });
    if (!res || !res.ok) {
      if (force) setUpdateStatus((res && res.error) || "Couldn't check for updates.", "warn");
      return;
    }
    if (res.skipped) {
      setUpdateStatus(`Current version ${res.current}.`);
      return;
    }
    state.updateInfo = res;
    if (res.updateAvailable) {
      els.btnGetUpdate.classList.remove("hidden");
      setUpdateStatus(`Version ${res.latest} is available — you're on ${res.current}.`, "good");
      toast(`Picsmith ${res.latest} is available`);
    } else {
      els.btnGetUpdate.classList.add("hidden");
      setUpdateStatus(`Up to date — version ${res.current}.`);
    }
  }

  // ================================================================== save
  function markDirty() {
    render();
    if (state.layersTabActive) renderLayersPanel();
    updateTopbar();
    clearTimeout(state.saveTimer);
    state.saveTimer = setTimeout(saveProject, 1500);
  }

  async function saveProject() {
    if (!state.doc) return;
    try {
      const flat = PFEngine.flattenDoc(state.doc);
      const data = PFProject.serializeDoc(state.doc);
      await PFDB.put("projects", {
        id: state.doc.id,
        name: state.doc.name,
        width: state.doc.width,
        height: state.doc.height,
        template: state.doc.template,
        updatedAt: Date.now(),
        thumbnail: PFProject.makeThumbnail(flat),
        data,
      });
    } catch (err) {
      console.error("Picsmith save failed:", err);
    }
  }

  // ================================================================== modals
  function openModal(id) {
    const back = $(id);
    back.classList.remove("hidden");
    // Re-centre on every open — a drag from a previous session shouldn't
    // leave the NEXT dialog (a different one, or the same one reopened)
    // starting off in some odd corner of the screen.
    const modal = back.querySelector(".modal");
    if (modal) { modal.style.position = ""; modal.style.left = ""; modal.style.top = ""; modal.style.margin = ""; }
  }
  function closeModal(id) {
    $(id).classList.add("hidden");
  }
  function closeAllModals() {
    document.querySelectorAll(".modal-back").forEach((m) => m.classList.add("hidden"));
  }

  /**
   * Every dialog can be dragged by its title bar. The motivating case: the
   * Image tool dialog previewing live on the canvas sits centred by default,
   * which can cover exactly the part of the image you're trying to watch
   * while dragging a slider — dragging it aside fixes that without losing
   * the live preview underneath.
   */
  function bindDraggableModals() {
    document.querySelectorAll(".modal-back .modal-head").forEach((head) => {
      const modal = head.closest(".modal");
      if (!modal) return;
      head.classList.add("draggable");

      head.addEventListener("pointerdown", (e) => {
        if (e.button !== 0 || e.target.closest("button")) return; // let the × still work
        const startRect = modal.getBoundingClientRect();
        const startX = e.clientX, startY = e.clientY;

        // Switch from flex-centred to an explicit fixed position anchored at
        // its current spot, so the very first move doesn't jump the dialog.
        modal.style.position = "fixed";
        modal.style.margin = "0";
        modal.style.left = `${startRect.left}px`;
        modal.style.top = `${startRect.top}px`;
        head.setPointerCapture(e.pointerId);
        head.classList.add("dragging");

        const onMove = (ev) => {
          const w = modal.offsetWidth, h = modal.offsetHeight;
          const pad = 24; // keep at least this much of the dialog on-screen
          const nx = clamp(startRect.left + (ev.clientX - startX), pad - w + 40, window.innerWidth - 40);
          const ny = clamp(startRect.top + (ev.clientY - startY), 0, window.innerHeight - 40);
          modal.style.left = `${nx}px`;
          modal.style.top = `${ny}px`;
        };
        const onUp = () => {
          head.classList.remove("dragging");
          window.removeEventListener("pointermove", onMove);
          window.removeEventListener("pointerup", onUp);
        };
        window.addEventListener("pointermove", onMove);
        window.addEventListener("pointerup", onUp);
      });
    });
  }

  function confirmDialog(text, onOk, title = "Are you sure?") {
    els.confirmText.textContent = text;
    els.confirmTitle.textContent = title;
    els.confirmCancel.classList.remove("hidden");
    els.confirmOk.textContent = "Confirm";
    els.confirmOk.className = "btn danger";
    els.confirmOk.onclick = () => {
      closeModal("modalConfirm");
      onOk();
    };
    els.confirmCancel.onclick = () => closeModal("modalConfirm");
    openModal("modalConfirm");
  }

  /** A plain info dialog (Help > Keyboard shortcuts) reusing the confirm modal. */
  function showHelpDialog(title, html) {
    els.confirmTitle.textContent = title;
    els.confirmText.innerHTML = html;
    els.confirmCancel.classList.add("hidden");
    els.confirmOk.textContent = "Got it";
    els.confirmOk.className = "btn primary";
    els.confirmOk.onclick = () => closeModal("modalConfirm");
    openModal("modalConfirm");
  }

  function showShortcutsHelp() {
    const rows = [
      ["V B E I T U", "Move / Brush / Eraser / Eyedropper / Text / Shape"],
      ["F G L K", "Fill / Gradient / Blur brush / Sharpen brush"],
      ["O N S", "Dodge / Burn / Clone stamp"],
      ["C Z H", "Crop / Zoom / Pan"],
      ["Ctrl+Z / Ctrl+Shift+Z", "Undo / Redo"],
      ["Ctrl+X / Ctrl+C / Ctrl+V", "Cut / Copy / Paste the selected item"],
      ["Ctrl+D", "Duplicate the selected item"],
      ["Ctrl+Shift+C", "Copy the item (or design) to the clipboard as an image"],
      ["Alt + drag", "Drag off a copy, leaving the original behind"],
      ["Ctrl (while dragging)", "Temporarily ignore the smart guides"],
      ["Ctrl+L", "Lock / unlock the selected layer"],
      ["Ctrl+M", "Image adjustments"],
      ["Ctrl+B", "Remove the background (offline AI)"],
      ["Ctrl+A", "Select the top layer"],
      ["Ctrl+G", "Show / hide the grid"],
      ["Ctrl+S / Ctrl+E", "Save project / Export"],
      ["0 / 1 / + / −", "Fit / 100% / Zoom in / Zoom out"],
      ["Delete", "Remove selected layer"],
      ["Arrow keys", "Nudge selection (Shift = ×10)"],
      ["Space (hold)", "Temporary pan"],
      ["Enter / Esc", "Apply / cancel crop"],
    ];
    const html = `<div style="display:grid;grid-template-columns:auto 1fr;gap:8px 16px;font-size:12.5px;text-align:left">${rows
      .map(([k, d]) => `<span class="tooltip-kbd" style="justify-self:start">${escapeHtml(k)}</span><span>${escapeHtml(d)}</span>`)
      .join("")}</div>`;
    showHelpDialog("Keyboard shortcuts", html);
  }

  function showAboutDialog() {
    const pro = !!(state.license && state.license.active);
    const key = !!(state.settings && state.settings.openaiKey);
    const html = `
      <div style="text-align:left;font-size:12.5px;line-height:1.6;color:var(--text-2)">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
          <svg width="34" height="34" viewBox="0 0 32 32" aria-hidden="true">
            <rect x="1" y="1" width="30" height="30" rx="7" fill="#3b82f6" />
            <path d="M16 5.5 18.4 13.6 26.5 16 18.4 18.4 16 26.5 13.6 18.4 5.5 16 13.6 13.6 Z" fill="#fff" />
          </svg>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--text)">Picsmith</div>
            <div style="font-size:11px;color:var(--text-3)">Version ${escapeHtml(appVersion())}</div>
          </div>
        </div>
        <p style="margin-bottom:10px">
          A layer-based photo and design editor that runs entirely inside your browser —
          no install of a separate app, no account, and nothing uploaded unless you
          explicitly run an AI tool.
        </p>
        <p style="margin-bottom:10px">
          <b style="color:var(--text)">Free, forever:</b> layers, blend modes, smart guides,
          16 tools, 32 image-menu operations, templates and full-quality editing — all offline.
        </p>
        <p style="margin-bottom:10px">
          <b style="color:var(--text)">AI:</b> ${key ? "your own OpenAI key is active — cloud AI is unlocked." : "bring your own OpenAI key to unlock cloud AI for free, or"} ${pro ? "" : "activate Picsmith Pro for on-device AI (like background removal) and full-resolution export."}
          ${pro ? "Picsmith Pro is active — on-device AI and full-resolution export are unlocked." : ""}
        </p>
        <p style="margin-bottom:10px">
          <b style="color:var(--text)">Privacy:</b> your designs live in this browser's own
          storage. The only network requests this extension ever makes are ones you triggered —
          an AI tool, an explicit background-removal download, or an opt-in update check.
        </p>
        <div style="display:flex;gap:14px;margin-top:14px;padding-top:12px;border-top:1px solid var(--border-soft);font-size:11.5px">
          <a href="#" id="aboutWebsite" style="color:var(--accent)">picsmith.alresia.tech</a>
          <a href="#" id="aboutPrivacy" style="color:var(--accent)">Privacy policy</a>
          <a href="#" id="aboutSupport" style="color:var(--accent)">Support the project</a>
        </div>
      </div>`;
    showHelpDialog("About Picsmith", html);
    // These three links are injected as part of `html` above, not present in
    // editor.html — scoped lookups here rather than the global $() id helper,
    // which tools/check-refs.js statically verifies against editor.html and
    // would (rightly) flag as dangling references otherwise.
    const open = (url) => (e) => { e.preventDefault(); chrome.tabs.create({ url }); };
    const root = els.confirmText;
    root.querySelector("#aboutWebsite")?.addEventListener("click", open("https://picsmith.alresia.tech/"));
    root.querySelector("#aboutPrivacy")?.addEventListener("click", open("https://picsmith.alresia.tech/privacy.html"));
    root.querySelector("#aboutSupport")?.addEventListener("click", (e) => { e.preventDefault(); sendMessage({ type: "support:open" }); });
  }

  // ================================================================== image tools
  /**
   * The Image menu's toolbox.
   *
   * Each entry declares its controls and a `run(canvas, params)` that returns a
   * new canvas. That's all the dialog needs: it can build the UI, preview on a
   * proxy, and apply at full resolution without knowing what the tool does.
   *
   *   resizes : true  — the output changes dimensions, so live preview is off
   *                     (the layer would jump around while you drag a slider)
   *   instant : true  — no controls; runs the moment it's picked
   *   async   : true  — run() returns a promise (the learned cutout)
   */
  const IT = {
    // ---------------------------------------------------------- adjustments
    adjust: {
      name: "Adjustments",
      desc: "The full stack — exposure through tint. Drag any slider to see it live.",
      controls: [
        { k: "exposure", label: "Exposure", min: -100, max: 100, def: 0 },
        { k: "brightness", label: "Brightness", min: -100, max: 100, def: 0 },
        { k: "contrast", label: "Contrast", min: -100, max: 100, def: 0 },
        { k: "saturation", label: "Saturation", min: -100, max: 100, def: 0 },
        { k: "vibrance", label: "Vibrance", min: -100, max: 100, def: 0 },
        { k: "hue", label: "Hue", min: -180, max: 180, def: 0, unit: "°" },
        { k: "temperature", label: "Temperature", min: -100, max: 100, def: 0 },
        { k: "tint", label: "Tint", min: -100, max: 100, def: 0 },
      ],
      run: (c, p) => PFImageOps.adjust(c, p),
    },
    levels: {
      name: "Levels",
      desc: "Remap the tonal range. Raise Black and lower White to add punch; Gamma bends the midtones.",
      controls: [
        { k: "black", label: "Black point", min: 0, max: 254, def: 0 },
        { k: "white", label: "White point", min: 1, max: 255, def: 255 },
        { k: "gamma", label: "Gamma", min: 0.1, max: 3, def: 1, step: 0.05 },
      ],
      run: (c, p) => PFImageOps.levels(c, p),
    },
    autoEnhance: { name: "Auto enhance", instant: true, run: (c) => PFImageOps.autoEnhance(c) },
    autoContrast: { name: "Auto contrast", instant: true, run: (c) => PFImageOps.autoContrast(c) },
    autoWhite: { name: "Auto white balance", instant: true, run: (c) => PFImageOps.autoWhiteBalance(c) },

    // ---------------------------------------------------------------- colour
    grayscale: { name: "Black & white", instant: true, run: (c) => PFImageOps.grayscale(c) },
    invert: { name: "Invert colours", instant: true, run: (c) => PFImageOps.invert(c) },
    sepia: {
      name: "Sepia",
      controls: [{ k: "amount", label: "Amount", min: 0, max: 100, def: 80 }],
      run: (c, p) => PFImageOps.sepia(c, p.amount / 100),
    },
    posterize: {
      name: "Posterize",
      desc: "Flattens the image into a handful of tones — good for screen-print looks.",
      controls: [{ k: "steps", label: "Levels", min: 2, max: 32, def: 6 }],
      run: (c, p) => PFImageOps.posterize(c, p.steps),
    },
    threshold: {
      name: "Threshold",
      desc: "Everything becomes pure black or pure white at the cut-off you choose.",
      controls: [{ k: "level", label: "Cut-off", min: 0, max: 255, def: 128 }],
      run: (c, p) => PFImageOps.threshold(c, p.level),
    },
    duotone: {
      name: "Duotone",
      desc: "Maps shadows to one colour and highlights to another.",
      controls: [
        { k: "dark", label: "Shadows", type: "color", def: "#1b1b3a" },
        { k: "light", label: "Highlights", type: "color", def: "#f5c518" },
      ],
      run: (c, p) => PFImageOps.duotone(c, p.dark, p.light),
    },
    colorOverlay: {
      name: "Colour overlay",
      controls: [
        { k: "color", label: "Colour", type: "color", def: "#4f7dff" },
        { k: "alpha", label: "Strength", min: 0, max: 100, def: 35 },
        {
          k: "blend", label: "Blend", type: "select", def: "overlay",
          options: [["overlay", "Overlay"], ["multiply", "Multiply"], ["screen", "Screen"],
            ["color", "Colour"], ["soft-light", "Soft light"], ["hue", "Hue"]],
        },
      ],
      run: (c, p) => PFImageOps.colorOverlay(c, p.color, p.alpha / 100, p.blend),
    },
    replaceColor: {
      name: "Replace colour",
      desc: "Swap one colour for another everywhere it appears.",
      controls: [
        { k: "from", label: "Find", type: "color", def: "#ffffff" },
        { k: "to", label: "Replace with", type: "color", def: "#4f7dff" },
        { k: "tolerance", label: "Tolerance", min: 0, max: 150, def: 40 },
      ],
      run: (c, p) => PFImageOps.replaceColor(c, p.from, p.to, p.tolerance),
    },

    // ---------------------------------------------------------------- detail
    blur: {
      name: "Blur",
      controls: [{ k: "radius", label: "Radius", min: 0, max: 60, def: 6, step: 0.5 }],
      run: (c, p) => PFImageOps.blur(c, p.radius),
    },
    sharpen: {
      name: "Sharpen",
      controls: [{ k: "amount", label: "Amount", min: 0, max: 400, def: 100 }],
      run: (c, p) => PFImageOps.sharpen(c, p.amount / 100),
    },
    unsharp: {
      name: "Unsharp mask",
      desc: "Sharpens edges while leaving flat areas — the one to use on photos.",
      controls: [
        { k: "amount", label: "Amount", min: 0, max: 300, def: 80 },
        { k: "radius", label: "Radius", min: 0.5, max: 20, def: 2, step: 0.5 },
        { k: "threshold", label: "Threshold", min: 0, max: 60, def: 4 },
      ],
      run: (c, p) => PFImageOps.unsharpMask(c, p),
    },
    noise: {
      name: "Grain",
      controls: [
        { k: "amount", label: "Amount", min: 0, max: 100, def: 18 },
        { k: "mono", label: "Monochrome", type: "check", def: true },
      ],
      run: (c, p) => PFImageOps.noise(c, p.amount, p.mono),
    },
    pixelate: {
      name: "Pixelate",
      desc: "Also the quickest way to censor a face or a licence plate.",
      controls: [{ k: "size", label: "Block size", min: 2, max: 120, def: 12 }],
      run: (c, p) => PFImageOps.pixelate(c, p.size),
    },
    edges: { name: "Find edges", instant: true, run: (c) => PFImageOps.edgeDetect(c) },
    emboss: { name: "Emboss", instant: true, run: (c) => PFImageOps.emboss(c) },

    // ----------------------------------------------------------------- style
    vignette: {
      name: "Vignette",
      controls: [
        { k: "amount", label: "Strength", min: -100, max: 100, def: 45 },
        { k: "size", label: "Size", min: 0, max: 100, def: 55 },
        { k: "color", label: "Colour", type: "color", def: "#000000" },
      ],
      run: (c, p) => PFImageOps.vignette(c, p),
    },
    roundCorners: {
      name: "Round corners",
      controls: [{ k: "radius", label: "Radius", min: 0, max: 400, def: 32 }],
      run: (c, p) => PFImageOps.roundCorners(c, p.radius),
    },

    // ------------------------------------------------------------- transform
    flipH: { name: "Flip horizontal", instant: true, run: (c) => PFImageOps.flip(c, true) },
    flipV: { name: "Flip vertical", instant: true, run: (c) => PFImageOps.flip(c, false) },
    rotCW: { name: "Rotate 90° right", instant: true, resizes: true, run: (c) => PFImageOps.rotateQuarter(c, 1) },
    rotCCW: { name: "Rotate 90° left", instant: true, resizes: true, run: (c) => PFImageOps.rotateQuarter(c, 3) },
    rot180: { name: "Rotate 180°", instant: true, resizes: true, run: (c) => PFImageOps.rotateQuarter(c, 2) },
    straighten: {
      name: "Straighten",
      desc: "Free rotation. The layer grows so nothing gets clipped.",
      resizes: true,
      controls: [{ k: "degrees", label: "Angle", min: -45, max: 45, def: 0, step: 0.5, unit: "°" }],
      run: (c, p) => PFImageOps.rotateFree(c, p.degrees),
    },
    trim: {
      name: "Trim transparent edges",
      instant: true,
      resizes: true,
      run: (c) => PFImageOps.trimTransparent(c),
    },

    // ---------------------------------------------------------------- cutout
    removeBgAI: {
      name: "Remove background (AI)",
      desc: "Finds the subject with a neural network — no account, nothing uploaded, no prompt sent anywhere. The first use downloads a ~15MB engine once; every use after that is fully offline.",
      pro: true,
      async: true,
      controls: [{ k: "feather", label: "Edge softness", min: 0, max: 6, def: 1 }],
      run: (c, p, ctxObj) => PFCutout.removeBackgroundAI(c, {
        feather: p.feather,
        onProgress: ctxObj && ctxObj.onProgress,
      }),
    },
    removeBgEdges: {
      name: "Remove background (plain backdrop)",
      desc: "Floods in from the edges. Instant, and cleaner than the AI when the background is a solid or gently graded colour.",
      controls: [
        { k: "tolerance", label: "Tolerance", min: 1, max: 120, def: 32 },
        { k: "feather", label: "Edge softness", min: 0, max: 8, def: 2 },
      ],
      run: (c, p) => PFCutout.removeBackgroundEdges(c, p),
    },
    colorKey: {
      name: "Remove a colour",
      desc: "Deletes every pixel near the colour you pick — a green-screen key, essentially.",
      controls: [
        { k: "color", label: "Colour", type: "color", def: "#ffffff" },
        { k: "tolerance", label: "Tolerance", min: 1, max: 150, def: 40 },
        { k: "feather", label: "Edge softness", min: 0, max: 8, def: 1 },
      ],
      run: (c, p) => PFCutout.colorKey(c, p.color, p),
    },
  };

  // --- dialog state
  const itState = { id: null, tool: null, params: {}, original: null, proxy: null, layerId: null, busy: false, timer: null };

  /**
   * The pixels a tool operates on: the layer's OWN content, at its own size.
   *
   * Deliberately not the document-sized flatten. Beyond wasting work, that
   * surrounds a small image with a large transparent (i.e. black once you read
   * the pixels) border — which wrecks the background remover, since the model
   * then reads the whole photo as the subject sitting on a black field.
   * Working on the layer's own pixels also leaves its transform untouched, so
   * a rotated or scaled item stays exactly where it was.
   */
  function itSourceCanvas(layer) {
    const c = document.createElement("canvas");
    c.width = layer.content.width;
    c.height = layer.content.height;
    c.getContext("2d").drawImage(layer.content, 0, 0);
    return c;
  }

  /**
   * Swap in new pixels for a layer, keeping everything about where and how it
   * sits. A pixel operation turns text/shapes into pixels, so the layer is
   * converted to a raster — otherwise editing a shape property afterwards would
   * re-render the vector straight over the applied effect.
   */
  function itSetLayerPixels(layer, canvas) {
    layer.content = canvas;
    layer.fullCanvas = canvas.width === state.doc.width && canvas.height === state.doc.height;
    if (layer.type !== "raster") {
      layer.type = "raster";
      delete layer.shapeKind;
      delete layer.shapeRect;
      delete layer.text;
    }
  }

  /**
   * A smaller stand-in used for live preview. Running a heavy convolution on a
   * 4000px layer for every slider tick would crawl, and at normal zoom the
   * result is indistinguishable.
   */
  function itMakeProxy(src) {
    const MAX = 1100;
    const scale = Math.min(1, MAX / Math.max(src.width, src.height));
    if (scale === 1) return src;
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(src.width * scale));
    c.height = Math.max(1, Math.round(src.height * scale));
    const ctx = c.getContext("2d");
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return c;
  }

  function itSetStatus(text, tone = "") {
    if (!text) { els.itStatus.classList.add("hidden"); return; }
    els.itStatus.textContent = text;
    els.itStatus.className = "it-status" + (tone ? " " + tone : "");
  }

  /** A Pro upsell that goes straight to the License field, not a plain dead-end. */
  function showProUpsell(message) {
    els.confirmTitle.textContent = "Picsmith Pro";
    els.confirmText.textContent = message;
    els.confirmCancel.classList.remove("hidden");
    els.confirmCancel.textContent = "Not now";
    els.confirmOk.textContent = "Go to Settings";
    els.confirmOk.className = "btn primary";
    els.confirmOk.onclick = () => { closeModal("modalConfirm"); switchTab("settings"); };
    els.confirmCancel.onclick = () => { closeModal("modalConfirm"); els.confirmCancel.textContent = "Cancel"; };
    openModal("modalConfirm");
  }

  /** `presetParams` lets a caller (the AI Chat assistant) pre-fill a control
   *  instead of the tool's own default — e.g. Brightness opening already set
   *  to +30 because that's what was asked for. Still opens the normal dialog
   *  with a live preview; nothing applies until Apply is pressed (or, for an
   *  instant no-control tool, immediately — same as a manual click). */
  async function openImageTool(id, presetParams = null) {
    const tool = IT[id];
    if (!tool) return;
    const layer = selectedLayer();
    if (!layer || !layer.content) { toast("Select a layer first", true); return; }

    if (tool.pro && !(state.license && state.license.active)) {
      showProUpsell(
        "Remove background (AI) is a Picsmith Pro feature — it runs a neural network entirely on your " +
        "device (nothing uploaded), which costs us real hosting bandwidth regardless of who's asking. " +
        "Activate Pro in Settings to use it.",
      );
      return;
    }

    // One-time, explicit consent before the ~15MB engine is ever fetched —
    // never a silent background download.
    if (tool.pro && id === "removeBgAI") {
      let cached = false;
      try { cached = await PFCutout.isModelAvailable(); } catch { cached = false; }
      if (!cached) {
        const proceed = await new Promise((resolve) => {
          els.confirmTitle.textContent = "Download the offline background remover?";
          els.confirmText.textContent =
            "This is a one-time ~15MB download (the AI engine + model). After that, background removal " +
            "works completely offline, every time, with nothing ever uploaded.";
          els.confirmCancel.classList.remove("hidden");
          els.confirmCancel.textContent = "Cancel";
          els.confirmOk.textContent = "Download & continue";
          els.confirmOk.className = "btn primary";
          els.confirmOk.onclick = () => { closeModal("modalConfirm"); resolve(true); };
          els.confirmCancel.onclick = () => { closeModal("modalConfirm"); resolve(false); };
          openModal("modalConfirm");
        });
        if (!proceed) return;
      }
    }

    itState.id = id;
    itState.tool = tool;
    itState.layerId = layer.id;
    itState.busy = false;
    itState.original = itSourceCanvas(layer);
    itState.proxy = tool.resizes ? null : itMakeProxy(itState.original);
    itState.params = {};
    (tool.controls || []).forEach((c) => { itState.params[c.k] = c.def; });
    if (presetParams) Object.assign(itState.params, presetParams);

    els.itTitle.textContent = tool.name;
    els.itDesc.textContent = tool.desc || "";
    els.itDesc.classList.toggle("hidden", !tool.desc);
    itSetStatus("");
    els.itReset.classList.toggle("hidden", !(tool.controls || []).length);
    itBuildControls(tool);

    // An instant tool with no knobs has nothing to preview — just run it.
    if (tool.instant && !(tool.controls || []).length) {
      itApply();
      return;
    }
    openModal("modalImageTool");
    itPreview();
  }

  function itBuildControls(tool) {
    const host = els.itControls;
    host.innerHTML = "";
    (tool.controls || []).forEach((c) => {
      const row = document.createElement("div");
      row.className = "it-row";
      const val = itState.params[c.k];

      if (c.type === "color") {
        row.innerHTML = `<label>${escapeHtml(c.label)}</label>
          <input type="color" data-k="${c.k}" value="${escapeHtml(String(val))}">`;
      } else if (c.type === "select") {
        row.innerHTML = `<label>${escapeHtml(c.label)}</label>
          <select data-k="${c.k}">${c.options.map(([v, n]) =>
            `<option value="${escapeHtml(v)}"${v === val ? " selected" : ""}>${escapeHtml(n)}</option>`).join("")}</select>`;
      } else if (c.type === "check") {
        row.innerHTML = `<label class="it-check"><input type="checkbox" data-k="${c.k}"${val ? " checked" : ""}> ${escapeHtml(c.label)}</label>`;
      } else {
        row.innerHTML = `<label>${escapeHtml(c.label)}</label>
          <input type="range" data-k="${c.k}" min="${c.min}" max="${c.max}" step="${c.step || 1}" value="${val}">
          <span class="it-val">${val}${c.unit || ""}</span>`;
      }
      host.appendChild(row);

      const input = row.querySelector("[data-k]");
      const readout = row.querySelector(".it-val");
      const onChange = () => {
        let v;
        if (c.type === "check") v = input.checked;
        else if (c.type === "color" || c.type === "select") v = input.value;
        else v = parseFloat(input.value);
        itState.params[c.k] = v;
        if (readout) readout.textContent = v + (c.unit || "");
        if (input.type === "range") sliderFill(input);
        itSchedulePreview();
      };
      input.addEventListener("input", onChange);
      input.addEventListener("change", onChange);
      if (input.type === "range") sliderFill(input);
    });
  }

  /** Debounce preview work so dragging a slider stays smooth. */
  function itSchedulePreview() {
    clearTimeout(itState.timer);
    itState.timer = setTimeout(itPreview, 90);
  }

  /**
   * Render the tool onto the layer so the canvas itself is the preview.
   * The result is drawn back at the original dimensions, so the layer's
   * transform (and therefore its on-canvas position) never shifts.
   */
  function itPreview() {
    const tool = itState.tool;
    if (!tool || tool.async || tool.resizes || itState.busy) return;
    const layer = layerById(itState.layerId);
    if (!layer) return;
    try {
      const out = tool.run(itState.proxy, itState.params, {});
      if (!out) return;
      // Draw the proxy result back at the original size so the layer's
      // dimensions — and therefore its on-canvas footprint — never change
      // while a slider is being dragged.
      const shown = document.createElement("canvas");
      shown.width = itState.original.width;
      shown.height = itState.original.height;
      const ctx = shown.getContext("2d");
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(out, 0, 0, shown.width, shown.height);
      layer.content = shown;
      render();
    } catch (err) {
      console.error("Picsmith preview failed:", err);
      itSetStatus("Preview failed — applying may still work.", "warn");
    }
  }

  /** Put the layer's pixels back the way they were before the dialog opened. */
  function itRestore() {
    const layer = layerById(itState.layerId);
    if (layer && itState.original) {
      layer.content = itState.original;
      render();
    }
  }

  function itCancel() {
    clearTimeout(itState.timer);
    if (itState.busy) return;
    itRestore();
    closeModal("modalImageTool");
    itState.tool = null;
  }

  function itReset() {
    const tool = itState.tool;
    if (!tool) return;
    (tool.controls || []).forEach((c) => { itState.params[c.k] = c.def; });
    itBuildControls(tool);
    itPreview();
  }

  async function itApply() {
    const tool = itState.tool;
    if (!tool || itState.busy) return;
    const layer = layerById(itState.layerId);
    if (!layer) { closeModal("modalImageTool"); return; }

    // Always compute the real result from the untouched original at full size —
    // never from whatever low-res proxy the preview happened to leave behind.
    itRestore();

    let out;
    try {
      if (tool.async) {
        itState.busy = true;
        els.itApply.disabled = true;
        const STAGES = {
          loading: "Starting the engine…",
          running: "Finding the subject…",
          compositing: "Cutting it out…",
        };
        itSetStatus("Starting…");
        out = await tool.run(itState.original, itState.params, {
          onProgress: (stage, pct, label) => {
            if (stage === "downloading") {
              const what = label === "runtime" ? "the AI engine" : label === "model" ? "the model" : "the AI pack";
              itSetStatus(pct != null ? `Downloading ${what}… ${pct}%` : `Downloading ${what}…`);
            } else {
              itSetStatus(STAGES[stage] || stage);
            }
          },
        });
      } else {
        out = tool.run(itState.original, itState.params, {});
      }
    } catch (err) {
      console.error("Picsmith image tool failed:", err);
      itState.busy = false;
      els.itApply.disabled = false;
      itSetStatus((err && err.message) || "That didn't work.", "warn");
      return;
    }

    itState.busy = false;
    els.itApply.disabled = false;

    if (!out) {
      // trimTransparent returns null when there's nothing to remove.
      itSetStatus("Nothing to change here.", "warn");
      if (tool.instant) { closeModal("modalImageTool"); toast("Nothing to change", true); }
      return;
    }

    pushHistory();
    // The transform is preserved in every case: the layer's centre, rotation,
    // scale and effects stay exactly as they were, only the pixels change.
    itSetLayerPixels(layer, out);
    render();
    renderLayersPanel();
    renderInspector();
    markDirty();

    closeModal("modalImageTool");
    itState.tool = null;
    toast(tool.name + " applied");
  }

  function bindImageToolModal() {
    els.itApply.addEventListener("click", itApply);
    els.itCancel.addEventListener("click", itCancel);
    els.itReset.addEventListener("click", itReset);
    // The X and the backdrop must restore too, not just hide the dialog.
    els.modalImageTool.addEventListener("click", (e) => {
      if (e.target === els.modalImageTool || e.target.closest("[data-close='modalImageTool']")) {
        e.preventDefault();
        itCancel();
      }
    });
  }

  // ================================================================== menu bar
  const MENUS = [
    { label: "File", items: [
      { label: "New…", action: () => openModal("modalNew") },
      { label: "Save", kbd: "Ctrl+S", action: async () => { await saveProject(); toast("Project saved"); } },
      { label: "Export…", kbd: "Ctrl+E", action: openExport },
      { sep: true },
      { label: "Download .pfproj", action: () => els.btnDownloadProject.click() },
    ] },
    { label: "Edit", items: [
      { label: "Undo", kbd: "Ctrl+Z", action: undo },
      { label: "Redo", kbd: "Ctrl+Shift+Z", action: redo },
      { sep: true },
      { label: "Cut", kbd: "Ctrl+X", action: () => copySelected({ cut: true }) },
      { label: "Copy", kbd: "Ctrl+C", action: () => copySelected() },
      { label: "Paste", kbd: "Ctrl+V", action: () => pasteClipboard() },
      { label: "Duplicate", kbd: "Ctrl+D", action: duplicateLayer },
      { sep: true },
      { label: "Copy as image", kbd: "Ctrl+Shift+C", action: copyImageToSystem },
      { sep: true },
      { label: "Delete", kbd: "Del", action: deleteSelected },
    ] },
    { label: "Image", items: [
      { label: "Adjustments…", kbd: "Ctrl+M", tool: "adjust" },
      { label: "Levels…", tool: "levels" },
      { label: "Auto", sub: [
        { label: "Auto enhance", tool: "autoEnhance" },
        { label: "Auto contrast", tool: "autoContrast" },
        { label: "Auto white balance", tool: "autoWhite" },
      ] },
      { sep: true },
      { label: "Remove background (AI)", kbd: "Ctrl+B", tool: "removeBgAI" },
      { label: "Cut out", sub: [
        { label: "Remove plain backdrop…", tool: "removeBgEdges" },
        { label: "Remove a colour…", tool: "colorKey" },
        { label: "Trim transparent edges", tool: "trim" },
      ] },
      { sep: true },
      { label: "Colour", sub: [
        { label: "Black & white", tool: "grayscale" },
        { label: "Sepia…", tool: "sepia" },
        { label: "Invert colours", tool: "invert" },
        { label: "Duotone…", tool: "duotone" },
        { label: "Colour overlay…", tool: "colorOverlay" },
        { label: "Replace colour…", tool: "replaceColor" },
        { label: "Posterize…", tool: "posterize" },
        { label: "Threshold…", tool: "threshold" },
      ] },
      { label: "Detail", sub: [
        { label: "Blur…", tool: "blur" },
        { label: "Sharpen…", tool: "sharpen" },
        { label: "Unsharp mask…", tool: "unsharp" },
        { label: "Grain…", tool: "noise" },
        { label: "Pixelate…", tool: "pixelate" },
        { label: "Find edges", tool: "edges" },
        { label: "Emboss", tool: "emboss" },
      ] },
      { label: "Style", sub: [
        { label: "Vignette…", tool: "vignette" },
        { label: "Round corners…", tool: "roundCorners" },
      ] },
      { label: "Transform", sub: [
        { label: "Flip horizontal", tool: "flipH" },
        { label: "Flip vertical", tool: "flipV" },
        { label: "Rotate 90° right", tool: "rotCW" },
        { label: "Rotate 90° left", tool: "rotCCW" },
        { label: "Rotate 180°", tool: "rot180" },
        { label: "Straighten…", tool: "straighten" },
      ] },
      { sep: true },
      { label: "Filter presets", action: () => switchTab("adjust") },
      { label: "Resize canvas / image…", action: openResize },
    ] },
    { label: "Layer", items: [
      { label: "Add image", action: () => els.btnAddImage.click() },
      { label: "Add text", action: () => els.btnAddText.click() },
      { label: "Add shape", action: () => els.btnAddShape.click() },
      { sep: true },
      { label: "Duplicate", kbd: "Ctrl+D", action: duplicateLayer },
      { label: "Lock / unlock", kbd: "Ctrl+L", action: toggleLockSelected },
      { label: "Delete", action: deleteSelected },
      { sep: true },
      { label: "Bring to front", action: () => moveToEdge(state.doc.layers.length - 1) },
      { label: "Send to back", action: () => moveToEdge(0) },
      { sep: true },
      { label: "Flatten design", action: flattenAll },
    ] },
    { label: "Select", items: [
      { label: "Select top layer", kbd: "Ctrl+A", action: selectTopLayer },
      { label: "Deselect", action: () => selectLayer(null) },
      { sep: true },
      { label: "Zoom to selection", action: zoomToSelection },
    ] },
    { label: "View", items: [
      { label: "Zoom in", kbd: "+", action: () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2) },
      { label: "Zoom out", kbd: "−", action: () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2) },
      { label: "Zoom to fit", kbd: "0", action: zoomFit },
      { label: "Zoom to 100%", kbd: "1", action: () => { state.zoom = 1; applyZoom(); } },
      { sep: true },
      { label: "Toggle grid", kbd: "Ctrl+G", action: toggleGrid },
      { label: "Toggle smart guides", action: toggleSnap },
    ] },
    { label: "Help", items: [
      { label: "Keyboard shortcuts", action: showShortcutsHelp },
      { label: "About Picsmith", action: showAboutDialog },
      { sep: true },
      { label: "Check for updates", action: () => { switchTab("settings"); runUpdateCheck({ force: true }); } },
      { label: "Buy me a coffee ☕", action: () => sendMessage({ type: "support:open" }) },
      { label: "Picsmith website", action: () => chrome.tabs.create({ url: "https://picsmith.alresia.tech/" }) },
    ] },
  ];

  function closeAllMenus() {
    document.querySelectorAll("#menuBar .menu-item.open").forEach((m) => m.classList.remove("open"));
    document.querySelectorAll("#menuBar .menu-sub.open").forEach((m) => m.classList.remove("open"));
  }

  /** Does this entry need a pixel layer selected before it can do anything? */
  const menuNeedsLayer = (it) => !!it.tool;

  /** Build one dropdown entry (recursing for submenus). */
  function buildMenuEntry(it, dd) {
    if (it.sep) {
      const s = document.createElement("div");
      s.className = "menu-sep";
      dd.appendChild(s);
      return;
    }

    if (it.sub) {
      const wrap = document.createElement("div");
      wrap.className = "menu-sub";
      const b = document.createElement("button");
      b.className = "menu-dd-item has-sub";
      b.innerHTML = `<span>${escapeHtml(it.label)}</span><span class="dd-arrow">${PFIcons.svg("chevron")}</span>`;
      wrap.appendChild(b);
      const panel = document.createElement("div");
      panel.className = "menu-dd menu-dd-sub";
      it.sub.forEach((s) => buildMenuEntry(s, panel));
      wrap.appendChild(panel);
      // Click also opens it, so the menu is usable without hover (touch, and
      // anyone who moves the pointer diagonally off the row).
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        const open = wrap.classList.contains("open");
        dd.querySelectorAll(".menu-sub.open").forEach((o) => o.classList.remove("open"));
        if (!open) wrap.classList.add("open");
      });
      dd.appendChild(wrap);
      return;
    }

    const toolDef = it.tool ? IT[it.tool] : null;
    const b = document.createElement("button");
    b.className = "menu-dd-item";
    b.innerHTML = `<span>${escapeHtml(it.label)}</span>${
      toolDef && toolDef.pro ? `<span class="dd-pro">PRO</span>` : ""
    }${it.kbd ? `<span class="dd-kbd">${escapeHtml(it.kbd)}</span>` : ""}`;
    if (menuNeedsLayer(it)) b.dataset.needsLayer = "1";
    b.addEventListener("click", () => {
      if (b.disabled) return;
      closeAllMenus();
      if (it.tool) openImageTool(it.tool);
      else if (it.action) it.action();
    });
    dd.appendChild(b);
  }

  /** Grey out anything that needs a selected layer when there isn't one. */
  function syncMenuEnabled() {
    const has = !!(selectedLayer() && selectedLayer().content);
    els.menuBar.querySelectorAll("[data-needs-layer]").forEach((b) => {
      b.disabled = !has;
      b.title = has ? "" : "Select an image, text or shape layer first";
    });
  }

  function bindMenuBar() {
    els.menuBar.innerHTML = "";
    MENUS.forEach((menu) => {
      const item = document.createElement("div");
      item.className = "menu-item";
      const label = document.createElement("span");
      label.textContent = menu.label;
      item.appendChild(label);
      const dd = document.createElement("div");
      dd.className = "menu-dd";
      menu.items.forEach((it) => buildMenuEntry(it, dd));
      item.appendChild(dd);
      item.addEventListener("click", (e) => {
        // Clicks inside the dropdown are handled by their own buttons.
        if (e.target !== item && e.target !== label) return;
        e.stopPropagation();
        const wasOpen = item.classList.contains("open");
        closeAllMenus();
        if (!wasOpen) { item.classList.add("open"); syncMenuEnabled(); }
      });
      els.menuBar.appendChild(item);
    });
    document.addEventListener("click", closeAllMenus);
  }

  // ================================================================== right-dock resizer
  function bindDockResizer() {
    document.querySelectorAll(".dock-resizer").forEach((handle) => {
      handle.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        handle.classList.add("active");
        handle.setPointerCapture(e.pointerId);
        const startX = e.clientX;
        const startW = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--rp-w")) || 300;
        const onMove = (ev) => {
          // The handle sits on the dock's left edge, so dragging left widens it.
          const w = clamp(startW + (startX - ev.clientX), 220, 520);
          document.documentElement.style.setProperty("--rp-w", `${w}px`);
        };
        const onUp = () => {
          handle.classList.remove("active");
          window.removeEventListener("pointermove", onMove);
          window.removeEventListener("pointerup", onUp);
          const w = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--rp-w"));
          sendMessage({ type: "settings:set", key: "rightDockWidth", value: w });
        };
        window.addEventListener("pointermove", onMove);
        window.addEventListener("pointerup", onUp);
      });
    });
  }

  // ================================================================== right-click context menu
  function closeContextMenu() {
    els.ctxMenu.classList.add("hidden");
    els.ctxMenu.innerHTML = "";
  }

  function buildCtxItems(items) {
    els.ctxMenu.innerHTML = "";
    items.forEach((it) => {
      if (it.sep) {
        const s = document.createElement("div");
        s.className = "ctx-sep";
        els.ctxMenu.appendChild(s);
        return;
      }
      const b = document.createElement("button");
      b.className = "ctx-item" + (it.danger ? " danger" : "");
      b.disabled = !!it.disabled;
      b.innerHTML = `${PFIcons.svg(it.icon)}<span>${escapeHtml(it.label)}</span>${it.kbd ? `<span class="ctx-kbd">${escapeHtml(it.kbd)}</span>` : ""}`;
      if (!it.disabled) b.addEventListener("click", () => { closeContextMenu(); it.action(); });
      els.ctxMenu.appendChild(b);
    });
  }

  function positionCtxMenu(x, y) {
    els.ctxMenu.classList.remove("hidden");
    const r = els.ctxMenu.getBoundingClientRect();
    els.ctxMenu.style.left = Math.min(x, window.innerWidth - r.width - 8) + "px";
    els.ctxMenu.style.top = Math.min(y, window.innerHeight - r.height - 8) + "px";
  }

  const hasClipboard = () => !!state.clipboard;

  function layerContextItems(layer) {
    return [
      { icon: "cut", label: "Cut", kbd: "Ctrl+X", action: () => copySelected({ cut: true }) },
      { icon: "copy", label: "Copy", kbd: "Ctrl+C", action: () => copySelected() },
      { icon: "clipboard", label: "Paste", kbd: "Ctrl+V", disabled: !hasClipboard(), action: () => pasteClipboard() },
      { icon: "duplicate", label: "Duplicate", kbd: "Ctrl+D", action: duplicateLayer },
      { sep: true },
      { icon: "edit", label: "Rename…", action: () => { selectLayer(layer.id); startRename(); } },
      { icon: layer.locked ? "unlock" : "lock", label: layer.locked ? "Unlock" : "Lock", kbd: "Ctrl+L", action: toggleLockSelected },
      { icon: "trash", label: "Delete", kbd: "Del", danger: true, action: () => removeLayer(layer.id) },
      { sep: true },
      { icon: "arrange-front", label: "Bring to front", action: () => moveToEdge(state.doc.layers.length - 1) },
      { icon: "arrange-forward", label: "Bring forward", action: () => moveLayer(1) },
      { icon: "arrange-back", label: "Send backward", action: () => moveLayer(-1) },
      { icon: "arrange-toback", label: "Send to back", action: () => moveToEdge(0) },
    ];
  }

  /** Right-clicking empty canvas still offers paste. */
  function emptyCanvasContextItems(pt) {
    return [
      { icon: "clipboard", label: "Paste here", kbd: "Ctrl+V", disabled: !hasClipboard(), action: () => pasteClipboard(pt) },
      { icon: "image", label: "Add image…", action: () => openImagePicker(pt) },
      { icon: "text", label: "Add text", action: () => addElementAt("text", pt) },
      { sep: true },
      { icon: "layers", label: "Select top layer", kbd: "Ctrl+A", action: selectTopLayer },
    ];
  }

  function openCanvasContextMenu(x, y, layer, pt) {
    buildCtxItems(layer ? layerContextItems(layer) : emptyCanvasContextItems(pt));
    positionCtxMenu(x, y);
  }

  function openLayerContextMenu(x, y, layer) {
    buildCtxItems(layerContextItems(layer));
    positionCtxMenu(x, y);
  }

  function bindContextMenu() {
    document.addEventListener("pointerdown", (e) => {
      if (!els.ctxMenu.contains(e.target)) closeContextMenu();
    });
    window.addEventListener("blur", closeContextMenu);
    window.addEventListener("resize", closeContextMenu);
  }

  function renderTemplates() {
    els.templateGrid.innerHTML = "";
    PFProject.TEMPLATES.forEach((t) => {
      const card = document.createElement("button");
      card.className = "template-card";
      const ar = t.w / t.h;
      const boxW = ar >= 1 ? 26 : Math.round(26 * ar);
      const boxH = ar >= 1 ? Math.round(26 / ar) : 26;
      card.innerHTML = `<span class="t-icon" style="width:${boxW}px;height:${boxH}px"></span><span class="t-name">${t.name}</span><span class="t-hint">${t.hint}</span>`;
      card.addEventListener("click", () => createFromTemplate(t.id));
      els.templateGrid.appendChild(card);
    });
  }

  function openExport() {
    const pro = !!(state.license && state.license.active);
    const maxDim = pro ? 0 : PFProject.FREE_MAX_DIM;
    const long = Math.max(state.doc.width, state.doc.height);
    const scale = maxDim && long > maxDim ? maxDim / long : 1;
    const w = Math.round(state.doc.width * scale);
    const h = Math.round(state.doc.height * scale);
    els.expSizeNote.className = "exp-note " + (pro ? "pro" : "free");
    els.expSizeNote.textContent = pro
      ? "✓ Full resolution export (Pro)."
      : `Free exports are capped at ${PFProject.FREE_MAX_DIM}px — activate Pro for full resolution.`;
    els.expDims.textContent = `Will export ${w} × ${h}px`;
    openModal("modalExport");
  }

  function doExport() {
    const pro = !!(state.license && state.license.active);
    const maxDim = pro ? 0 : PFProject.FREE_MAX_DIM;
    const quality = parseFloat(els.expQuality.value) / 100;
    const flat = PFEngine.flattenDoc(state.doc);
    PFProject.exportBlob(flat, { format: state.exportFormat, quality, maxDim }).then((blob) => {
      PFProject.downloadBlob(blob, `${state.doc.name.replace(/[^\w\- ]+/g, "").trim() || "design"}.${state.exportFormat}`);
      closeModal("modalExport");
      toast("Exported");
    }).catch((err) => toast(err.message || "Export failed", true));
  }

  function openResize() {
    els.resW.value = state.doc.width;
    els.resH.value = state.doc.height;
    openModal("modalResize");
  }

  function applyResize() {
    const w = clamp(parseInt(els.resW.value, 10) || 0, 16, 8000);
    const h = clamp(parseInt(els.resH.value, 10) || 0, 16, 8000);
    const mode = document.querySelector('input[name="resizeMode"]:checked').value;
    const doc = state.doc;
    pushHistory();
    if (mode === "canvas") {
      for (const layer of doc.layers) {
        if (layer.fullCanvas && layer.content) {
          const c = document.createElement("canvas");
          c.width = w;
          c.height = h;
          c.getContext("2d").drawImage(layer.content, 0, 0);
          layer.content = c;
          layer.transform = { x: w / 2, y: h / 2, rotation: 0, scaleX: 1, scaleY: 1 };
        }
      }
    } else {
      const layers = [];
      for (const layer of doc.layers) {
        // Force-flatten hidden layers too (drawLayer skips them by default).
        const full = PFEngine.flattenLayerToFullCanvas(doc, layer, true);
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        c.getContext("2d").drawImage(full.content, 0, 0, w, h);
        const scaled = PFEngine.makeFullCanvasLayer(c, { name: layer.name });
        scaled.visible = layer.visible; // opacity was baked during flatten
        layers.push(scaled);
      }
      doc.layers = layers;
    }
    doc.width = w;
    doc.height = h;
    closeModal("modalResize");
    setupCanvas(false);
    render();
    renderLayersPanel();
    markDirty();
    toast(`Resized to ${w} × ${h}`);
  }

  // ================================================================== bindings
  function bindTopbar() {
    els.docName.addEventListener("input", () => {
      if (!state.doc) return;
      state.doc.name = els.docName.value || "Untitled design";
      clearTimeout(state.nameTimer);
      state.nameTimer = setTimeout(markDirty, 400);
    });
    els.undoBtn.addEventListener("click", undo);
    els.redoBtn.addEventListener("click", redo);
    els.zoomIn.addEventListener("click", () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2));
    els.zoomOut.addEventListener("click", () => zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2));
    els.zoomLabel.addEventListener("click", () => { state.zoom = 1; applyZoom(); });
    els.zoomFit.addEventListener("click", zoomFit);
    els.newBtn.addEventListener("click", () => openModal("modalNew"));
    els.saveBtn.addEventListener("click", async () => { await saveProject(); toast("Project saved"); });
    els.exportBtn.addEventListener("click", openExport);
    els.proBadge.addEventListener("click", () => switchTab("ai"));
  }

  function switchTab(tab) {
    state.rpTab = tab;
    renderRightDock();
    if (state.layersTabActive) renderLayersPanel();
  }

  /**
   * Single source of truth for what's visible in the right dock. The
   * inspector (item properties) and the tabbed panel (Elements/Adjust/
   * Layers/AI/Settings) share one dock slot, but which one wins is now
   * decided by the active TAB, not by "is something selected" — otherwise
   * selecting an item makes every other tab unreachable (its tab strip
   * lives inside #rightPanel, which gets hidden), and there's no way to
   * e.g. open Settings or run Adjust on the selected item without
   * deselecting it first. Only the "elements" tab ever shows the
   * inspector, and only when something is actually selected; every other
   * tab always shows its own panel, selection or not.
   */
  function renderRightDock() {
    const tab = state.rpTab || "elements";
    const l = selectedLayer();
    const showInspector = tab === "elements" && !!l;
    document.querySelectorAll(".rp-tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
    els.inspector.classList.toggle("hidden", !showInspector);
    els.rightPanel.classList.toggle("hidden", showInspector);
    if (!showInspector) {
      document.querySelectorAll(".rp-panel").forEach((p) => p.classList.toggle("active", p.id === "panel-" + tab));
    }
    state.layersTabActive = tab === "layers";
  }

  function bindPanels() {
    document.querySelectorAll(".rp-tab").forEach((b) => b.addEventListener("click", () => switchTab(b.dataset.tab)));

    const fxMap = { fxBrightness: "brightness", fxContrast: "contrast", fxSaturate: "saturate", fxHue: "hue", fxBlur: "blur", fxSharpen: "sharpen" };
    Object.entries(fxMap).forEach(([id, key]) => {
      const slider = els[id];
      const valEl = els["v" + key.charAt(0).toUpperCase() + key.slice(1)];
      slider.addEventListener("input", () => {
        state.fx[key] = parseFloat(slider.value);
        sliderFill(slider);
        valEl.textContent = slider.value;
      });
      sliderFill(slider);
    });

    els.applyFxBtn.addEventListener("click", applyAdjustments);
    els.resetFxBtn.addEventListener("click", resetFxSliders);
    els.resizeBtn.addEventListener("click", openResize);

    els.btnAddImage.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => { if (input.files[0]) addImageFile(input.files[0]); };
      input.click();
    });
    els.btnAddText.addEventListener("click", () => {
      const layer = PFProject.newLayer("text", {
        transform: { x: state.doc.width / 2, y: state.doc.height / 2, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
      openTextEditor(layer);
    });
    els.btnAddShape.addEventListener("click", () => { setTool("shape"); toast("Drag on the canvas to draw a shape"); });
    els.btnAddBrush.addEventListener("click", () => { setTool("brush"); });

    els.layerOpacity.addEventListener("input", () => {
      const layer = selectedLayer();
      if (!layer) return;
      layer.opacity = parseFloat(els.layerOpacity.value) / 100;
      els.layerOpacityVal.textContent = els.layerOpacity.value;
      render();
    });
    els.layerOpacity.addEventListener("change", () => { pushHistory(); markDirty(); });
    els.layerUp.addEventListener("click", () => moveLayer(1));
    els.layerDown.addEventListener("click", () => moveLayer(-1));
    els.layerDup.addEventListener("click", duplicateLayer);
    els.layerDel.addEventListener("click", deleteSelected);

    els.aiGo.addEventListener("click", sendChatMessage);
    els.aiPrompt.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
    });
    els.aiPrompt.addEventListener("input", autoSizeComposer);
    els.aiChatNew.addEventListener("click", () => {
      if (!(state.doc.aiChat || []).length) return;
      confirmDialog("Clear this project's AI Chat history? This can't be undone.", () => {
        state.doc.aiChat = [];
        markDirty();
        renderAIChatThread();
      });
    });
    els.aiByokDismiss.addEventListener("click", () => {
      state.settings.aiByokDismissed = true;
      sendMessage({ type: "settings:set", key: "aiByokDismissed", value: true });
      renderAIEngineStatus();
    });
  }

  function bindModals() {
    document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => closeModal(b.dataset.close)));
    document.querySelectorAll(".modal-back").forEach((m) => m.addEventListener("click", (e) => {
      if (e.target === m) m.classList.add("hidden");
    }));
    bindDraggableModals();
    els.newCreateBtn.addEventListener("click", () => {
      const w = clamp(parseInt(els.newW.value, 10) || 1080, 16, 8000);
      const h = clamp(parseInt(els.newH.value, 10) || 1080, 16, 8000);
      createFromTemplate("custom", { name: `Design ${w}×${h}`, width: w, height: h });
    });
    els.fmtSeg.querySelectorAll(".seg-btn").forEach((b) => b.addEventListener("click", () => {
      state.exportFormat = b.dataset.fmt;
      els.fmtSeg.querySelectorAll(".seg-btn").forEach((x) => x.classList.toggle("active", x === b));
    }));
    els.expQuality.addEventListener("input", () => {
      els.expQualityVal.textContent = els.expQuality.value;
      sliderFill(els.expQuality);
    });
    sliderFill(els.expQuality);
    els.expBtn.addEventListener("click", doExport);
    els.resizeApply.addEventListener("click", applyResize);
  }

  function bindDnD() {
    els.workspace.addEventListener("dragover", (e) => e.preventDefault());
    els.workspace.addEventListener("drop", (e) => {
      e.preventDefault();
      const file = Array.from(e.dataTransfer.files || []).find((f) => f.type.startsWith("image/"));
      if (file) addImageFile(file);
    });
    document.addEventListener("paste", (e) => {
      const t = e.target;
      // Let text fields do their own thing.
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      const items = (e.clipboardData && e.clipboardData.items) || [];
      for (const item of items) {
        if (item.type.startsWith("image/")) {
          const file = item.getAsFile();
          if (file) {
            e.preventDefault();
            addImageFile(file, state.lastCanvasPt || null);
            return;
          }
        }
      }
      // No image on the OS clipboard. The Ctrl+V keydown handler already
      // pastes an internally-copied layer, so only act if it didn't.
      if (state.suppressPasteEvent) return;
      e.preventDefault();
      pasteClipboard();
    });
  }

  function addImageFile(file, center) {
    if (!file || !file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const layer = PFEngine.createRasterLayer(state.doc, img);
      if (center) {
        layer.transform.x = center.x;
        layer.transform.y = center.y;
      }
      pushHistory();
      addLayer(layer, { select: true });
      render();
      renderLayersPanel();
      toast("Image added");
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      toast("Could not load that image", true);
    };
    img.src = url;
  }

  // ================================================================== elements panel + drag-to-canvas
  function renderElementsPanel() {
    const grid = $("elShapeGrid");
    if (!grid) return;
    grid.innerHTML = "";
    PFTools.SHAPE_KINDS.forEach(([k, icon, name]) => {
      const chip = document.createElement("button");
      chip.className = "el-chip";
      chip.dataset.el = `shape:${k}`;
      chip.draggable = false;
      chip.dataset.tip = `${name}|Drag onto the canvas to drop a ${name.toLowerCase()} — or click to add it in the centre`;
      chip.innerHTML = `<span class="el-ico">${icon}</span><span class="el-name">${name}</span>`;
      grid.appendChild(chip);
    });
  }

  /** Add an element from the Elements panel — at a doc point, or centred on click. */
  function addElementAt(kind, pt) {
    if (kind === "image") {
      openImagePicker(pt);
      return;
    }
    if (kind === "text") {
      // The popover pushes history after the layer exists, so don't push twice.
      const d = state.toolOptions.textDefaults;
      const layer = PFProject.newLayer("text", {
        text: "Your text",
        fontFamily: d.fontFamily, fontSize: d.fontSize, fontWeight: d.fontWeight, fontStyle: d.fontStyle,
        color: d.color, align: d.align, letterSpacing: d.letterSpacing, upper: d.upper,
        transform: { x: pt.x, y: pt.y, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
      openTextEditor(layer, { push: false });
    } else if (kind.startsWith("shape:")) {
      pushHistory();
      const o = state.toolOptions;
      const shapeKind = kind.slice(6);
      const s = Math.max(48, Math.min(state.doc.width, state.doc.height) * 0.22);
      const isLine = shapeKind === "line" || shapeKind === "arrow";
      const layer = PFProject.newLayer("shape", {
        name: shapeKind,
        shapeKind,
        shapeRect: { x: 0, y: 0, w: s, h: isLine ? Math.max(2, s * 0.6) : s },
        radius: o.radius,
        points: o.points,
        fill: o.fill,
        stroke: o.stroke,
        strokeWidth: isLine ? Math.max(3, o.strokeWidth) : o.strokeWidth,
        transform: { x: pt.x, y: pt.y, rotation: 0, scaleX: 1, scaleY: 1 },
      });
      PFEngine.renderContent(layer);
      addLayer(layer, { select: true });
    }
  }

  function openImagePicker(center) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => { if (input.files[0]) addImageFile(input.files[0], center); };
    input.click();
  }

  /** Pointer-based drag from an Elements chip onto the canvas, with a visible flow. */
  function initItemDrag() {
    let drag = null;

    function buildGhost(kind) {
      const g = document.createElement("div");
      g.className = "drag-ghost";
      if (kind === "text") {
        g.innerHTML = '<span class="dg-ico dg-text">T</span>';
      } else if (kind === "image") {
        g.innerHTML = `<span class="dg-ico">${PFIcons.svg("image")}</span>`;
      } else {
        const c = document.createElement("canvas");
        c.width = 40;
        c.height = 40;
        const ctx = c.getContext("2d");
        const k = kind.slice(6);
        PFTools.drawShapePath(ctx, k, 5, 5, 30, 30, { radius: 8, points: 5 });
        if (k !== "line" && k !== "arrow") { ctx.fillStyle = "#fff"; ctx.fill(); }
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.stroke();
        g.appendChild(c);
      }
      return g;
    }

    function moveDrag(e) {
      if (!drag) return;
      if (Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) > 5) drag.moved = true;
      drag.ghost.style.left = e.clientX + "px";
      drag.ghost.style.top = e.clientY + "px";
      const r = els.stage.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      els.stage.classList.toggle("drop-target", inside);
      const wr = els.workspace.getBoundingClientRect();
      drag.badge.style.left = e.clientX - wr.left + "px";
      drag.badge.style.top = e.clientY - wr.top + "px";
      drag.badge.classList.toggle("off", !inside);
    }

    function endDrag(e, cancelled) {
      if (!drag) return;
      const wasClick = !drag.moved && !cancelled;
      const kind = drag.kind;
      drag.ghost.remove();
      drag.badge.remove();
      drag = null;
      document.body.classList.remove("is-item-drag");
      els.stage.classList.remove("drop-target");
      state.itemDragActive = false;
      if (cancelled) return;
      const r = els.stage.getBoundingClientRect();
      const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      if (inside) {
        addElementAt(kind, docPoint(e));
      } else if (wasClick) {
        addElementAt(kind, { x: state.doc.width / 2, y: state.doc.height / 2 });
      }
    }

    document.addEventListener("pointerdown", (e) => {
      const chip = e.target.closest ? e.target.closest("[data-el]") : null;
      if (!chip || e.button !== 0) return;
      e.preventDefault();
      // Capture the pointer so releasing outside the window still fires
      // pointerup (no stuck ghost / drop highlight / hover lockout).
      try { chip.setPointerCapture(e.pointerId); } catch { /* noop */ }
      const badge = document.createElement("div");
      badge.className = "drag-badge off";
      badge.innerHTML = "＋ <b>Release to add</b>";
      els.workspace.appendChild(badge);
      drag = {
        kind: chip.dataset.el,
        startX: e.clientX, startY: e.clientY,
        ghost: buildGhost(chip.dataset.el),
        badge,
        moved: false,
      };
      document.body.appendChild(drag.ghost);
      document.body.classList.add("is-item-drag");
      state.itemDragActive = true;
      moveDrag(e);
    });

    window.addEventListener("pointermove", moveDrag);
    window.addEventListener("pointerup", (e) => endDrag(e, false));
    window.addEventListener("pointercancel", (e) => endDrag(e, true));
  }

  // ================================================================== pointer + zoom
  function bindShortcuts() {
    document.addEventListener("keydown", (e) => {
      const target = e.target;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT");

      if (typing && !(e.key === "Escape")) {
        if (e.key === "Enter" && target === els.textPopInput && !e.shiftKey) closeTextEditor();
        return;
      }

      const ctrl = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();

      if (ctrl && k === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
      if (ctrl && k === "y") { e.preventDefault(); redo(); return; }
      if (ctrl && k === "s") { e.preventDefault(); saveProject(); toast("Project saved"); return; }
      if (ctrl && k === "e") { e.preventDefault(); openExport(); return; }

      // --- clipboard.
      // Ctrl+V: if we hold a layer copied inside Picsmith, paste that here and
      // now (deterministic — the browser's "paste" event isn't guaranteed to
      // fire). Otherwise fall through to the native paste event, which carries
      // any image sitting on the OS clipboard.
      if (ctrl && k === "v") {
        if (state.clipboard) {
          e.preventDefault();
          state.suppressPasteEvent = true;
          pasteClipboard().finally(() => { state.suppressPasteEvent = false; });
        }
        return;
      }
      if (ctrl && k === "c") {
        e.preventDefault();
        e.shiftKey ? copyImageToSystem() : copySelected();
        return;
      }
      if (ctrl && k === "x") { e.preventDefault(); copySelected({ cut: true }); return; }
      if (ctrl && k === "d") { e.preventDefault(); duplicateLayer(); return; }
      if (ctrl && k === "a") { e.preventDefault(); selectTopLayer(); return; }
      if (ctrl && k === "g") { e.preventDefault(); toggleGrid(); return; }
      if (ctrl && k === "l") { e.preventDefault(); toggleLockSelected(); return; }
      if (ctrl && k === "m") { e.preventDefault(); openImageTool("adjust"); return; }
      if (ctrl && k === "b") { e.preventDefault(); openImageTool("removeBgAI"); return; }
      if (e.key === "Escape") {
        closeAllModals();
        closeAllMenus();
        closeContextMenu();
        if (state.tool === "crop" && state.toolInstance.cancel) { state.toolInstance.cancel(); }
        closeTextEditor();
        return;
      }
      if (e.key === "Enter" && state.tool === "crop" && state.cropRect) { state.toolInstance.apply(); return; }
      if ((e.key === "Delete" || e.key === "Backspace") && !typing) { e.preventDefault(); deleteSelected(); return; }

      const toolKeys = {
        v: "move", b: "brush", e: "eraser", i: "eyedropper", t: "text", u: "shape",
        c: "crop", h: "pan", f: "fill", g: "gradient", l: "blur", k: "sharpen",
        o: "dodge", n: "burn", s: "stamp", z: "zoom",
      };
      if (toolKeys[k] && !ctrl) { setTool(toolKeys[k]); return; }

      if (k === "0") { e.preventDefault(); zoomFit(); return; }
      if (k === "1") { e.preventDefault(); state.zoom = 1; applyZoom(); return; }
      if (k === "=" || k === "+") { e.preventDefault(); zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1.2); return; }
      if (k === "-") { e.preventDefault(); zoomAt(els.workspace.clientWidth / 2, els.workspace.clientHeight / 2, 1 / 1.2); return; }

      if (e.key.startsWith("Arrow")) {
        const layer = selectedLayer();
        if (!layer) return;
        e.preventDefault();
        if (!state.nudgePushed) { pushHistory(); state.nudgePushed = true; }
        const n = e.shiftKey ? 10 : 1;
        if (e.key === "ArrowLeft") layer.transform.x -= n;
        if (e.key === "ArrowRight") layer.transform.x += n;
        if (e.key === "ArrowUp") layer.transform.y -= n;
        if (e.key === "ArrowDown") layer.transform.y += n;
        render();
        markDirty();
        return;
      }

      // space → temporary pan
      if (e.code === "Space" && !typing) {
        e.preventDefault();
        if (!state.spacePan) {
          state.spacePan = true;
          state.toolBeforeSpace = state.tool;
          setTool("pan");
        }
      }
    });

    document.addEventListener("keyup", (e) => {
      if (e.code === "Space" && state.spacePan) {
        state.spacePan = false;
        setTool(state.toolBeforeSpace || "move");
      }
      if (e.key.startsWith("Arrow")) state.nudgePushed = false;
    });

    // pointer
    els.workspace.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      const pt = docPoint(e);
      const layer = PFEngine.topLayerAt(state.doc, pt);
      if (layer) selectLayer(layer.id);
      openCanvasContextMenu(e.clientX, e.clientY, layer, pt);
    });

    els.workspace.addEventListener("pointerdown", (e) => {
      if (e.button === 1) {
        state.dragging = true;
        state.middlePan = true;
        els.workspace.setPointerCapture(e.pointerId);
        e.preventDefault();
        return;
      }
      if (e.button !== 0) return;
      state.dragging = true;
      state.nudgePushed = false;
      clearHover();
      if (state.tool === "move" && hitSelectionHandle(docPoint(e))) {
        els.workspace.style.cursor = "grabbing";
      }
      try {
        state.toolInstance.pointerDown(docPoint(e), e);
      } catch (err) {
        console.error("Picsmith tool error:", err);
      }
      els.workspace.setPointerCapture(e.pointerId);
    });

    els.workspace.addEventListener("pointermove", (e) => {
      updateBrushCursorPos(e);
      const p = docPoint(e);
      state.lastCanvasPt = p; // paste-at-cursor target
      els.hudCursor.textContent = `${Math.round(p.x)}, ${Math.round(p.y)}`;
      if (state.dragging) {
        if (state.middlePan) { panBy(e.movementX, e.movementY); return; }
        try {
          state.toolInstance.pointerMove(docPoint(e), e);
        } catch (err) {
          console.error("Picsmith tool error:", err);
        }
        return;
      }
      // Hover feedback: highlight the handle under the cursor, swap the cursor
      // and show a hint naming the action (resize / rotate / radius / move).
      updateHover(e);
    });

    els.workspace.addEventListener("pointerleave", () => {
      els.hudCursor.textContent = "—, —";
      if (state.dragging) return;
      clearHover();
      els.workspace.style.cursor = "default";
    });

    window.addEventListener("pointerup", (e) => {
      if (!state.dragging) return;
      state.dragging = false;
      state.middlePan = false;
      try {
        state.toolInstance.pointerUp(docPoint(e), e);
      } catch (err) {
        console.error("Picsmith tool error:", err);
      }
      updateHover(e);
    });

    els.workspace.addEventListener("wheel", (e) => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.12 : 1 / 1.12);
    }, { passive: false });

    window.addEventListener("beforeunload", () => {
      saveProject();
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) saveProject();
    });
  }

  function updateBrushCursorPos(e) {
    if (els.brushCursor.style.display === "none") return;
    const r = els.workspace.getBoundingClientRect();
    els.brushCursor.style.left = e.clientX - r.left + "px";
    els.brushCursor.style.top = e.clientY - r.top + "px";
  }

  // ================================================================== go
  boot();
})();
