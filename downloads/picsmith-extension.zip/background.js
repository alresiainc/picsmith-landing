/**
 * Picsmith — background service worker (Manifest V3).
 *
 * Responsibilities:
 *  - OpenAI integration (GPT-4o chat/vision + gpt-image-1 edit/generate)
 *  - Picsmith Pro license validation (HMAC keys, see lib/license.js)
 *  - Settings + license storage
 *  - Message router for popup + editor pages
 *
 * Everything else (the editor itself) runs fully offline in the editor page.
 */
"use strict";

importScripts("lib/license.js");

const OPENAI_BASE = "https://api.openai.com/v1";

const SITE = "https://picsmith.alresia.tech";
const VERSION_URL = `${SITE}/version.json`;
const SUPPORT_URL = `${SITE}/support.html`;
const UPDATE_INTERVAL_MS = 24 * 60 * 60 * 1000;

const DEFAULT_SETTINGS = {
  openaiKey: "",
  openaiModel: "gpt-4o",         // chat / vision model
  openaiImageModel: "gpt-image-1", // image edit + generation model
  // Update checking is OFF unless the user turns it on: with it off the
  // extension makes no network request of any kind on its own.
  updateCheck: false,
  lastUpdateCheck: 0,
};

// ------------------------------------------------------------------ storage

function get(keys) {
  return chrome.storage.local.get(keys);
}
function set(obj) {
  return chrome.storage.local.set(obj);
}

async function getSettings() {
  const { settings } = await get("settings");
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

async function getLicense() {
  const { license } = await get("license");
  return license || null; // { key, tier, keyId, exp, activatedAt }
}

async function isPro() {
  const license = await getLicense();
  if (!license) return false;
  const check = await PFLicense.validate(license.key);
  return check.ok;
}

/** Cloud AI (OpenAI-backed) unlocks with either your own key or a Pro key. */
async function canUseCloudAI() {
  const settings = await getSettings();
  if (settings.openaiKey) return true;
  return isPro();
}

/**
 * A neutral "you need one of these" response — deliberately not PRO_REQUIRED,
 * so the UI doesn't push someone toward buying Pro when adding their own key
 * is the free, one-step fix.
 */
function cloudAIGateResponse() {
  return {
    ok: false,
    code: "AI_LOCKED",
    error: "Add your own OpenAI API key in Settings, or activate Picsmith Pro, to use AI.",
  };
}

// ------------------------------------------------------------------ updates

/**
 * Compare two dotted version strings. Returns >0 if a is newer than b.
 * Segment-wise numeric compare, so "1.10.0" correctly beats "1.9.0" — a
 * plain string comparison gets that backwards.
 */
function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

/**
 * Fetch the published version file and compare it with this build.
 * Never installs anything — Chrome does not allow an extension to update
 * itself outside the Web Store, so the most we can do is tell the user and
 * hand them the download link.
 *
 * Honours the `updateCheck` setting unless `force` is set (the "Check now"
 * button), and throttles automatic checks to once a day.
 */
async function checkForUpdate({ force = false } = {}) {
  const current = chrome.runtime.getManifest().version;
  const settings = await getSettings();

  if (!force) {
    if (!settings.updateCheck) return { ok: true, skipped: "disabled", current };
    if (Date.now() - (settings.lastUpdateCheck || 0) < UPDATE_INTERVAL_MS) {
      return { ok: true, skipped: "throttled", current };
    }
  }

  let data;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(`${VERSION_URL}?t=${Date.now()}`, {
      cache: "no-store",
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, current, error: `Server returned ${res.status}` };
    data = await res.json();
  } catch (err) {
    return {
      ok: false,
      current,
      error: err.name === "AbortError" ? "The check timed out." : "Couldn't reach the update server.",
    };
  }

  const latest = String(data.version || "").trim();
  if (!/^\d+(\.\d+)*$/.test(latest)) return { ok: false, current, error: "The version file looks malformed." };

  const next = { ...settings, lastUpdateCheck: Date.now() };
  await set({ settings: next });

  return {
    ok: true,
    current,
    latest,
    updateAvailable: compareVersions(latest, current) > 0,
    notes: typeof data.notes === "string" ? data.notes : "",
    // Only ever hand back a link on our own site — never a URL the file supplies,
    // so a tampered version.json can't redirect anyone to a hostile download.
    downloadUrl: `${SITE}/downloads/picsmith-extension.zip`,
    releaseUrl: `${SITE}/#get`,
  };
}

// ------------------------------------------------------------------ license

async function handleValidateLicense(key) {
  const check = await PFLicense.validate(key);
  if (check.ok) {
    await set({ license: { key, tier: check.tier, keyId: check.keyId, exp: check.exp, activatedAt: Date.now() } });
  }
  return check;
}

async function handleLicenseStatus() {
  const license = await getLicense();
  if (!license) return { active: false };
  const check = await PFLicense.validate(license.key);
  if (!check.ok) return { active: false, reason: check.reason };
  return { active: true, tier: check.tier, keyId: check.keyId, exp: check.exp, key: license.key };
}

// ------------------------------------------------------------------ OpenAI

function dataURLToBlob(dataURL) {
  const [head, body] = String(dataURL || "").split(",");
  const mime = /data:(.*?);base64/.exec(head)?.[1] || "image/png";
  const bin = atob(body);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

async function openaiFetch(path, { method = "POST", headers = {}, body } = {}) {
  const settings = await getSettings();
  if (!settings.openaiKey) {
    return { ok: false, code: "NO_KEY", error: "Add your OpenAI API key in Settings → AI to use AI features." };
  }
  let res;
  try {
    res = await fetch(`${OPENAI_BASE}${path}`, {
      method,
      headers: { Authorization: `Bearer ${settings.openaiKey}`, ...headers },
      body,
    });
  } catch (err) {
    return { ok: false, code: "OFFLINE", error: "No internet connection — AI needs to reach api.openai.com." };
  }

  if (res.ok) {
    try {
      return { ok: true, data: await res.json() };
    } catch {
      return { ok: false, code: "PARSE", error: "Unexpected response from OpenAI." };
    }
  }

  let detail = "";
  try {
    const j = await res.json();
    detail = j?.error?.message || j?.message || "";
  } catch { /* ignore */ }

  const map = {
    401: "Invalid OpenAI API key — check Settings → AI.",
    403: "This OpenAI key can't access the requested model.",
    429: "OpenAI rate limit hit — wait a moment and retry.",
    400: "The request was rejected: " + detail,
  };
  return { ok: false, code: "HTTP_" + res.status, error: map[res.status] || `OpenAI error ${res.status}: ${detail}` };
}

/** GPT-4o chat / vision. Returns text. */
async function aiChat({ prompt, image, mode }) {
  const settings = await getSettings();
  const system = {
    describe: "You are a professional photo editor. Analyze the attached image and describe it in under 150 words: subject, composition, colors, lighting, style, mood, and any flaws or things you'd improve.",
    suggest: "You are a professional photo editor. Based on the attached image, suggest exactly 4 specific, short edit prompts (8 words max each) that would improve it. Return ONLY a JSON array of strings, nothing else.",
    caption: "You are a social media expert. Write 3 short captions (under 120 characters each) with relevant hashtags for the attached image. Return ONLY the captions, numbered 1-3.",
    custom: "You are a helpful assistant and expert photo editor. Answer the user's question about the attached image concisely.",
  }[mode || "custom"];

  const content = image
    ? [
        { type: "text", text: prompt },
        { type: "image_url", image_url: { url: image } },
      ]
    : prompt;

  const result = await openaiFetch("/chat/completions", {
    body: JSON.stringify({
      model: settings.openaiModel || "gpt-4o",
      messages: [
        { role: "system", content: system },
        { role: "user", content },
      ],
      max_tokens: 900,
    }),
  });
  if (!result.ok) return result;
  const text = result.data?.choices?.[0]?.message?.content || "";
  return { ok: true, text };
}

/** gpt-image-1 image edit (whole image, no mask). Returns PNG dataURL. */
async function aiEdit({ image, prompt }) {
  const settings = await getSettings();
  const form = new FormData();
  form.append("model", settings.openaiImageModel || "gpt-image-1");
  form.append("prompt", prompt);
  form.append("image", dataURLToBlob(image), "edit.png");
  form.append("size", "1536x1536");
  const result = await openaiFetch("/images/edits", { body: form });
  if (!result.ok) return result;
  const b64 = result.data?.data?.[0]?.b64_json;
  if (!b64) return { ok: false, code: "EMPTY", error: "OpenAI returned no image." };
  return { ok: true, image: `data:image/png;base64,${b64}` };
}

/** gpt-image-1 generation from a prompt. Returns PNG dataURL. */
async function aiGenerate({ prompt }) {
  const settings = await getSettings();
  const result = await openaiFetch("/images/generations", {
    body: JSON.stringify({
      model: settings.openaiImageModel || "gpt-image-1",
      prompt,
      n: 1,
      size: "1536x1536",
    }),
  });
  if (!result.ok) return result;
  const b64 = result.data?.data?.[0]?.b64_json;
  if (!b64) return { ok: false, code: "EMPTY", error: "OpenAI returned no image." };
  return { ok: true, image: `data:image/png;base64,${b64}` };
}

// ------------------------------------------------------------------ router

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case "license:validate": {
        sendResponse(await handleValidateLicense(message.key));
        break;
      }
      case "license:clear": {
        await set({ license: null });
        sendResponse({ ok: true });
        break;
      }
      case "license:status": {
        sendResponse(await handleLicenseStatus());
        break;
      }
      case "settings:get": {
        const settings = await getSettings();
        const license = await handleLicenseStatus();
        sendResponse({ ok: true, settings, license });
        break;
      }
      case "settings:set": {
        const { settings } = await get("settings");
        const next = { ...DEFAULT_SETTINGS, ...(settings || {}), [message.key]: message.value };
        await set({ settings: next });
        sendResponse({ ok: true, settings: next });
        break;
      }
      // The layer clipboard lives under its own key, not inside `settings` —
      // a pasted layer carries a full PNG dataURL, and settings are rewritten
      // wholesale on every slider tweak.
      case "clipboard:set": {
        await set({ clipboardLayer: message.value || null });
        sendResponse({ ok: true });
        break;
      }
      case "clipboard:get": {
        const { clipboardLayer } = await get("clipboardLayer");
        sendResponse({ ok: true, layer: clipboardLayer || null });
        break;
      }
      case "update:check": {
        sendResponse(await checkForUpdate({ force: !!message.force }));
        break;
      }
      case "support:open": {
        chrome.tabs.create({ url: SUPPORT_URL });
        sendResponse({ ok: true });
        break;
      }
      // AI is gated by "do you have a way to pay for it", not by Pro alone:
      // bring your own OpenAI key and it just works — you're already paying
      // OpenAI, we're not giving away anything of ours. Pro exists for people
      // who'd rather not manage a key themselves, whenever we offer that, and
      // for the on-device ML packs (background removal, upscaling, …), which
      // DO cost us hosting/bandwidth regardless of who's asking.
      case "ai:chat": {
        if (!(await canUseCloudAI())) { sendResponse(cloudAIGateResponse()); break; }
        sendResponse(await aiChat(message));
        break;
      }
      case "ai:edit": {
        if (!(await canUseCloudAI())) { sendResponse(cloudAIGateResponse()); break; }
        sendResponse(await aiEdit(message));
        break;
      }
      case "ai:generate": {
        if (!(await canUseCloudAI())) { sendResponse(cloudAIGateResponse()); break; }
        sendResponse(await aiGenerate(message));
        break;
      }
      default:
        sendResponse({ ok: false, error: "Unknown message type" });
    }
  })().catch((err) => {
    console.error("Picsmith:", err);
    sendResponse({ ok: false, error: String(err) });
  });
  return true; // async response
});

// ------------------------------------------------------------------ lifecycle

chrome.runtime.onInstalled.addListener((details) => {
  get("settings").then(({ settings }) => {
    if (!settings) set({ settings: { ...DEFAULT_SETTINGS } });
  });
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("install.html") });
  }
});
